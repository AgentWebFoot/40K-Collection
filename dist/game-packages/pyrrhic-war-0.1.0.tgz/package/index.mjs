// PyrrhicWar/PyrrhicWar.jsx
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

// packages/host.mjs
var API_URL = "";
var host;
function configureHost(options) {
  if (typeof options?.API_URL !== "string" || typeof options.fetchJson !== "function" || typeof options.getAuthEventName !== "function") {
    throw new TypeError("Provide the host API_URL, fetchJson, and getAuthEventName.");
  }
  API_URL = options.API_URL.replace(/\/$/, "");
  host = options;
}
function hostFunction(name, args) {
  if (typeof host?.[name] !== "function") {
    throw new Error(`Configure the game host with ${name} before opening this page.`);
  }
  return host[name](...args);
}
function fetchJson(...args) {
  return hostFunction("fetchJson", args);
}
function getAuthEventName(...args) {
  return hostFunction("getAuthEventName", args);
}
function readStoredUser(...args) {
  return hostFunction("readStoredUser", args);
}
function refreshStoredUser(...args) {
  return hostFunction("refreshStoredUser", args);
}

// PyrrhicWar/PyrrhicWar.jsx
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var styles = {
  page: {
    minHeight: "100dvh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "16px",
    padding: "24px",
    boxSizing: "border-box",
    background: "radial-gradient(circle at top, rgba(132, 47, 47, 0.24), transparent 34%), linear-gradient(180deg, #241312 0%, #160d0c 55%, #0c0707 100%)",
    color: "#f4e7d7",
    fontFamily: '"Trebuchet MS", sans-serif',
    textAlign: "center"
  },
  backButton: {
    position: "absolute",
    top: "8px",
    left: "12px",
    zIndex: 1e3,
    minWidth: "104px",
    padding: "9px 14px",
    border: "1px solid rgba(124, 19, 19, 0.92)",
    borderRadius: "6px",
    background: "linear-gradient(180deg, rgba(108, 10, 10, 0.98), rgba(52, 5, 5, 0.99))",
    color: "#f9e6de",
    cursor: "pointer",
    fontFamily: '"Trebuchet MS", sans-serif',
    fontSize: "0.92rem",
    fontWeight: 700,
    boxSizing: "border-box",
    boxShadow: "0 10px 24px rgba(24, 3, 3, 0.48)"
  },
  titleBox: {
    minWidth: "320px",
    maxWidth: "100%",
    padding: "14px 18px",
    border: "1px solid rgba(116, 67, 52, 0.45)",
    borderRadius: "8px",
    background: "linear-gradient(135deg, rgba(245, 235, 220, 0.98), rgba(214, 183, 158, 0.95))",
    color: "#241312",
    fontFamily: "Georgia, serif",
    fontSize: "1.35rem",
    fontWeight: 700,
    boxSizing: "border-box",
    boxShadow: "0 16px 40px rgba(12, 7, 7, 0.42)"
  },
  actions: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: "14px",
    padding: "18px",
    border: "1px solid rgba(214, 170, 114, 0.32)",
    borderRadius: "8px",
    background: "rgba(32, 16, 16, 0.9)",
    boxShadow: "0 16px 40px rgba(12, 7, 7, 0.42)"
  },
  button: {
    minWidth: "180px",
    padding: "12px 18px",
    border: "1px solid #9d6248",
    borderRadius: "6px",
    background: "rgba(245, 235, 220, 0.95)",
    color: "#241312",
    fontFamily: '"Trebuchet MS", sans-serif',
    fontSize: "1rem",
    fontWeight: 700,
    textDecoration: "none",
    cursor: "pointer",
    boxSizing: "border-box"
  },
  gearButton: {
    position: "absolute",
    top: "8px",
    right: "12px",
    zIndex: 1e3,
    width: "44px",
    height: "44px",
    border: "1px solid rgba(214, 170, 114, 0.42)",
    borderRadius: "6px",
    background: "rgba(32, 16, 16, 0.9)",
    color: "#f4e7d7",
    cursor: "pointer",
    fontSize: "22px",
    lineHeight: 1,
    boxSizing: "border-box"
  },
  modalOverlay: {
    position: "fixed",
    inset: 0,
    zIndex: 2e3,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "20px",
    background: "rgba(12, 7, 7, 0.78)"
  },
  modal: {
    width: "min(980px, 100%)",
    maxHeight: "82dvh",
    overflow: "auto",
    padding: "20px",
    border: "1px solid rgba(214, 170, 114, 0.32)",
    borderRadius: "8px",
    background: "linear-gradient(180deg, rgba(36, 19, 18, 0.98), rgba(12, 7, 7, 0.98))",
    color: "#f4e7d7",
    boxShadow: "0 18px 42px rgba(12, 7, 7, 0.48)",
    textAlign: "left"
  },
  modalHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "12px",
    marginBottom: "14px"
  },
  settingsSummary: {
    color: "rgba(244, 231, 215, 0.82)",
    fontSize: "0.94rem",
    lineHeight: 1.5
  },
  patronRow: {
    display: "grid",
    gridTemplateColumns: "minmax(180px, 1fr) minmax(180px, auto) minmax(180px, auto)",
    gap: "12px",
    alignItems: "start",
    padding: "12px 0",
    borderTop: "1px solid rgba(214, 170, 114, 0.16)"
  },
  controlBlock: {
    display: "flex",
    flexDirection: "column",
    gap: "6px"
  },
  controlLabel: {
    fontSize: "0.85rem",
    color: "rgba(244, 231, 215, 0.72)",
    textTransform: "uppercase",
    letterSpacing: "0.04em"
  },
  select: {
    minWidth: "160px",
    padding: "8px 10px",
    border: "1px solid rgba(214, 170, 114, 0.42)",
    borderRadius: "6px",
    background: "rgba(245, 235, 220, 0.95)",
    color: "#241312",
    fontFamily: '"Trebuchet MS", sans-serif',
    fontSize: "0.95rem",
    fontWeight: 700
  },
  smallButton: {
    padding: "7px 10px",
    border: "1px solid #9d6248",
    borderRadius: "6px",
    background: "rgba(245, 235, 220, 0.95)",
    color: "#241312",
    fontWeight: 700,
    cursor: "pointer"
  },
  mutedText: {
    color: "rgba(244, 231, 215, 0.72)",
    fontSize: "0.9rem"
  },
  statusText: {
    marginTop: "12px",
    color: "#d6aa72",
    fontWeight: 700
  }
};
function formatPyrrhicWarRole(role = "viewer") {
  const normalizedRole = String(role).trim().toLowerCase();
  if (normalizedRole === "participant") return "Participant";
  if (normalizedRole === "writer") return "Writer";
  if (normalizedRole === "admin") return "Admin";
  if (normalizedRole === "owner") return "Owner";
  return "Viewer";
}
function formatPyrrhicWarTeam(team = 0) {
  switch (Number(team)) {
    case 1:
      return "Imperial Forces";
    case 2:
      return "United Chaos";
    case 3:
      return "Forces of Change";
    case 4:
      return "Marauders";
    default:
      return "No Team";
  }
}
function PyrrhicWar() {
  const navigate = useNavigate();
  const [user, setUser] = useState(() => readStoredUser());
  const [pyrrhicAccess, setPyrrhicAccess] = useState({
    role: "viewer",
    team: 0,
    canManageRoles: false,
    canEditCompendium: false
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [patrons, setPatrons] = useState([]);
  const [settingsMessage, setSettingsMessage] = useState("");
  const [isPatronsBusy, setIsPatronsBusy] = useState(false);
  useEffect(() => {
    let ignore = false;
    async function syncUser() {
      const storedUser = readStoredUser();
      setUser(storedUser);
      if (!storedUser) {
        if (!ignore) {
          setPyrrhicAccess({
            role: "viewer",
            team: 0,
            canManageRoles: false,
            canEditCompendium: false
          });
        }
        return;
      }
      try {
        await refreshStoredUser();
        const { response, payload } = await fetchJson("/pyrrhic-war/access", {
          method: "GET"
        });
        if (!ignore && response.ok) {
          setPyrrhicAccess({
            role: payload.access?.role || "viewer",
            team: Number(payload.access?.team || 0),
            canManageRoles: Boolean(payload.access?.canManageRoles),
            canEditCompendium: Boolean(payload.access?.canEditCompendium)
          });
        }
      } catch (_error) {
        if (!ignore) {
          setPyrrhicAccess({
            role: "viewer",
            team: 0,
            canManageRoles: false,
            canEditCompendium: false
          });
        }
      }
    }
    window.addEventListener(getAuthEventName(), syncUser);
    syncUser();
    return () => {
      ignore = true;
      window.removeEventListener(getAuthEventName(), syncUser);
    };
  }, []);
  async function loadPatrons() {
    if (!pyrrhicAccess.canManageRoles) return;
    setIsPatronsBusy(true);
    setSettingsMessage("");
    try {
      const { response, payload } = await fetchJson("/pyrrhic-war/roles/list", {
        method: "POST"
      });
      if (!response.ok) {
        setSettingsMessage(payload.message || "Unable to load Pyrrhic War members.");
        return;
      }
      setPatrons(payload.patrons || []);
    } catch (_error) {
      setSettingsMessage("Unable to load Pyrrhic War members.");
    } finally {
      setIsPatronsBusy(false);
    }
  }
  function openSettings() {
    setIsSettingsOpen(true);
    loadPatrons();
  }
  async function handleMembershipChange(patron, nextRole, nextTeam) {
    setIsPatronsBusy(true);
    setSettingsMessage("");
    try {
      const { response, payload } = await fetchJson("/pyrrhic-war/roles/set-role", {
        method: "POST",
        body: JSON.stringify({
          targetUserId: patron.id,
          role: nextRole,
          team: Number(nextTeam || 0)
        })
      });
      if (!response.ok) {
        setSettingsMessage(payload.message || "Unable to update that Pyrrhic War member.");
        return;
      }
      setPatrons((prev) => prev.map((item2) => item2.id === payload.patron.id ? payload.patron : item2));
      setSettingsMessage(payload.message || "Pyrrhic War access updated.");
      if (payload.patron.id === user?.id) {
        const { response: accessResponse, payload: accessPayload } = await fetchJson("/pyrrhic-war/access", {
          method: "GET"
        });
        if (accessResponse.ok) {
          setPyrrhicAccess({
            role: accessPayload.access?.role || "viewer",
            team: Number(accessPayload.access?.team || 0),
            canManageRoles: Boolean(accessPayload.access?.canManageRoles),
            canEditCompendium: Boolean(accessPayload.access?.canEditCompendium)
          });
        }
      }
    } catch (_error) {
      setSettingsMessage("Unable to update that Pyrrhic War member.");
    } finally {
      setIsPatronsBusy(false);
    }
  }
  return /* @__PURE__ */ jsxs("main", { style: styles.page, children: [
    /* @__PURE__ */ jsx("button", { type: "button", onClick: () => navigate("/projects"), style: styles.backButton, children: "< Back" }),
    pyrrhicAccess.canManageRoles && /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        onClick: openSettings,
        style: styles.gearButton,
        "aria-label": "Open Pyrrhic War settings",
        title: "Pyrrhic War settings",
        children: "\u2699"
      }
    ),
    /* @__PURE__ */ jsx("div", { style: styles.titleBox, children: "Pyrrhic War" }),
    /* @__PURE__ */ jsxs("div", { style: styles.actions, children: [
      /* @__PURE__ */ jsx(Link, { to: "/projects/PyrrhicWarCompendium", style: styles.button, children: "Compendium" }),
      /* @__PURE__ */ jsx(Link, { to: "/projects/PyrrhicWarMap", style: styles.button, children: "Crusade Board" })
    ] }),
    isSettingsOpen && /* @__PURE__ */ jsx("div", { style: styles.modalOverlay, onClick: () => setIsSettingsOpen(false), children: /* @__PURE__ */ jsxs("div", { style: styles.modal, onClick: (event) => event.stopPropagation(), children: [
      /* @__PURE__ */ jsxs("div", { style: styles.modalHeader, children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h2", { style: { margin: 0, fontFamily: "Georgia, serif" }, children: "Pyrrhic War Settings" }),
          /* @__PURE__ */ jsxs("div", { style: styles.settingsSummary, children: [
            user?.username || "This user",
            " currently has Pyrrhic War ",
            formatPyrrhicWarRole(pyrrhicAccess.role),
            " access for",
            " ",
            formatPyrrhicWarTeam(pyrrhicAccess.team),
            "."
          ] })
        ] }),
        /* @__PURE__ */ jsx("button", { type: "button", style: styles.smallButton, onClick: () => setIsSettingsOpen(false), children: "Close" })
      ] }),
      /* @__PURE__ */ jsx("div", { style: styles.mutedText, children: "Owners, website admins, and Pyrrhic War admins can manage Pyrrhic War access and team assignments." }),
      /* @__PURE__ */ jsx("div", { style: styles.mutedText, children: "The `Writer` role can edit the Pyrrhic War compendium without granting crusade-board admin access." }),
      settingsMessage && /* @__PURE__ */ jsx("div", { style: styles.statusText, children: settingsMessage }),
      /* @__PURE__ */ jsx("div", { style: { marginTop: "12px" }, children: isPatronsBusy && patrons.length === 0 ? /* @__PURE__ */ jsx("div", { children: "Loading members..." }) : patrons.map((patron) => /* @__PURE__ */ jsxs("div", { style: styles.patronRow, children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { style: { fontWeight: 700 }, children: patron.username || "Unnamed user" }),
          /* @__PURE__ */ jsx("div", { style: styles.mutedText, children: patron.email }),
          /* @__PURE__ */ jsxs("div", { style: styles.mutedText, children: [
            "Current: ",
            formatPyrrhicWarRole(patron.pyrrhicWarRole),
            " for ",
            formatPyrrhicWarTeam(patron.pyrrhicWarTeam)
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { style: styles.controlBlock, children: [
          /* @__PURE__ */ jsx("label", { htmlFor: `pyrrhic-role-${patron.id}`, style: styles.controlLabel, children: "Access" }),
          /* @__PURE__ */ jsx(
            "select",
            {
              id: `pyrrhic-role-${patron.id}`,
              style: styles.select,
              value: patron.pyrrhicWarMembershipRole === "owner" ? "owner" : patron.pyrrhicWarMembershipRole || "viewer",
              onChange: (event) => handleMembershipChange(patron, event.target.value, patron.pyrrhicWarTeam),
              disabled: isPatronsBusy || !patron.canEditPyrrhicWarRole || patron.pyrrhicWarRole === "owner",
              children: patron.pyrrhicWarRole === "owner" ? /* @__PURE__ */ jsx("option", { value: "owner", children: "Owner" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx("option", { value: "viewer", children: "Viewer" }),
                /* @__PURE__ */ jsx("option", { value: "participant", children: "Participant" }),
                /* @__PURE__ */ jsx("option", { value: "writer", children: "Writer" }),
                /* @__PURE__ */ jsx("option", { value: "admin", children: "Admin" })
              ] })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { style: styles.controlBlock, children: [
          /* @__PURE__ */ jsx("label", { htmlFor: `pyrrhic-team-${patron.id}`, style: styles.controlLabel, children: "Team" }),
          /* @__PURE__ */ jsxs(
            "select",
            {
              id: `pyrrhic-team-${patron.id}`,
              style: styles.select,
              value: String(Number(patron.pyrrhicWarTeam || 0)),
              onChange: (event) => handleMembershipChange(
                patron,
                patron.pyrrhicWarRole === "owner" ? "owner" : patron.pyrrhicWarMembershipRole || "viewer",
                Number(event.target.value)
              ),
              disabled: isPatronsBusy || !patron.canEditPyrrhicWarTeam,
              children: [
                /* @__PURE__ */ jsx("option", { value: "0", children: "No Team" }),
                /* @__PURE__ */ jsx("option", { value: "1", children: "Imperial Forces" }),
                /* @__PURE__ */ jsx("option", { value: "2", children: "United Chaos" }),
                /* @__PURE__ */ jsx("option", { value: "3", children: "Forces of Change" }),
                /* @__PURE__ */ jsx("option", { value: "4", children: "Marauders" })
              ]
            }
          )
        ] })
      ] }, patron.id)) })
    ] }) })
  ] });
}

// PyrrhicWar/PyrrhicWarMap.jsx
import { useNavigate as useNavigate2 } from "react-router-dom";
import { jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
var backButtonStyle = {
  position: "absolute",
  top: "8px",
  left: "12px",
  zIndex: 1e3,
  minWidth: "104px",
  padding: "9px 14px",
  border: "1px solid rgba(124, 19, 19, 0.92)",
  borderRadius: "6px",
  background: "linear-gradient(180deg, rgba(108, 10, 10, 0.98), rgba(52, 5, 5, 0.99))",
  color: "#f9e6de",
  cursor: "pointer",
  fontFamily: '"Trebuchet MS", sans-serif',
  fontSize: "0.92rem",
  fontWeight: 700,
  boxSizing: "border-box",
  boxShadow: "0 10px 24px rgba(24, 3, 3, 0.48)"
};
var PyrrhicWarMap = () => {
  const navigate = useNavigate2();
  const apiUrl = encodeURIComponent(API_URL);
  const boardVersion = "2026-07-18-01";
  return /* @__PURE__ */ jsxs2(
    "div",
    {
      style: {
        position: "fixed",
        inset: 0,
        width: "100%",
        height: "100dvh",
        overflow: "hidden"
      },
      children: [
        /* @__PURE__ */ jsx2(
          "button",
          {
            type: "button",
            onClick: () => navigate("/projects/PyrrhicWar"),
            style: backButtonStyle,
            children: "< Back"
          }
        ),
        /* @__PURE__ */ jsx2(
          "iframe",
          {
            src: `/games/PyrrhicWar/40kCrusadeBoard.html?v=${boardVersion}&apiUrl=${apiUrl}`,
            title: "Pyrrhic War Crusade Board",
            style: {
              width: "100%",
              height: "100%",
              border: "none",
              display: "block"
            }
          }
        )
      ]
    }
  );
};
var PyrrhicWarMap_default = PyrrhicWarMap;

// preview/GameCompendium.jsx
import { useEffect as useEffect2, useRef, useState as useState2 } from "react";
import { Link as Link2 } from "react-router-dom";

// node_modules/compendium/src/index.js
var pageTypes = /* @__PURE__ */ new Set(["normal", "grid", "table", "classes"]);
function indexById(items, label) {
  const index = /* @__PURE__ */ new Map();
  for (const item2 of items) {
    const id = item2?.id;
    if (typeof id !== "string" || !id.trim() || id !== id.trim()) {
      throw new TypeError(`${label} must have a non-empty ID without surrounding whitespace.`);
    }
    if (index.has(id)) {
      throw new TypeError(`Duplicate ${label.toLowerCase()} ID: ${id}`);
    }
    index.set(id, item2);
  }
  return index;
}
function resolvePage(page, collections, fallbackType) {
  const type = page.type ?? fallbackType;
  if (!pageTypes.has(type)) {
    throw new TypeError(`Unknown page type for "${page.id}": ${type}`);
  }
  const entries = page.collectionId === void 0 ? /* @__PURE__ */ new Map() : collections.get(page.collectionId);
  if (!entries) {
    throw new TypeError(`Unknown collection for "${page.id}": ${page.collectionId}`);
  }
  return {
    page: { ...page, type, entries: [...entries.values()] },
    entries
  };
}
function createCompendium({ tabs, collections = [] }) {
  if (!Array.isArray(tabs)) throw new TypeError("Compendium data must contain a tabs array.");
  const collectionsById = /* @__PURE__ */ new Map();
  for (const [id, collection] of indexById(collections, "Collection")) {
    collectionsById.set(id, indexById(collection.entries, `Entry in collection "${id}"`));
  }
  const tabsById = /* @__PURE__ */ new Map();
  for (const [id, tab] of indexById(tabs, "Tab")) {
    const resolved = resolvePage(tab, collectionsById, "normal");
    const sections = /* @__PURE__ */ new Map();
    for (const [sectionId, section] of indexById(tab.sections ?? [], `Section in tab "${id}"`)) {
      sections.set(sectionId, resolvePage(section, collectionsById, resolved.page.type));
    }
    resolved.page.sections = [...sections.values()].map((section) => section.page);
    tabsById.set(id, { ...resolved, sections });
  }
  return {
    tabs: [...tabsById.values()].map((tab) => tab.page),
    resolveEntry({ tabId, sectionId, entryId }) {
      const tab = tabsById.get(tabId);
      const target = sectionId === void 0 ? tab : tab?.sections.get(sectionId);
      const entry = target?.entries.get(entryId);
      if (!entry) return null;
      return { tab: tab.page, section: sectionId === void 0 ? null : target.page, entry };
    }
  };
}

// node_modules/compendium/src/browser/favorites.js
function favoriteKey({ tabId, sectionId, entryId, block }) {
  return JSON.stringify([tabId, sectionId, entryId, block?.field, block?.index]);
}
function loadFavorites(projectId) {
  const storageKey = `compendium-preview:favorites:${projectId}`;
  let entries = [];
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey) ?? "[]");
    if (Array.isArray(stored)) {
      entries = stored.filter((item2) => typeof item2?.tabId === "string" && typeof item2.entryId === "string");
    }
  } catch {
  }
  const favorites = new Map(entries.map((item2) => [favoriteKey(item2), item2]));
  function save() {
    try {
      localStorage.setItem(storageKey, JSON.stringify([...favorites.values()]));
    } catch {
    }
  }
  return {
    get size() {
      return favorites.size;
    },
    values: () => favorites.values(),
    has: (item2) => favorites.has(favoriteKey(item2)),
    toggle(item2) {
      const key = favoriteKey(item2);
      if (!favorites.delete(key)) {
        favorites.set(key, item2);
        save();
        return true;
      }
      save();
      return false;
    }
  };
}

// node_modules/compendium/src/images.js
var imageFormats = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp"
};
function isImageName(name) {
  return typeof name === "string" && /^[a-z0-9][a-z0-9._-]{0,119}\.(?:png|jpe?g|webp)$/i.test(name);
}

// node_modules/compendium/src/browser/writer-spellcheck.js
function createSpellcheckField(textarea, checkSpelling) {
  const shell = document.createElement("div");
  shell.className = "spellcheck-field";
  const editor = document.createElement("div");
  editor.className = "spellcheck-editor";
  const mirror = document.createElement("div");
  mirror.className = "spellcheck-mirror";
  mirror.setAttribute("aria-hidden", "true");
  editor.append(textarea, mirror);
  const menu = document.createElement("div");
  menu.className = "spellcheck-menu";
  menu.setAttribute("popover", "auto");
  menu.setAttribute("role", "dialog");
  menu.setAttribute("aria-label", "Spelling suggestions");
  const status = document.createElement("p");
  status.className = "spellcheck-status";
  status.setAttribute("role", "status");
  shell.append(editor, status, menu);
  textarea.spellcheck = false;
  textarea.lang = "en-US";
  let issues = [];
  let checkedText = "";
  let timer;
  let request;
  function sync() {
    mirror.style.left = `${textarea.clientLeft}px`;
    mirror.style.top = `${textarea.clientTop}px`;
    mirror.style.width = `${textarea.clientWidth}px`;
    mirror.style.height = `${textarea.clientHeight}px`;
    mirror.scrollTop = textarea.scrollTop;
    mirror.scrollLeft = textarea.scrollLeft;
  }
  function highlight() {
    const content = document.createDocumentFragment();
    let end = 0;
    for (const [index, issue] of issues.entries()) {
      content.append(checkedText.slice(end, issue.start));
      const mark = document.createElement("mark");
      mark.dataset.spellingIssue = index;
      mark.textContent = issue.word;
      content.append(mark);
      end = issue.end;
    }
    content.append(checkedText.slice(end), "\u200B");
    mirror.replaceChildren(content);
    sync();
  }
  function closeSuggestions() {
    if (menu.matches(":popover-open")) menu.hidePopover();
  }
  function openSuggestions(issue, x, y) {
    menu.replaceChildren();
    const heading = document.createElement("strong");
    heading.textContent = issue.word;
    menu.append(heading);
    if (issue.suggestions.length) {
      for (const suggestion of issue.suggestions) {
        const button2 = document.createElement("button");
        button2.type = "button";
        button2.textContent = suggestion;
        button2.addEventListener("click", () => {
          if (textarea.value !== checkedText) return closeSuggestions();
          textarea.setRangeText(suggestion, issue.start, issue.end, "end");
          textarea.focus();
          queueCheck();
        });
        menu.append(button2);
      }
    } else {
      const empty = document.createElement("span");
      empty.textContent = "No suggestions";
      menu.append(empty);
    }
    menu.showPopover();
    menu.style.left = `${Math.max(8, Math.min(x, window.innerWidth - menu.offsetWidth - 8))}px`;
    menu.style.top = `${Math.max(8, Math.min(y, window.innerHeight - menu.offsetHeight - 8))}px`;
    menu.querySelector("button")?.focus();
  }
  function issueAtCaret() {
    return issues.find((issue) => textarea.selectionStart <= issue.end && textarea.selectionEnd >= issue.start);
  }
  function contextMenu(event) {
    if (textarea.value !== checkedText) return;
    const mark = [...mirror.querySelectorAll("mark")].find((node) => [...node.getClientRects()].some((rect2) => event.clientX >= rect2.left && event.clientX <= rect2.right && event.clientY >= rect2.top && event.clientY <= rect2.bottom));
    const issue = mark ? issues[Number(mark.dataset.spellingIssue)] : issueAtCaret();
    if (!issue) return;
    event.preventDefault();
    const rect = textarea.getBoundingClientRect();
    openSuggestions(issue, event.clientX || rect.left, event.clientY || rect.bottom);
  }
  function queueCheck() {
    clearTimeout(timer);
    request?.abort();
    closeSuggestions();
    issues = [];
    checkedText = textarea.value;
    highlight();
    status.textContent = "";
    const text = checkedText;
    if (!text.trim()) return;
    timer = setTimeout(async () => {
      const current = new AbortController();
      request = current;
      try {
        const result = await checkSpelling(text, { signal: current.signal });
        if (current.signal.aborted) return;
        textarea.spellcheck = false;
        issues = result.issues;
        highlight();
      } catch (error) {
        if (current.signal.aborted) return;
        if (error.status === 400) {
          status.textContent = error.message;
          return;
        }
        textarea.spellcheck = true;
        status.textContent = "Using browser spellcheck. The compendium dictionary is unavailable.";
      }
    }, 250);
  }
  textarea.addEventListener("input", queueCheck);
  textarea.addEventListener("scroll", sync);
  textarea.addEventListener("contextmenu", contextMenu);
  const resize = new ResizeObserver(sync);
  resize.observe(textarea);
  queueCheck();
  return {
    shell,
    dispose() {
      clearTimeout(timer);
      request?.abort();
      resize.disconnect();
      closeSuggestions();
    }
  };
}

// node_modules/compendium/src/browser/inline-format.js
var formats = [
  { label: "Bold", symbol: "B", marker: "**", tag: "strong", shortcut: "b" },
  { label: "Italic", symbol: "I", marker: "*", tag: "em", shortcut: "i" },
  { label: "Underline", symbol: "U", marker: "++", tag: "u", shortcut: "u" },
  { label: "Strikethrough", symbol: "S", marker: "~~", tag: "s" }
];
var tags = new Map(formats.map(({ marker, tag }) => [marker, tag]));
var shortcuts = new Map(formats.filter((format) => format.shortcut).map((format) => [format.shortcut, format.marker]));
function appendInline(node, text, referenceFor) {
  const lines = text.split(/\r?\n/);
  for (const [index, line] of lines.entries()) {
    if (index) node.append("\n");
    appendLine(node, line, referenceFor);
  }
  return node;
}
function appendLine(node, text, referenceFor) {
  const stack = [{ content: node }];
  const current = () => stack.at(-1);
  let offset = 0;
  function open(marker) {
    stack.push({ marker, content: node.ownerDocument.createDocumentFragment() });
  }
  function close() {
    const { marker, content } = stack.pop();
    const formatted = node.ownerDocument.createElement(tags.get(marker));
    formatted.append(content);
    current().content.append(formatted);
  }
  for (const match of text.matchAll(/\\([*+~<>\\])|<([^<>]+)>|\*+|\++|~+/g)) {
    current().content.append(text.slice(offset, match.index));
    const [token, escaped, reference] = match;
    offset = match.index + token.length;
    if (escaped) {
      current().content.append(escaped);
      continue;
    }
    if (reference) {
      current().content.append(referenceFor(reference) ?? token);
      continue;
    }
    const canOpen = offset < text.length && !/\s/.test(text[offset]);
    const canClose = match.index > 0 && !/\s/.test(text[match.index - 1]);
    if (token[0] === "*" && token.length <= 3) {
      let remaining = token.length;
      while (remaining) {
        const marker = current().marker;
        if (canClose && marker?.startsWith("*") && marker.length <= remaining) {
          remaining -= marker.length;
          close();
        } else if (canOpen) {
          const length = Math.min(2, remaining);
          open("*".repeat(length));
          remaining -= length;
        } else {
          current().content.append("*".repeat(remaining));
          break;
        }
      }
    } else if (tags.has(token)) {
      if (canClose && current().marker === token) close();
      else if (canOpen) open(token);
      else current().content.append(token);
    } else {
      current().content.append(token);
    }
  }
  current().content.append(text.slice(offset));
  while (stack.length > 1) {
    const { marker, content } = stack.pop();
    current().content.append(marker, content);
  }
}
function surrounds(value, start, end, marker) {
  const length = marker.length;
  if (value.slice(start - length, start) !== marker || value.slice(end, end + length) !== marker) return false;
  if (marker !== "*") return true;
  const left = value.slice(0, start).match(/\*+$/)?.[0].length;
  const right = value.slice(end).match(/^\*+/)?.[0].length;
  return left !== 2 && right !== 2;
}
function toggleFormatting(textarea, marker) {
  const { value } = textarea;
  let start = textarea.selectionStart;
  let end = textarea.selectionEnd;
  const selected = value.slice(start, end);
  let replacement;
  let selectionStart;
  let selectionEnd;
  if (!selected.includes("\n") && surrounds(value, start, end, marker)) {
    start -= marker.length;
    end += marker.length;
    replacement = selected;
    selectionStart = start;
    selectionEnd = start + selected.length;
  } else if (!selected.includes("\n") && selected.length > marker.length * 2 && surrounds(selected, marker.length, selected.length - marker.length, marker)) {
    replacement = selected.slice(marker.length, -marker.length);
    selectionStart = start;
    selectionEnd = start + replacement.length;
  } else if (selected.includes("\n")) {
    replacement = selected.split("\n").map((line) => {
      const [, before, text, after] = line.match(/^([ \t]*(?:#{1,3}[ \t]+)?)(.*?)([ \t]*)$/) ?? ["", "", line, ""];
      if (!text || text.startsWith("|") || text.startsWith("![")) return line;
      if (text.length > marker.length * 2 && surrounds(text, marker.length, text.length - marker.length, marker)) {
        return before + text.slice(marker.length, -marker.length) + after;
      }
      return before + marker + text + marker + after;
    }).join("\n");
    selectionStart = start;
    selectionEnd = start + replacement.length;
  } else {
    const pattern = start === 0 || value[start - 1] === "\n" ? /^([ \t]*(?:#{1,3}[ \t]+)?)(.*?)([ \t]*)$/ : /^([ \t]*)(.*?)([ \t]*)$/;
    const [, before, text, after] = selected.match(pattern) ?? ["", "", selected, ""];
    replacement = before + marker + text + marker + after;
    selectionStart = start + before.length + marker.length;
    selectionEnd = selectionStart + text.length;
  }
  textarea.setRangeText(replacement, start, end, "end");
  textarea.focus();
  textarea.setSelectionRange(selectionStart, selectionEnd);
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
}
function createFormattingControls(textarea, field) {
  const group = textarea.ownerDocument.createElement("div");
  group.className = "formatting-controls";
  group.setAttribute("role", "group");
  group.setAttribute("aria-label", `Format ${field}`);
  for (const { label, symbol, marker, tag } of formats) {
    const button2 = textarea.ownerDocument.createElement("button");
    button2.type = "button";
    button2.title = label;
    button2.setAttribute("aria-label", label);
    const text = textarea.ownerDocument.createElement(tag);
    text.textContent = symbol;
    button2.append(text);
    button2.addEventListener("click", () => toggleFormatting(textarea, marker));
    group.append(button2);
  }
  textarea.addEventListener("keydown", (event) => {
    if (!(event.ctrlKey || event.metaKey) || event.altKey || event.shiftKey) return;
    const marker = shortcuts.get(event.key.toLowerCase());
    if (!marker) return;
    event.preventDefault();
    toggleFormatting(textarea, marker);
  });
  return group;
}

// node_modules/compendium/src/browser/writer.js
function createEntryEditor(root, writer, saveTarget) {
  const form = root.querySelector("#writer-form");
  const dialog = root.querySelector("#writer-dialog");
  const fields = root.querySelector("#writer-fields");
  const status = root.querySelector("#writer-status");
  const saveButton = form.querySelector('button[type="submit"]');
  const deleteButton = root.querySelector("#writer-delete");
  let currentEdit;
  function imageUpload(textarea, reference, field) {
    const controls = document.createElement("div");
    controls.className = "image-upload";
    const picker = document.createElement("input");
    picker.type = "file";
    picker.accept = Object.keys(imageFormats).join(",");
    picker.hidden = true;
    const button2 = document.createElement("button");
    button2.type = "button";
    button2.textContent = "Upload image";
    button2.setAttribute("aria-label", `Upload image to ${field}`);
    button2.addEventListener("click", () => {
      if (!saveButton.disabled) picker.click();
    });
    picker.addEventListener("change", async () => {
      const file = picker.files[0];
      picker.value = "";
      if (!file || saveButton.disabled) return;
      const original = textarea.value;
      const position = [textarea.selectionStart, textarea.selectionEnd];
      status.textContent = "Uploading image\u2026";
      saveButton.disabled = true;
      deleteButton.disabled = true;
      button2.disabled = true;
      try {
        const { name } = await writer.uploadImage(file, { reference });
        if (!isImageName(name)) throw new Error("The upload did not return a valid image filename.");
        const current = textarea.value;
        const [start, end] = current === original ? position : [textarea.selectionStart, textarea.selectionEnd];
        const caption = file.name.replace(/\.[^.]+$/, "").replace(/[\[\]\r\n]/g, " ").trim();
        const before = start && current[start - 1] !== "\n" ? "\n" : "";
        const after = end < current.length && current[end] !== "\n" ? "\n" : "";
        textarea.setRangeText(`${before}![${caption}](${name})${after}`, start, end, "end");
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
        textarea.focus();
        status.textContent = "";
      } catch (error) {
        status.textContent = error.message;
      } finally {
        saveButton.disabled = false;
        deleteButton.disabled = false;
        button2.disabled = false;
      }
    });
    controls.append(button2, picker);
    return controls;
  }
  function editEntry(reference, title, entry, { afterSave, afterDelete, paragraphFields = [], hideNavigationColor = false }) {
    fields.replaceChildren();
    status.textContent = "";
    root.querySelector("#writer-title").textContent = `Edit ${title}`;
    const controls = [];
    const spellchecks = [];
    for (const [key, value] of Object.entries(entry)) {
      if (key === "id" || value === null || hideNavigationColor && key === "color") continue;
      const label = document.createElement("label");
      label.textContent = key.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/^./, (letter) => letter.toUpperCase());
      const prose = key === "content" || key === "description" || paragraphFields.includes(key);
      const structured = typeof value === "object";
      const input = document.createElement(prose || structured ? "textarea" : "input");
      if (input.tagName === "TEXTAREA") input.rows = prose ? 7 : 3;
      if (typeof value === "boolean") {
        input.type = "checkbox";
        input.checked = value;
      } else {
        input.value = structured ? JSON.stringify(value, null, 2) : String(value);
      }
      if (prose && typeof value === "string") {
        input.id = `writer-field-${controls.length}`;
        label.htmlFor = input.id;
        const formatting = createFormattingControls(input, label.textContent);
        fields.append(label, formatting);
        if (writer.checkSpelling) {
          const spellcheck = createSpellcheckField(input, writer.checkSpelling);
          spellchecks.push(spellcheck);
          fields.append(spellcheck.shell);
        } else {
          fields.append(input);
        }
        if (writer.uploadImage) fields.append(imageUpload(input, reference, label.textContent));
      } else {
        if (structured) input.spellcheck = false;
        label.append(input);
        fields.append(label);
      }
      controls.push({ key, original: input.type === "checkbox" ? input.checked : input.value, value, input });
    }
    currentEdit = { reference, title, controls, spellchecks, afterSave, afterDelete };
    deleteButton.hidden = !afterDelete;
    dialog.showModal();
  }
  form.querySelector('button[type="button"]').addEventListener("click", () => {
    if (!saveButton.disabled) dialog.close();
  });
  dialog.addEventListener("cancel", (event) => {
    if (saveButton.disabled) event.preventDefault();
  });
  dialog.addEventListener("close", () => {
    if (dialog.open) return;
    for (const spellcheck of currentEdit?.spellchecks ?? []) spellcheck.dispose();
  });
  async function submitChange(operation, body, onSuccess) {
    saveButton.disabled = true;
    deleteButton.disabled = true;
    try {
      const data = await operation(body);
      dialog.close();
      onSuccess(data);
    } catch (error) {
      status.textContent = error.message;
    } finally {
      saveButton.disabled = false;
      deleteButton.disabled = false;
    }
  }
  deleteButton.addEventListener("click", () => {
    if (!currentEdit?.afterDelete || saveButton.disabled) return;
    const { title, reference, afterDelete } = currentEdit;
    if (!window.confirm(`Delete "${title}" from ${saveTarget}?`)) return;
    status.textContent = "";
    submitChange(writer.deleteAbility, reference, afterDelete);
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!currentEdit || saveButton.disabled) return;
    status.textContent = "";
    const values = /* @__PURE__ */ Object.create(null);
    try {
      for (const { key, original, value, input } of currentEdit.controls) {
        const edited = input.type === "checkbox" ? input.checked : input.value;
        if (edited === original) continue;
        if (typeof value === "number" && (!edited.trim() || !Number.isFinite(Number(edited)))) {
          throw new Error(`Enter a number for "${key}".`);
        }
        if (typeof value === "object") {
          try {
            values[key] = JSON.parse(edited);
          } catch {
            throw new Error(`Enter valid JSON for "${key}".`);
          }
        } else {
          values[key] = typeof value === "number" ? Number(edited) : edited;
        }
      }
      if (Object.keys(values).length) {
        submitChange(writer.saveEntry, { reference: currentEdit.reference, values }, currentEdit.afterSave);
      } else {
        dialog.close();
      }
    } catch (error) {
      status.textContent = error.message;
    }
  });
  return { editEntry, dispose() {
    for (const spellcheck of currentEdit?.spellchecks ?? []) spellcheck.dispose();
  } };
}

// node_modules/compendium/src/navigation.js
var types = ["normal", "grid", "table", "classes"];
function item(id, title, color, value) {
  return { id, title, color, value };
}
function listPages(pages) {
  return pages.map((page) => item(page.id, page.title, page.color, page));
}
function groupedSections(sections) {
  const groups = /* @__PURE__ */ new Map();
  for (const section of sections) {
    const group = section.navigationGroup ?? section;
    if (!groups.has(group.id)) groups.set(group.id, item(group.id, group.title, group.color, []));
    groups.get(group.id).value.push(section);
  }
  return [...groups.values()];
}
function collectionFor(data, page) {
  return data.collections?.find((collection) => collection.id === page.collectionId);
}
function setEntries(data, page, entries) {
  const collection = collectionFor(data, page);
  const users = data.tabs.flatMap((tab) => [tab, ...tab.sections ?? []]).filter((view) => view.collectionId === page.collectionId);
  if (collection && users.length === 1) {
    collection.entries = entries;
    return;
  }
  const id = `collection-${crypto.randomUUID()}`;
  page.collectionId = id;
  (data.collections ??= []).push({ id, entries });
}
function updateClassList(tab, previous, next, kind) {
  const labels = tab.classPageLabels ??= {};
  const colors = tab.classPageColors ??= {};
  const names = labels[`${kind}Labels`] ??= {};
  const accents = colors[kind] ??= {};
  for (const entry of previous) {
    delete names[entry.id];
    delete accents[entry.id];
  }
  for (const entry of next) {
    Object.defineProperty(names, entry.id, { value: entry.title, enumerable: true, configurable: true, writable: true });
    if (entry.color) {
      Object.defineProperty(accents, entry.id, { value: entry.color, enumerable: true, configurable: true, writable: true });
    }
  }
}
function discardRemovedClassAbilities(data, tab, before) {
  const after = new Set(tab.classPageStructure.groups.flatMap((group) => group.classes));
  const removed = new Set(before.filter((id) => !after.has(id)));
  const entries = collectionFor(data, tab)?.entries;
  if (removed.size && entries?.some((entry) => removed.has(entry.class))) {
    setEntries(data, tab, entries.filter((entry) => !removed.has(entry.class)));
  }
}
function classLevel(data, tab, groupId) {
  const groups = tab.classPageStructure.groups;
  const before = groups.flatMap((group2) => group2.classes);
  const labels = tab.classPageLabels;
  const colors = tab.classPageColors;
  if (groupId === void 0) {
    const items2 = groups.map((group2) => item(
      group2.key,
      labels?.groupLabels?.[group2.key] ?? group2.key,
      colors?.group?.[group2.key],
      group2
    ));
    return {
      items: items2,
      create: (id) => ({ key: id, classes: [] }),
      commit(next) {
        tab.classPageStructure.groups = next.map((entry) => entry.value);
        updateClassList(tab, items2, next, "group");
        discardRemovedClassAbilities(data, tab, before);
      }
    };
  }
  const group = groups.find((candidate) => candidate.key === groupId);
  if (!group) return null;
  const items = group.classes.map((id) => item(id, labels?.classLabels?.[id] ?? id, colors?.class?.[id], id));
  return {
    items,
    create: (id) => id,
    commit(next) {
      group.classes = next.map((entry) => entry.value);
      const remaining = new Set(tab.classPageStructure.groups.flatMap((candidate) => candidate.classes));
      updateClassList(tab, items.filter((entry) => !remaining.has(entry.id)), next, "class");
      for (const entry of next) {
        if (!entry.color && tab.classPageColors?.class) delete tab.classPageColors.class[entry.id];
      }
      discardRemovedClassAbilities(data, tab, before);
    }
  };
}
function levelFor(data, path) {
  const [tabId, subtabId] = path;
  if (!path.length) {
    return {
      items: listPages(data.tabs),
      types,
      create: (id, type) => type === "classes" ? { id, type, classPageStructure: { groups: [] } } : { id, type, sections: [] },
      commit: (next) => {
        data.tabs = next.map((entry) => ({ ...entry.value, title: entry.title, color: entry.color }));
      }
    };
  }
  const tab = data.tabs.find((candidate) => candidate.id === tabId);
  if (!tab) return null;
  if (tab.type === "classes" && tab.classPageStructure) return classLevel(data, tab, subtabId);
  const groups = groupedSections(tab.sections ?? []);
  if (path.length === 1) {
    return {
      items: groups,
      types: types.slice(0, 3),
      create: (id, type) => [{ id, type }],
      commit: (next) => {
        tab.sections = next.flatMap((entry) => entry.value.map((section2) => section2.navigationGroup ? { ...section2, navigationGroup: { id: entry.id, title: entry.title, color: entry.color } } : { ...section2, title: entry.title, color: entry.color }));
      }
    };
  }
  const sections = groups.find((group) => group.id === subtabId)?.value;
  if (sections?.length !== 1 || (sections[0].type ?? tab.type ?? "normal") !== "normal") return null;
  const section = sections[0];
  const titleKey = (entry) => Object.hasOwn(entry, "title") ? "title" : "name";
  return {
    items: (collectionFor(data, section)?.entries ?? []).map((entry) => item(entry.id, entry[titleKey(entry)] ?? entry.id, entry.color, entry)),
    create: (id) => ({ id, title: "", content: "" }),
    commit: (next) => setEntries(data, section, next.map((entry) => ({
      ...entry.value,
      [titleKey(entry.value)]: entry.title,
      color: entry.color
    })))
  };
}
function getNavigation(data, path = []) {
  const level = levelFor(data, path);
  if (!level) return null;
  return {
    types: level.types,
    items: level.items.map(({ id, title, color }) => ({
      id,
      title,
      color,
      children: path.length < 2 ? getNavigation(data, [...path, id]) : null
    }))
  };
}

// node_modules/compendium/src/browser/navigation.js
var levels = ["tab", "subtab", "category"];
function button(text, label, click) {
  const control = document.createElement("button");
  control.type = "button";
  control.textContent = text;
  control.setAttribute("aria-label", label);
  control.addEventListener("click", click);
  return control;
}
function createNavigationEditor(root, getConfiguration, onSaved, changeNavigation, saveTarget) {
  const dialog = root.querySelector("#navigation-dialog");
  const form = root.querySelector("#navigation-form");
  const name = root.querySelector("#navigation-name");
  const color = root.querySelector("#navigation-color");
  const useDefault = root.querySelector("#navigation-default-color");
  const type = root.querySelector("#navigation-type");
  const status = root.querySelector("#navigation-status");
  const announcement = root.querySelector("#writer-announcement");
  const cancel = root.querySelector("#navigation-cancel");
  const submit = root.querySelector("#navigation-save");
  let edit;
  let busy = false;
  function openForm(path, current) {
    if (busy) return;
    const level = levels[path.length];
    const capitalized = level[0].toUpperCase() + level.slice(1);
    edit = { path, id: current?.id, action: current ? "rename" : "add" };
    root.querySelector("#navigation-title").textContent = current ? `Edit ${level}` : `Add ${level}`;
    root.querySelector("#navigation-name-label").textContent = `${capitalized} name`;
    name.value = current?.title ?? "";
    color.value = current?.color || "#805b34";
    useDefault.checked = !current?.color;
    const options = current ? [] : getNavigation(getConfiguration(), path)?.types ?? [];
    type.replaceChildren(...options.map((value) => new Option(value[0].toUpperCase() + value.slice(1), value)));
    type.closest("label").hidden = !options.length;
    status.textContent = "";
    dialog.showModal();
    name.focus();
  }
  async function save(change) {
    if (busy) return;
    busy = true;
    submit.disabled = true;
    cancel.disabled = true;
    announcement.textContent = "";
    status.textContent = "";
    const before = change.action === "add" ? new Set(getNavigation(getConfiguration(), change.path).items.map((item2) => item2.id)) : null;
    try {
      const data = await changeNavigation(change);
      if (dialog.open) dialog.close();
      const added = before && getNavigation(data, change.path).items.find((item2) => !before.has(item2.id));
      onSaved(data, added && { path: change.path, id: added.id });
      const list = [...root.querySelectorAll("[data-navigation-path]")].find((node) => node.dataset.navigationPath === JSON.stringify(change.path));
      const focusId = added?.id ?? (change.action === "remove" ? void 0 : change.id);
      const focus = [...list?.querySelectorAll("[data-navigation-id]") ?? []].find((node) => node.dataset.navigationId === focusId);
      (focus ?? list?.querySelector('[aria-pressed="true"]'))?.focus();
      announcement.textContent = `Navigation saved to ${saveTarget}.`;
    } catch (error) {
      if (dialog.open) status.textContent = error.message;
      else announcement.textContent = error.message;
    } finally {
      busy = false;
      submit.disabled = false;
      cancel.disabled = false;
    }
  }
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    save({ ...edit, title: name.value, color: useDefault.checked ? "" : color.value, type: type.value });
  });
  color.addEventListener("input", () => {
    useDefault.checked = false;
  });
  cancel.addEventListener("click", () => dialog.close());
  dialog.addEventListener("cancel", (event) => {
    if (busy) event.preventDefault();
  });
  return {
    attach(list, path, controls, options, current) {
      const level = levels[path.length];
      list.dataset.navigationPath = JSON.stringify(path);
      let dragging;
      for (const [index, { control, id }] of options.entries()) {
        control.dataset.navigationId = id;
        control.classList.add("draggable-navigation");
        control.draggable = true;
        control.title = "Drag to reorder, or press Alt and an arrow key";
        control.ondragstart = (event) => {
          dragging = id;
          control.classList.add("is-dragging");
          event.dataTransfer.setData("text/plain", id);
          event.dataTransfer.effectAllowed = "move";
        };
        control.ondragend = () => {
          dragging = void 0;
          control.classList.remove("is-dragging");
          for (const option of options) option.control.classList.remove("navigation-drop-target");
        };
        control.ondragover = (event) => {
          if (!dragging || dragging === id) return;
          event.preventDefault();
          event.dataTransfer.dropEffect = "move";
          control.classList.add("navigation-drop-target");
        };
        control.ondragleave = () => control.classList.remove("navigation-drop-target");
        control.ondrop = (event) => {
          if (!dragging || dragging === id) return;
          event.preventDefault();
          save({ action: "move", path, id: dragging, targetId: id });
        };
        control.onkeydown = (event) => {
          if (!event.altKey) return;
          const direction = ["ArrowLeft", "ArrowUp"].includes(event.key) ? -1 : ["ArrowRight", "ArrowDown"].includes(event.key) ? 1 : 0;
          if (!direction) return;
          event.preventDefault();
          if (options[index + direction]) save({ action: "move", path, id, direction });
        };
      }
      const add = button("Add", `Add ${level}`, () => openForm(path));
      const editButton = button("Edit", `Edit ${level}`, () => openForm(path, current));
      const remove = button("Remove", `Remove ${level}`, () => {
        if (window.confirm(`Remove "${current.title}" and its contents from ${saveTarget}?`)) {
          save({ action: "remove", path, id: current.id });
        }
      });
      editButton.disabled = !current;
      remove.disabled = !current;
      const row = document.createElement("div");
      row.className = "navigation-actions";
      row.setAttribute("role", "group");
      row.setAttribute("aria-label", `${level} writer tools`);
      row.append(add, editButton, remove);
      controls.replaceChildren(row);
    }
  };
}

// node_modules/compendium/src/browser/search.js
var originalTabs = /* @__PURE__ */ new Set(["lore", "classes", "equipment", "conditions"]);
function searchText(values) {
  if (Array.isArray(values)) return values.map(searchText).join(" ");
  if (values && typeof values === "object") return searchText(Object.values(values));
  return String(values ?? "");
}
function equipmentTerms(entry, sectionId) {
  switch (sectionId) {
    case "weapons":
      return [entry.type, entry.damage?.type, entry.properties];
    case "armors":
    case "shields":
      return [entry.properties];
    case "generalItems":
      return [entry.description, entry.amountCharges, entry.cost];
    case "equipmentProperties":
      return [entry.description];
    default:
      return Object.values(entry);
  }
}
function searchCompendium(compendium, input) {
  const query = input.trim().toLowerCase();
  if (!query) return [];
  const results = [];
  function add(title, meta, target, terms = [], prefix = []) {
    const lowerTitle = title.toLowerCase();
    const index = searchText([...prefix, title, ...terms]).toLowerCase().indexOf(query);
    if (index < 0) return;
    const score = lowerTitle === query ? 0 : lowerTitle.startsWith(query) ? 1 : index + 2;
    results.push({ title, meta, target, score });
  }
  function addEntry(entry, view, target, meta, terms, prefix) {
    const key = view.fields?.find((field) => field.isTitle)?.key;
    const title = String(entry[key] ?? entry.title ?? entry.name ?? entry.id);
    add(title, meta, { ...target, entryId: entry.id }, terms, prefix);
  }
  for (const tab of compendium.tabs) {
    const tabTarget = { tabId: tab.id };
    const isCustom = !originalTabs.has(tab.id);
    if (isCustom) {
      const type = tab.type.charAt(0).toUpperCase() + tab.type.slice(1);
      const target = tab.type === "normal" && tab.sections.length ? { ...tabTarget, sectionId: tab.sections[0].id } : tabTarget;
      add(tab.title, `${type} Tab`, target);
    }
    const groups = tab.classPageStructure?.groups ?? [];
    if (tab.type === "classes" && groups.length) {
      const members = /* @__PURE__ */ new Map();
      for (const group of groups) {
        const groupLabel = tab.classPageLabels?.groupLabels?.[group.key] ?? group.key;
        for (const id of group.classes) {
          const title = tab.classPageLabels?.classLabels?.[id] ?? id;
          const target = { ...tabTarget, groupId: group.key, classId: id };
          add(title, "Class", target, [groupLabel, id, group.key]);
          members.set(id, { title, target });
        }
      }
      for (const ability of tab.entries) {
        const member = members.get(ability.class);
        if (member) {
          addEntry(
            ability,
            tab,
            member.target,
            `${member.title} Ability`,
            [member.title, ability.class, ability.description, ability.type]
          );
        }
      }
    } else {
      for (const entry of tab.entries) {
        const terms = tab.id === "conditions" ? [entry.description] : Object.values(entry);
        addEntry(entry, tab, tabTarget, tab.id === "conditions" ? "Condition" : tab.title, terms);
      }
    }
    for (const section of tab.sections) {
      const target = { ...tabTarget, sectionId: section.id };
      if (tab.id !== "equipment") {
        add(
          section.title,
          tab.id === "lore" ? "Lore Category" : tab.title,
          target,
          [],
          isCustom ? [tab.title] : []
        );
      }
      for (const entry of section.entries) {
        if (tab.id === "equipment") {
          addEntry(entry, section, target, section.title, [section.title, ...equipmentTerms(entry, section.id)]);
        } else if (tab.id === "lore") {
          addEntry(entry, section, target, section.title, [entry.content ?? entry.description]);
        } else {
          addEntry(
            entry,
            section,
            target,
            `${tab.title} / ${section.title}`,
            section.type === "normal" ? [entry.content ?? entry.description] : Object.values(entry),
            [tab.title, section.title]
          );
        }
      }
    }
  }
  return results.sort((a, b) => a.score - b.score || a.title.localeCompare(b.title)).slice(0, 12);
}

// node_modules/compendium/src/browser/markup.js
var markup = `
<main>
    <header>
      <h1></h1>
      <div class="compendium-search">
        <label for="search">Search
          <input id="search" type="search" placeholder="Search the compendium" aria-controls="search-results" disabled>
        </label>
        <div id="search-results" role="region" aria-label="Search results" hidden></div>
      </div>
    </header>
    <div id="tab-navigation">
      <nav id="tabs" aria-label="Compendium sections"></nav>
      <div id="tab-writer-actions"></div>
    </div>
    <div id="subtabs"></div>
    <div id="content" aria-live="polite">Loading compendium\u2026</div>
    <p id="writer-announcement" role="status"></p>
  </main>
  <dialog id="writer-dialog" aria-labelledby="writer-title">
    <form id="writer-form">
      <h2 id="writer-title">Edit entry</h2>
      <p id="writer-notice"></p>
      <div id="writer-fields"></div>
      <p id="writer-status" role="alert"></p>
      <div class="entry-actions">
        <button type="button">Cancel</button>
        <button type="submit">Save</button>
        <button id="writer-delete" type="button" hidden>Delete</button>
      </div>
    </form>
  </dialog>
  <dialog id="navigation-dialog" aria-labelledby="navigation-title">
    <form id="navigation-form" class="navigation-form">
      <h2 id="navigation-title"></h2>
      <label><span id="navigation-name-label">Name</span>
        <input id="navigation-name" required maxlength="120">
      </label>
      <label>Page type <select id="navigation-type"></select></label>
      <div class="navigation-colors">
        <label>Color <input id="navigation-color" type="color"></label>
        <label>Use default color <input id="navigation-default-color" type="checkbox"></label>
      </div>
      <p id="navigation-status" role="alert"></p>
      <div class="entry-actions">
        <button id="navigation-cancel" type="button">Cancel</button>
        <button id="navigation-save" type="submit">Save</button>
      </div>
    </form>
  </dialog>
  <dialog id="style-guide" aria-labelledby="style-guide-title">
    <form id="style-guide-form">
      <h2 id="style-guide-title">Style Guide</h2>
      <div class="style-guide-row style-guide-labels" aria-hidden="true">
        <span>Preview</span><span>Font</span><span>Size (px)</span><span>Color</span>
      </div>
      <div id="style-guide-fields"></div>
      <p id="style-guide-status" role="alert"></p>
      <div class="entry-actions">
        <button id="style-guide-cancel" type="button">Cancel</button>
        <button id="style-guide-save" type="submit">Save</button>
      </div>
    </form>
  </dialog>

`;

// node_modules/compendium/src/browser/references.js
var normalize = (value) => String(value ?? "").trim().toLowerCase().replace(/\s*\/\s*/g, " / ");
function createPageReferences(compendium) {
  const names = /* @__PURE__ */ new Map();
  function add(title, path, target, location) {
    for (const key of /* @__PURE__ */ new Set([normalize(title), normalize(path.join(" / "))])) {
      if (!key) continue;
      if (!names.has(key)) names.set(key, []);
      names.get(key).push({ target, location });
    }
  }
  for (const tab of compendium.tabs) {
    const tabTarget = { tabId: tab.id };
    const tabLocation = { tab: tab.id };
    add(tab.title, [tab.title], tabTarget, tabLocation);
    const classGroups = tab.type === "classes" ? tab.classPageStructure?.groups ?? [] : [];
    const classes = /* @__PURE__ */ new Map();
    for (const group of classGroups) {
      const label = tab.classPageLabels?.groupLabels?.[group.key] ?? group.key;
      const groupTarget = { ...tabTarget, groupId: group.key };
      const groupLocation = { ...tabLocation, subtab: group.key };
      add(label, [tab.title, label], groupTarget, groupLocation);
      for (const id of group.classes) {
        const title = tab.classPageLabels?.classLabels?.[id] ?? id;
        const path = [tab.title, label, title];
        const target = { ...groupTarget, classId: id };
        const location = { ...groupLocation, entry: id };
        add(title, path, target, location);
        if (!classes.has(id)) classes.set(id, { path, target, location });
      }
    }
    for (const entry of tab.entries) {
      const parent = classes.get(entry.class);
      if (classGroups.length && !parent) continue;
      const title = titleFor(tab, entry);
      add(
        title,
        [...parent?.path ?? [tab.title], title],
        { ...parent?.target ?? tabTarget, entryId: entry.id },
        parent?.location ?? tabLocation
      );
    }
    const navigationGroups = /* @__PURE__ */ new Set();
    for (const section of tab.sections) {
      const subtab = section.navigationGroup ?? section;
      const sectionTarget = { ...tabTarget, sectionId: section.id };
      const sectionLocation = { ...tabLocation, subtab: subtab.id };
      if (!navigationGroups.has(subtab.id)) {
        add(subtab.title, [tab.title, subtab.title], sectionTarget, sectionLocation);
        navigationGroups.add(subtab.id);
      }
      if (section.title !== subtab.title) {
        add(section.title, [tab.title, subtab.title, section.title], sectionTarget, sectionLocation);
      }
      for (const entry of section.entries) {
        const title = titleFor(section, entry);
        const location = section.type === "normal" ? { ...sectionLocation, entry: entry.id } : sectionLocation;
        add(title, [tab.title, subtab.title, title], { ...sectionTarget, entryId: entry.id }, location);
      }
    }
  }
  return (name, origin = {}) => {
    const matches = names.get(normalize(name)) ?? [];
    return matches.find((match) => match.target.tabId === origin.tabId && match.target.sectionId === origin.sectionId) ?? matches.find((match) => match.target.tabId === origin.tabId) ?? matches[0];
  };
}
function titleFor(page, entry) {
  const key = page.fields?.find((field) => field.isTitle)?.key;
  return String(entry[key] ?? entry.title ?? entry.name ?? entry.id);
}

// node_modules/compendium/src/typography.js
var typographyRoles = {
  title: "Compendium title",
  pageTitle: "Page titles",
  entryTitle: "Entry and class titles",
  sectionHeading: "Section and rank headings",
  heading1: "Text heading 1 (#)",
  heading2: "Text heading 2 (##)",
  heading3: "Text heading 3 (###)"
};
var typographyFonts = {
  system: { label: "System", family: "system-ui, sans-serif" },
  georgia: { label: "Georgia", family: "Georgia, serif" },
  times: { label: "Times New Roman", family: '"Times New Roman", serif' },
  arial: { label: "Arial", family: "Arial, sans-serif" },
  verdana: { label: "Verdana", family: "Verdana, sans-serif" },
  monospace: { label: "Monospace", family: "monospace" }
};
var typographySize = { min: 10, max: 72 };
function normalizeTypography(settings = {}) {
  if (!settings || typeof settings !== "object" || Array.isArray(settings)) {
    throw new TypeError("Choose valid typography settings.");
  }
  const normalized = {};
  for (const [role, style] of Object.entries(settings)) {
    if (!Object.hasOwn(typographyRoles, role) || !style || typeof style !== "object" || Array.isArray(style)) {
      throw new TypeError("Choose a valid typography role.");
    }
    const { font, size, color } = style;
    if (font !== void 0 && (typeof font !== "string" || !Object.hasOwn(typographyFonts, font))) {
      throw new TypeError("Choose a font from the Style Guide.");
    }
    if (size !== void 0 && (!Number.isInteger(size) || size < typographySize.min || size > typographySize.max)) {
      throw new TypeError(`Choose a whole font size from ${typographySize.min} to ${typographySize.max} pixels.`);
    }
    if (color !== void 0 && (typeof color !== "string" || !/^#[\da-f]{6}$/i.test(color))) {
      throw new TypeError("Choose a valid text color.");
    }
    if (font !== void 0 || size !== void 0 || color !== void 0) {
      normalized[role] = {
        ...font === void 0 ? {} : { font },
        ...size === void 0 ? {} : { size },
        ...color === void 0 ? {} : { color: color.toLowerCase() }
      };
    }
  }
  return normalized;
}

// node_modules/compendium/src/browser/style-guide.js
function applyHeadingStyle(heading, { font, size, color } = {}) {
  heading.style.fontFamily = typographyFonts[font]?.family ?? "";
  heading.style.fontSize = size === void 0 ? "" : `${size}px`;
  heading.style.color = color ?? "";
  return heading;
}
function createStyleGuide(root, saveTypography, onSaved) {
  const dialog = root.querySelector("#style-guide");
  const form = root.querySelector("#style-guide-form");
  const fields = root.querySelector("#style-guide-fields");
  const status = root.querySelector("#style-guide-status");
  const save = root.querySelector("#style-guide-save");
  const cancel = root.querySelector("#style-guide-cancel");
  const controls = /* @__PURE__ */ new Map();
  for (const [role, label] of Object.entries(typographyRoles)) {
    let updateSample = function() {
      const px = size.valueAsNumber;
      const validSize = Number.isInteger(px) && px >= typographySize.min && px <= typographySize.max;
      applyHeadingStyle(sample, {
        font: font.value,
        size: validSize ? px : void 0,
        color: state.customColor
      });
      resetSize.disabled = size.value === "";
      resetColor.disabled = state.customColor === void 0;
    };
    const row = document.createElement("div");
    row.className = "style-guide-row";
    const sample = document.createElement("span");
    sample.textContent = label;
    sample.className = "style-guide-sample";
    const font = document.createElement("select");
    font.setAttribute("aria-label", `${label} font`);
    font.append(new Option("Default", ""));
    for (const [key, { label: fontLabel }] of Object.entries(typographyFonts)) {
      font.append(new Option(fontLabel, key));
    }
    const size = document.createElement("input");
    size.type = "number";
    size.min = typographySize.min;
    size.max = typographySize.max;
    size.step = "1";
    size.placeholder = "Default";
    size.setAttribute("aria-label", `${label} size (px)`);
    const resetSize = document.createElement("button");
    resetSize.type = "button";
    resetSize.textContent = "Reset";
    resetSize.setAttribute("aria-label", `Reset ${label} size`);
    const sizeControl = document.createElement("div");
    sizeControl.className = "style-guide-control";
    sizeControl.append(size, resetSize);
    const color = document.createElement("input");
    color.type = "color";
    color.setAttribute("aria-label", `${label} color`);
    const resetColor = document.createElement("button");
    resetColor.type = "button";
    resetColor.textContent = "Default";
    resetColor.setAttribute("aria-label", `Use default color for ${label}`);
    const colorControl = document.createElement("div");
    colorControl.className = "style-guide-control";
    colorControl.append(color, resetColor);
    const state = { font, size, color, customColor: void 0, updateSample };
    font.addEventListener("change", updateSample);
    size.addEventListener("input", updateSample);
    resetSize.addEventListener("click", () => {
      size.value = "";
      updateSample();
    });
    color.addEventListener("input", () => {
      state.customColor = color.value;
      updateSample();
    });
    resetColor.addEventListener("click", () => {
      state.customColor = void 0;
      color.value = "#28241d";
      updateSample();
    });
    row.append(sample, font, sizeControl, colorControl);
    fields.append(row);
    controls.set(role, state);
  }
  function show(settings) {
    status.textContent = "";
    for (const [role, state] of controls) {
      const { font, size, color, updateSample } = state;
      font.value = settings[role]?.font ?? "";
      size.value = settings[role]?.size ?? "";
      state.customColor = settings[role]?.color;
      color.value = state.customColor ?? "#28241d";
      updateSample();
    }
    dialog.showModal();
  }
  cancel.addEventListener("click", () => dialog.close());
  dialog.addEventListener("cancel", (event) => {
    if (save.disabled) event.preventDefault();
  });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (save.disabled) return;
    status.textContent = "";
    save.disabled = true;
    cancel.disabled = true;
    try {
      const settings = {};
      for (const [role, { font, size, customColor }] of controls) {
        settings[role] = {
          font: font.value || void 0,
          size: size.value ? size.valueAsNumber : void 0,
          color: customColor
        };
      }
      const configuration = await saveTypography(normalizeTypography(settings));
      dialog.close();
      onSaved(configuration);
    } catch (error) {
      status.textContent = error.message;
    } finally {
      save.disabled = false;
      cancel.disabled = false;
    }
  });
  return { show };
}

// node_modules/compendium/src/browser/index.js
function mountCompendium(container, configuration, {
  title = "Compendium",
  projectId = configuration.id ?? "local",
  routing = false,
  stylesheets = [],
  imageBaseUrl,
  writer = {},
  saveTarget = "this compendium"
} = {}) {
  const host2 = document.createElement("div");
  const root = host2.attachShadow({ mode: "open" });
  root.innerHTML = markup;
  const titleHeading = root.querySelector("h1");
  titleHeading.textContent = title;
  let typography = normalizeTypography(configuration.typography);
  applyHeadingStyle(titleHeading, typography.title);
  root.querySelector("#writer-notice").textContent = `Changes are saved to ${saveTarget}.`;
  for (const href of [new URL("/games/PyrrhicWar/compendium-reader.css", document.baseURI), ...stylesheets]) {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    root.insertBefore(link, root.querySelector("main"));
  }
  container.append(host2);
  const tabs = root.querySelector("#tabs");
  const subtabs = root.querySelector("#subtabs");
  const content = root.querySelector("#content");
  const search = root.querySelector("#search");
  const searchResults = root.querySelector("#search-results");
  const tabWriterActions = root.querySelector("#tab-writer-actions");
  function element(tag, text) {
    const node = document.createElement(tag);
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function styledHeading(tag, text, role) {
    return applyHeadingStyle(element(tag, text), typography[role]);
  }
  function titleFor2(key) {
    const words = key.replace(/([a-z])([A-Z])/g, "$1 $2");
    return words.charAt(0).toUpperCase() + words.slice(1);
  }
  function display(value) {
    if (value === null || value === void 0) return "";
    if (Array.isArray(value)) return value.map(display).join(", ");
    if (typeof value === "object") return Object.values(value).map(display).join(" ");
    if (typeof value === "boolean") return value ? "Yes" : "No";
    return String(value);
  }
  function columnsFor(page, entries) {
    if (page.columns?.length) return page.columns;
    const keys = new Set(entries.flatMap((entry) => Object.keys(entry)));
    keys.delete("id");
    return [...keys].map((key) => ({ key, label: titleFor2(key) }));
  }
  function renderTable(page, entries, favorite, origin) {
    const wrapper = element("div");
    wrapper.className = "table-container";
    const table = element("table");
    table.setAttribute("aria-label", page.title);
    const header = table.createTHead().insertRow();
    const columns = columnsFor(page, entries);
    for (const { key, label } of columns) {
      const cell = element("th", label ?? titleFor2(key));
      cell.scope = "col";
      header.append(cell);
    }
    const favoritesColumn = element("th", "Favorite");
    favoritesColumn.scope = "col";
    header.append(favoritesColumn);
    const body = table.createTBody();
    for (const entry of entries) {
      const row = body.insertRow();
      for (const { key } of columns) renderInline(row.insertCell(), display(entry[key]), origin);
      row.insertCell().append(favorite(entry));
    }
    wrapper.append(table);
    return wrapper;
  }
  const imageBase = imageBaseUrl ? new URL(imageBaseUrl, document.baseURI) : null;
  if (imageBase) imageBase.pathname = imageBase.pathname.replace(/\/?$/, "/");
  let findReference;
  let followReference;
  function renderInline(node, text, origin) {
    return appendInline(node, text, (name) => {
      const reference = findReference?.(name, origin);
      if (!reference) return null;
      const link = element(routing ? "a" : "button", name.trim());
      link.className = "inline-reference";
      if (routing) link.href = pageUrl(reference.location).href;
      else link.type = "button";
      link.addEventListener("click", (event) => {
        if (routing && (event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey)) return;
        event.preventDefault();
        followReference(reference.target);
      });
      return link;
    });
  }
  function renderImage(line, origin) {
    const match = line.match(/^!\[([^\]]*)\]\(([^)\s]+)\)$/);
    if (!match || !imageBase || !isImageName(match[2])) return null;
    const [, caption, name] = match;
    const figure = element("figure");
    figure.className = "compendium-image";
    const image = element("img");
    image.src = new URL(encodeURIComponent(name), imageBase).href;
    image.alt = caption;
    image.loading = "lazy";
    figure.append(image);
    if (caption) figure.append(renderInline(element("figcaption"), caption, origin));
    return figure;
  }
  function renderProse(source, parentHeading, origin, favoriteBlock) {
    const body = element("div");
    body.className = "prose";
    let paragraph = [];
    let tableRows = [];
    let blockIndex = 0;
    function addBlock(node, excerpt = node.textContent) {
      if (!favoriteBlock) {
        body.append(node);
        return;
      }
      const block = element("div");
      block.className = "favorite-block";
      block.append(node, favoriteBlock(blockIndex++, excerpt.trim().slice(0, 300)));
      body.append(block);
    }
    function flushParagraph() {
      if (!paragraph.length) return;
      addBlock(renderInline(element("p"), paragraph.join("\n"), origin));
      paragraph = [];
    }
    function flushTable() {
      if (!tableRows.length) return;
      const wrapper = element("div");
      wrapper.className = "table-container";
      const table = element("table");
      const [columns, ...rows] = tableRows;
      const header = table.createTHead().insertRow();
      for (const label of columns) {
        const cell = renderInline(element("th"), label, origin);
        cell.scope = "col";
        header.append(cell);
      }
      const body2 = table.createTBody();
      for (const values of rows) {
        if (values.every((value) => /^:?-{3,}:?$/.test(value))) continue;
        const row = body2.insertRow();
        for (const value of values) renderInline(row.insertCell(), value, origin);
      }
      wrapper.append(table);
      addBlock(wrapper, tableRows.map((values) => values.join(" | ")).join("\n"));
      tableRows = [];
    }
    for (const line of source.split(/\r?\n/)) {
      const trimmed = line.trim();
      const cells = trimmed.startsWith("|") ? trimmed.slice(1).replace(/\|$/, "").split("|").map((cell) => cell.trim()) : [];
      if (cells.length > 1) {
        flushParagraph();
        tableRows.push(cells);
        continue;
      }
      flushTable();
      const figure = renderImage(trimmed, origin);
      if (figure) {
        flushParagraph();
        addBlock(figure, trimmed);
        continue;
      }
      const title2 = trimmed.match(/^(#{1,3})[ \t]+(.+)$/);
      if (title2) {
        flushParagraph();
        const level = title2[1].length;
        const heading = renderInline(styledHeading(`h${Math.min(6, Number(parentHeading.slice(1)) + level)}`, "", `heading${level}`), title2[2], origin);
        heading.className = `prose-title prose-title-${level}`;
        addBlock(heading);
      } else if (trimmed) {
        paragraph.push(line);
      } else {
        flushParagraph();
      }
    }
    flushParagraph();
    flushTable();
    return body;
  }
  function entryTitle(page, entry) {
    const titleField = page.fields?.find((field) => field.isTitle)?.key;
    return display(entry[titleField] ?? entry.title ?? entry.name ?? entry.id);
  }
  function renderCard(page, entry, headingLevel, favorite, origin, rankedAbility = false) {
    const card = element("article");
    const titleField = page.fields?.find((field) => field.isTitle)?.key;
    const header = element("div");
    header.className = "favorite-block";
    header.append(styledHeading(headingLevel, entryTitle(page, entry), "entryTitle"), favorite(entry));
    card.append(header);
    if (rankedAbility) {
      const metadata = [
        entry.actionCost == null ? "" : `Action ${display(entry.actionCost)}`,
        entry.enduranceCost == null ? "" : `Endurance ${display(entry.enduranceCost)}`,
        display(entry.type)
      ].filter(Boolean);
      if (metadata.length) {
        const line = element("p", metadata.join(" | "));
        line.className = "ability-meta";
        card.append(line);
      }
    }
    const renderField = (value, field) => renderProse(value, headingLevel, origin, (index, excerpt) => favorite(entry, { field, index, excerpt }));
    if (typeof entry.content === "string") {
      card.append(renderField(entry.content, "content"));
    } else if (typeof entry.description === "string" && entry.description) {
      card.append(renderProse(entry.description, headingLevel, origin));
    } else if (entry.content ?? entry.description) {
      const text = element("p", display(entry.content ?? entry.description));
      text.className = "prose";
      card.append(text);
    }
    const hiddenFields = /* @__PURE__ */ new Set(["id", "name", "title", "content", "description", titleField]);
    if (rankedAbility) {
      for (const key of ["class", "rank", "actionCost", "enduranceCost", "type"]) hiddenFields.add(key);
    }
    if (page.type === "normal" && origin.sectionId !== void 0) hiddenFields.add("color");
    const fields = page.fields ?? Object.keys(entry).map((key) => ({ key }));
    const details = element("dl");
    for (const { key, label, type } of fields) {
      if (hiddenFields.has(key) || entry[key] === void 0) continue;
      const value = element("dd");
      if (type === "paragraph" && typeof entry[key] === "string") {
        value.append(renderField(entry[key], key));
      } else {
        value.textContent = display(entry[key]);
      }
      details.append(element("dt", label ?? titleFor2(key)), value);
    }
    if (details.childElementCount) card.append(details);
    return card;
  }
  function entryFavorite(page, favoriteButton, tabId, sectionId) {
    return (entry, block) => favoriteButton(
      { tabId, sectionId, entryId: entry.id, block },
      block ? block.excerpt || entryTitle(page, entry) : entryTitle(page, entry)
    );
  }
  function renderEntries(page, entries, headingLevel, favoriteButton, tabId, sectionId) {
    const favorite = entryFavorite(page, favoriteButton, tabId, sectionId);
    if (page.type === "table") return renderTable(page, entries, favorite, { tabId, sectionId });
    const list = element("div");
    list.className = page.type === "grid" || page.type === "classes" ? "cards grid" : "cards";
    for (const entry of entries) list.append(renderCard(page, entry, headingLevel, favorite, { tabId, sectionId }));
    return list;
  }
  function applyNavigationColor(button2, color) {
    if (typeof color !== "string" || !/^#[\da-f]{6}$/i.test(color)) return;
    const [red, green, blue] = color.slice(1).match(/.{2}/g).map((hex) => {
      const value = parseInt(hex, 16) / 255;
      return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
    });
    const luminance = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
    button2.style.setProperty("--navigation-color", color);
    button2.style.setProperty("--navigation-ink", luminance > 0.179 ? "#000" : "#fff");
    button2.classList.add("custom-navigation-color");
  }
  function selectOption(label, options, selection, key, update, showEmpty) {
    const selected = options.find((option) => option.id === selection[key]) ?? options[0];
    if (!options.length && !showEmpty) return void 0;
    const nav = element("nav");
    nav.className = "subtabs";
    nav.setAttribute("aria-label", label);
    let selectedButton;
    const controls = options.map((option) => {
      const button2 = element("button", option.title);
      applyNavigationColor(button2, option.color);
      button2.type = "button";
      button2.setAttribute("aria-pressed", String(option === selected));
      button2.addEventListener("click", () => {
        selection[key] = option.id;
        update(label);
      });
      nav.append(button2);
      if (option === selected) selectedButton = button2;
      return { ...option, control: button2 };
    });
    return { selected, nav, selectedButton, options: controls };
  }
  function getSectionGroups(sections) {
    const groups = /* @__PURE__ */ new Map();
    for (const section of sections) {
      const { id, title: title2, color } = section.navigationGroup ?? section;
      if (!groups.has(id)) groups.set(id, { id, title: title2, color, sections: [] });
      groups.get(id).sections.push(section);
    }
    return [...groups.values()];
  }
  function getClassGroups(page) {
    const labels = page.classPageLabels;
    return (page.classPageStructure?.groups ?? []).map((group) => ({
      id: group.key,
      title: labels?.groupLabels?.[group.key] ?? group.key,
      color: page.classPageColors?.group?.[group.key],
      classes: group.classes.map((id) => ({
        id,
        title: labels?.classLabels?.[id] ?? id,
        color: page.classPageColors?.class?.[id]
      }))
    }));
  }
  function renderAbilityRanks(page, abilities, headingLevel, favoriteButton) {
    const ranks = /* @__PURE__ */ new Map();
    for (const ability of abilities) {
      const value = ability.rank;
      const number = typeof value === "number" || typeof value === "string" && value.trim() ? Number(value) : NaN;
      const rank = Number.isFinite(number) ? number : Infinity;
      if (!ranks.has(rank)) ranks.set(rank, []);
      ranks.get(rank).push(ability);
    }
    const groups = document.createDocumentFragment();
    const abilityHeading = `h${Math.min(6, headingLevel + 1)}`;
    const favorite = entryFavorite(page, favoriteButton, page.id);
    for (const rank of [...ranks.keys()].sort((a, b) => a - b)) {
      const section = element("section");
      section.className = "ability-rank";
      const cards = element("div");
      cards.className = "cards";
      const entries = ranks.get(rank).sort((a, b) => entryTitle(page, a).localeCompare(entryTitle(page, b)));
      for (const entry of entries) cards.append(renderCard(page, entry, abilityHeading, favorite, { tabId: page.id }, true));
      section.append(styledHeading(`h${headingLevel}`, rank === Infinity ? "Unranked" : `Rank ${rank}`, "sectionHeading"), cards);
      groups.append(section);
    }
    return groups;
  }
  function renderFullCompendium(compendium, favoriteButton) {
    const root2 = element("div");
    root2.className = "full-compendium";
    root2.append(styledHeading("h2", "Full Compendium", "pageTitle"));
    function addEntries(parent, page, entries, level, tab, heading) {
      if (!entries.length) return;
      if (heading) parent.append(styledHeading(`h${level}`, heading, "sectionHeading"));
      const entryHeading = `h${heading ? level + 1 : level}`;
      parent.append(renderEntries(page, entries, entryHeading, favoriteButton, tab.id, page === tab ? void 0 : page.id));
    }
    for (const tab of compendium.tabs) {
      const chapter = element("section");
      chapter.append(styledHeading("h3", tab.title, "pageTitle"));
      const groups = tab.type === "classes" ? getClassGroups(tab) : [];
      if (groups.length) {
        const abilitiesByClass = /* @__PURE__ */ new Map();
        for (const entry of tab.entries) {
          if (!abilitiesByClass.has(entry.class)) abilitiesByClass.set(entry.class, []);
          abilitiesByClass.get(entry.class).push(entry);
        }
        const groupedClasses = /* @__PURE__ */ new Set();
        for (const group of groups) {
          const section = element("section");
          section.append(styledHeading("h4", group.title, "sectionHeading"));
          for (const characterClass of group.classes) {
            groupedClasses.add(characterClass.id);
            const abilities = abilitiesByClass.get(characterClass.id) ?? [];
            if (!abilities.length) continue;
            const classSection = element("section");
            classSection.append(
              styledHeading("h5", characterClass.title, "entryTitle"),
              renderAbilityRanks(tab, abilities, 6, favoriteButton)
            );
            section.append(classSection);
          }
          if (section.childElementCount > 1) chapter.append(section);
        }
        const ungrouped = tab.entries.filter((entry) => !groupedClasses.has(entry.class));
        addEntries(chapter, tab, ungrouped, 4, tab, "Other abilities");
      } else {
        addEntries(chapter, tab, tab.entries, 4, tab);
      }
      for (const group of getSectionGroups(tab.sections)) {
        const section = element("section");
        section.append(styledHeading("h4", group.title, "sectionHeading"));
        for (const view of group.sections) {
          const heading = view.navigationGroup ? view.title : void 0;
          addEntries(section, view, view.entries, 5, tab, heading);
        }
        if (section.childElementCount > 1) chapter.append(section);
      }
      if (chapter.childElementCount > 1) root2.append(chapter);
    }
    if (root2.childElementCount === 1) {
      root2.append(element("p", "This compendium has no entries."));
    }
    subtabs.replaceChildren();
    content.replaceChildren(root2);
  }
  function pageUrl(location) {
    const url = new URL(window.location.href);
    for (const key of ["view", "tab", "subtab", "entry"]) {
      if (location[key] === void 0) url.searchParams.delete(key);
      else url.searchParams.set(key, location[key]);
    }
    return url;
  }
  function writePageQuery(location, historyMode) {
    const url = pageUrl(location);
    if (url.href !== window.location.href) window.history[historyMode](null, "", url);
  }
  function renderPage(page, selection, favoriteButton, navigationEditor, onNavigate, focusRow) {
    const location = { tab: page.id };
    const root2 = element("div");
    root2.append(styledHeading("h2", page.title, "pageTitle"));
    const menus = [];
    function choose(label, options, state, key, path, sidebar) {
      const choice = selectOption(label, options, state, key, onNavigate, Boolean(navigationEditor));
      if (!choice) return void 0;
      const list = element("div");
      if (sidebar) choice.nav.classList.add("entry-sidebar");
      list.append(choice.nav);
      if (navigationEditor) {
        if (!sidebar) list.classList.add("navigation-with-actions");
        const controls = element("div");
        navigationEditor.attach(choice.nav, path, controls, choice.options, choice.selected);
        list.append(controls);
      }
      if (sidebar) sidebar.append(list);
      menus.push({ ...choice, label, sidebar, list });
      return choice;
    }
    function readingPane(label, options, state, key, path) {
      const layout = element("div");
      layout.className = "reading-layout";
      const choice = choose(label, options, state, key, path, layout);
      if (!choice) return void 0;
      const body = element("div");
      body.className = "reading-body";
      layout.append(body);
      root2.append(layout);
      if (!choice.selected) body.append(element("p", "No categories yet."));
      return { selected: choice.selected, body };
    }
    function addEntries(view, entries, isSection = false) {
      if (!entries.length) return;
      if (!isSection) {
        root2.append(renderEntries(view, entries, "h3", favoriteButton, page.id));
        return;
      }
      const group = element("section");
      group.append(styledHeading("h3", view.title, "sectionHeading"), renderEntries(view, entries, "h4", favoriteButton, page.id, view.id));
      root2.append(group);
    }
    if (page.type === "classes" && page.classPageStructure) {
      const groups = getClassGroups(page);
      const group = choose("Class groups", groups, selection, "classGroup", [page.id])?.selected;
      location.subtab = group?.id;
      const pane = group && readingPane("Classes", group.classes, selection.groups[group.id] ??= /* @__PURE__ */ Object.create(null), "class", [page.id, group.id]);
      if (pane?.selected) {
        const characterClass = pane.selected;
        location.entry = characterClass.id;
        pane.body.append(styledHeading("h3", characterClass.title, "entryTitle"));
        const abilities = page.entries.filter((entry) => entry.class === characterClass.id);
        if (abilities.length) pane.body.append(renderAbilityRanks(page, abilities, 4, favoriteButton));
        else pane.body.append(element("p", "No abilities listed for this class."));
      }
    } else {
      addEntries(page, page.entries);
      const group = choose(`${page.title} subtabs`, getSectionGroups(page.sections), selection, "subtab", [page.id])?.selected;
      location.subtab = group?.id;
      for (const section of group?.sections ?? []) {
        const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
        if (section.type === "normal" && (section.entries.length || navigationEditor)) {
          const options = section.entries.map((entry) => ({
            id: entry.id,
            title: entry.title ?? entry.name ?? entry.id,
            color: entry.color,
            entry
          }));
          const pane = readingPane(`${section.title} entries`, options, state, "entry", [page.id, group.id]);
          if (pane?.selected) {
            location.entry ??= pane.selected.id;
            pane.body.append(renderEntries(section, [pane.selected.entry], "h3", favoriteButton, page.id, section.id));
          }
        } else {
          addEntries(section, section.entries, true);
        }
      }
    }
    if (root2.childElementCount === 1) {
      root2.append(element("p", "No entries in this section."));
    }
    subtabs.replaceChildren(...menus.filter((menu) => !menu.sidebar).map((menu) => menu.list));
    content.replaceChildren(root2);
    menus.find((menu) => menu.label === focusRow)?.selectedButton?.focus();
    return location;
  }
  function showCompendium(configuration2, projectId2) {
    const canWrite = Boolean(writer.saveEntry || writer.changeNavigation || writer.saveTypography);
    const entryEditor = writer.saveEntry ? createEntryEditor(root, writer, saveTarget) : null;
    function setLocation(location, historyMode) {
      if (routing && host2.isConnected) writePageQuery(location, historyMode);
    }
    let compendium = createCompendium(configuration2);
    findReference = createPageReferences(compendium);
    followReference = openTarget;
    let selected = compendium.tabs[0];
    const fullView = Symbol("Full Compendium");
    const fullTab = element("button", "Full Compendium");
    fullTab.type = "button";
    let writerTools = false;
    const navigationEditor = writer.changeNavigation ? createNavigationEditor(root, () => configuration2, applyConfiguration, writer.changeNavigation, saveTarget) : null;
    if (canWrite) {
      const toolbar = element("div");
      toolbar.className = "writer-toolbar";
      const guideButton = writer.saveTypography ? element("button", "Style Guide") : null;
      if (guideButton) {
        const guide = createStyleGuide(root, writer.saveTypography, applyConfiguration);
        guideButton.type = "button";
        guideButton.hidden = true;
        guideButton.addEventListener("click", () => guide.show(typography));
        toolbar.append(guideButton);
      }
      const toggle = element("button", "Show Writer Tools");
      toggle.type = "button";
      toggle.setAttribute("aria-pressed", "false");
      toggle.addEventListener("click", () => {
        writerTools = !writerTools;
        if (guideButton) guideButton.hidden = !writerTools;
        toggle.textContent = writerTools ? "Hide Writer Tools" : "Show Writer Tools";
        toggle.setAttribute("aria-pressed", String(writerTools));
        renderTabButtons();
        renderTabWriterActions();
        renderSelected();
      });
      const main = root.querySelector("main");
      main.classList.add("writer-preview");
      toggle.className = "writer-toggle";
      toolbar.append(toggle);
      main.append(toolbar);
    }
    const favorites = loadFavorites(projectId2);
    const favoritesTab = element("button");
    favoritesTab.type = "button";
    const updateFavoriteCount = () => {
      favoritesTab.textContent = `Favorites (${favorites.size})`;
    };
    updateFavoriteCount();
    const selections = new Map(compendium.tabs.map((page) => [
      page.id,
      { groups: /* @__PURE__ */ Object.create(null) }
    ]));
    const tabButtons = /* @__PURE__ */ new Map();
    function favoriteButton(item2, title2) {
      const button2 = element("button", "\u2606");
      button2.className = "favorite-star";
      button2.type = "button";
      button2.dataset.favoriteKey = favoriteKey(item2);
      button2.setAttribute("aria-label", `Favorite: ${title2}`);
      const showState = (pressed) => {
        button2.textContent = pressed ? "\u2605" : "\u2606";
        button2.setAttribute("aria-pressed", String(pressed));
      };
      showState(favorites.has(item2));
      button2.addEventListener("click", () => {
        showState(favorites.toggle(item2));
        updateFavoriteCount();
      });
      if (!writerTools || !entryEditor || item2.block) return button2;
      const source = compendium.resolveEntry(item2);
      const edit = element("button", "Edit");
      edit.type = "button";
      edit.setAttribute("aria-label", `Edit: ${title2}`);
      const afterDelete = writer.deleteAbility && !source.section && source.tab.type === "classes" && typeof source.entry.class === "string" ? (updated) => {
        applyConfiguration(updated);
        const selectedClass = content.querySelector('.entry-sidebar [aria-pressed="true"]');
        (selectedClass ?? tabs.querySelector('[aria-pressed="true"]'))?.focus();
        root.querySelector("#writer-announcement").textContent = `Deleted ${title2} from ${saveTarget}.`;
      } : void 0;
      function afterSave(updated) {
        Object.assign(source.entry, updated);
        findReference = createPageReferences(compendium);
        renderSelected();
        const updatedTitle = entryTitle(source.section ?? source.tab, source.entry);
        const buttons = content.querySelectorAll(".entry-actions");
        const actions2 = [...buttons].find((group) => group.firstElementChild.dataset.favoriteKey === favoriteKey(item2));
        actions2?.lastElementChild.focus();
        root.querySelector("#writer-announcement").textContent = `Saved ${updatedTitle} to ${saveTarget}.`;
      }
      const paragraphFields = (source.section ?? source.tab).fields?.filter((field) => field.type === "paragraph").map((field) => field.key);
      edit.addEventListener("click", () => entryEditor.editEntry(item2, title2, source.entry, {
        afterSave,
        afterDelete,
        paragraphFields,
        hideNavigationColor: source.section?.type === "normal"
      }));
      const actions = element("div");
      actions.className = "entry-actions";
      actions.append(button2, edit);
      return actions;
    }
    function renderSelected(focusRow, historyMode = "replaceState") {
      if (selected === fullView) {
        renderFullCompendium(compendium, favoriteButton);
        setLocation({ view: "full" }, historyMode);
      } else if (selected) {
        const location = renderPage(
          selected,
          selections.get(selected.id),
          favoriteButton,
          writerTools ? navigationEditor : null,
          (row) => renderSelected(row, "pushState"),
          focusRow
        );
        setLocation(location, historyMode);
      }
    }
    function activate(page, historyMode = "pushState") {
      selected = page;
      for (const [id, button2] of tabButtons) {
        button2.setAttribute("aria-pressed", String(id === page?.id));
      }
      favoritesTab.setAttribute("aria-pressed", String(!page));
      fullTab.setAttribute("aria-pressed", String(page === fullView));
      renderTabWriterActions();
      search.value = "";
      search.disabled = false;
      renderSearchResults();
      if (page) renderSelected(void 0, historyMode);
      else {
        renderFavorites();
        setLocation({ view: "favorites" }, historyMode);
      }
    }
    function openSource(item2, { tab, section, entry }) {
      const selection = selections.get(tab.id);
      if (section) {
        selection.subtab = section.navigationGroup?.id ?? section.id;
        const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
        state.entry = entry.id;
      } else if (tab.type === "classes" && selection.groups[selection.classGroup]?.class !== entry.class) {
        const group = tab.classPageStructure?.groups?.find((group2) => group2.classes.includes(entry.class));
        if (group) {
          selection.classGroup = group.key;
          const state = selection.groups[group.key] ??= /* @__PURE__ */ Object.create(null);
          state.class = entry.class;
        }
      }
      activate(tab);
      const buttons = [...content.querySelectorAll("[data-favorite-key]")];
      const target = buttons.find((button2) => button2.dataset.favoriteKey === favoriteKey(item2)) ?? buttons.find((button2) => button2.dataset.favoriteKey === favoriteKey({ ...item2, block: void 0 }));
      target?.focus();
    }
    function renderFavorites() {
      subtabs.replaceChildren();
      const root2 = element("div");
      root2.append(styledHeading("h2", "Favorites", "pageTitle"));
      if (!favorites.size) {
        root2.append(element("p", "Star an entry or a passage to save it here."));
        content.replaceChildren(root2);
        return;
      }
      const list = element("div");
      list.className = "cards";
      for (const item2 of favorites.values()) {
        const source = compendium.resolveEntry(item2);
        const card = element("article");
        const title2 = source ? entryTitle(source.section ?? source.tab, source.entry) : item2.entryId;
        card.append(styledHeading("h3", title2, "entryTitle"));
        if (source) {
          const location = [source.tab.title, source.section?.title].filter(Boolean).join(" / ");
          card.append(element("p", location));
          if (item2.block?.excerpt) card.append(element("p", item2.block.excerpt));
        } else {
          card.append(element("p", "This entry is no longer available."));
        }
        const actions = element("div");
        actions.className = "favorite-actions";
        if (source) {
          const open = element("button", "Open source");
          open.type = "button";
          open.addEventListener("click", () => openSource(item2, source));
          actions.append(open);
        }
        const remove = element("button", "Remove");
        remove.type = "button";
        remove.setAttribute("aria-label", `Remove favorite: ${title2}`);
        remove.addEventListener("click", () => {
          favorites.toggle(item2);
          updateFavoriteCount();
          renderFavorites();
          favoritesTab.focus();
        });
        actions.append(remove);
        card.append(actions);
        list.append(card);
      }
      root2.append(list);
      content.replaceChildren(root2);
    }
    function renderSearchResults() {
      const results = searchCompendium(compendium, search.value);
      searchResults.replaceChildren();
      searchResults.hidden = !search.value.trim();
      if (searchResults.hidden) return;
      if (!results.length) {
        const empty = element("p", "No matches found.");
        empty.setAttribute("role", "status");
        searchResults.append(empty);
        return;
      }
      for (const result of results) {
        const button2 = element("button");
        button2.type = "button";
        const title2 = element("span", result.title);
        title2.className = "search-result-title";
        const location = element("small", result.meta);
        location.className = "search-result-location";
        button2.append(title2, location);
        button2.addEventListener("click", () => openTarget(result.target));
        searchResults.append(button2);
      }
    }
    function openTarget(target) {
      const tab = compendium.tabs.find((page) => page.id === target.tabId);
      if (!tab) return;
      const selection = selections.get(tab.id);
      if (target.groupId !== void 0) {
        selection.classGroup = target.groupId;
        const state = selection.groups[target.groupId] ??= /* @__PURE__ */ Object.create(null);
        state.class = target.classId;
      }
      if (target.entryId !== void 0) {
        const source = compendium.resolveEntry(target);
        if (source) {
          openSource(target, source);
          return;
        }
      }
      const section = tab.sections.find((view) => view.id === target.sectionId);
      if (section) {
        selection.subtab = section.navigationGroup?.id ?? section.id;
        const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
        delete state.entry;
      }
      activate(tab);
      tabButtons.get(tab.id)?.focus();
    }
    search.addEventListener("input", renderSearchResults);
    search.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        search.value = "";
        renderSearchResults();
      } else if (event.key === "Enter" || event.key === "ArrowDown") {
        const first = searchResults.querySelector("button");
        if (!first || searchResults.hidden) return;
        event.preventDefault();
        first.focus();
      }
    });
    searchResults.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        search.value = "";
        renderSearchResults();
        search.focus();
      } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const next = event.key === "ArrowDown" ? event.target.nextElementSibling : event.target.previousElementSibling ?? search;
        next?.focus();
      }
    });
    favoritesTab.addEventListener("click", () => activate(null));
    fullTab.addEventListener("click", () => activate(fullView));
    function renderTabWriterActions() {
      tabs.parentElement.classList.toggle("navigation-with-actions", writerTools);
      if (!writerTools || !navigationEditor) {
        tabWriterActions.replaceChildren();
        delete tabs.dataset.navigationPath;
        return;
      }
      const options = compendium.tabs.map((page) => ({ ...page, control: tabButtons.get(page.id) }));
      navigationEditor.attach(tabs, [], tabWriterActions, options, options.find((option) => option.id === selected?.id));
    }
    function renderTabButtons() {
      tabs.replaceChildren(favoritesTab, fullTab);
      tabButtons.clear();
      for (const page of compendium.tabs) {
        const button2 = element("button", page.title);
        button2.type = "button";
        applyNavigationColor(button2, page.color);
        button2.setAttribute("aria-pressed", String(page.id === selected?.id));
        button2.addEventListener("click", () => activate(page));
        tabButtons.set(page.id, button2);
        tabs.append(button2);
        if (!selections.has(page.id)) selections.set(page.id, { groups: /* @__PURE__ */ Object.create(null) });
      }
    }
    function applyConfiguration(updated, added) {
      if (!host2.isConnected) return;
      const previous = selected;
      typography = normalizeTypography(updated.typography);
      applyHeadingStyle(titleHeading, typography.title);
      configuration2 = updated;
      compendium = createCompendium(configuration2);
      findReference = createPageReferences(compendium);
      renderTabButtons();
      if (added) {
        const [tabId, subtabId] = added.path;
        const tab = compendium.tabs.find((page) => page.id === (tabId ?? added.id));
        if (tab) {
          const state = selections.get(tab.id);
          if (tabId) {
            const isClasses = tab.type === "classes" && tab.classPageStructure;
            if (isClasses) state.classGroup = subtabId ?? added.id;
            else state.subtab = subtabId ?? added.id;
            if (subtabId) {
              const subtab = state.groups[subtabId] ??= /* @__PURE__ */ Object.create(null);
              subtab[isClasses ? "class" : "entry"] = added.id;
            }
          }
          activate(tab);
          return;
        }
      }
      if (!previous || previous === fullView) {
        activate(previous, "replaceState");
        return;
      }
      activate(compendium.tabs.find((page) => page.id === previous.id) ?? compendium.tabs[0] ?? fullView, "replaceState");
    }
    function restorePageFromUrl() {
      const params = new URL(window.location.href).searchParams;
      if (params.get("view") === "favorites") return activate(null, "replaceState");
      if (params.get("view") === "full") return activate(fullView, "replaceState");
      const tabId = params.get("tab");
      const tab = compendium.tabs.find((page) => page.id === tabId) ?? compendium.tabs[0];
      if (!tab) return activate(fullView, "replaceState");
      const subtab = tab.id === tabId ? params.get("subtab") : null;
      const entry = tab.id === tabId ? params.get("entry") : null;
      const selection = selections.get(tab.id);
      if (tab.type === "classes" && tab.classPageStructure) {
        const groups = getClassGroups(tab);
        const group = groups.find((candidate) => candidate.id === subtab) ?? groups[0];
        selection.classGroup = group?.id;
        if (group) {
          const state = selection.groups[group.id] ??= /* @__PURE__ */ Object.create(null);
          state.class = group.id === subtab || !subtab ? entry : null;
        }
      } else {
        const groups = getSectionGroups(tab.sections);
        const group = groups.find((candidate) => candidate.id === subtab) ?? groups[0];
        selection.subtab = group?.id;
        for (const section of group?.sections ?? []) {
          const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
          state.entry = group.id === subtab || !subtab ? entry : null;
        }
      }
      activate(tab, "replaceState");
    }
    renderTabButtons();
    if (routing) {
      restorePageFromUrl();
      window.addEventListener("popstate", restorePageFromUrl);
    } else {
      activate(selected ?? fullView);
    }
    return () => {
      window.removeEventListener("popstate", restorePageFromUrl);
      entryEditor?.dispose();
    };
  }
  try {
    const dispose = showCompendium(structuredClone(configuration), projectId);
    return {
      destroy() {
        dispose();
        host2.remove();
      }
    };
  } catch (error) {
    host2.remove();
    throw error;
  }
}

// preview/GameCompendium.jsx
import { jsx as jsx3, jsxs as jsxs3 } from "react/jsx-runtime";
function savedTypography(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved === null ? fallback : normalizeTypography(JSON.parse(saved));
  } catch {
    return fallback;
  }
}
function GameCompendium({
  title,
  projectId,
  backTo,
  loadData,
  configure,
  imageBaseUrl,
  themeUrl = "/preview/compendium-theme.css",
  pageStyleUrl
}) {
  const container = useRef(null);
  const [status, setStatus] = useState2("Loading compendium\u2026");
  useEffect2(() => {
    const controller = new AbortController();
    const element = container.current;
    const pathname = window.location.pathname;
    let compendium;
    function dispose() {
      controller.abort();
      compendium?.destroy();
      compendium = void 0;
    }
    function handlePopState() {
      if (window.location.pathname !== pathname) dispose();
    }
    async function load() {
      setStatus("Loading compendium\u2026");
      try {
        const data = await loadData(controller.signal);
        if (controller.signal.aborted) return;
        const configuration = configure(data);
        const typographyKey = `40k-compendium-typography:${projectId}`;
        const typography = savedTypography(typographyKey, configuration.typography);
        compendium = mountCompendium(element, { ...configuration, typography }, {
          title,
          projectId,
          imageBaseUrl,
          routing: true,
          stylesheets: [themeUrl],
          writer: {
            saveTypography(nextTypography) {
              localStorage.setItem(typographyKey, JSON.stringify(nextTypography));
              return { ...configuration, typography: nextTypography };
            }
          }
        });
        setStatus("");
      } catch (error) {
        if (!controller.signal.aborted) setStatus(`Unable to open ${title}. ${error.message}`);
      }
    }
    window.addEventListener("popstate", handlePopState, true);
    load();
    return () => {
      window.removeEventListener("popstate", handlePopState, true);
      dispose();
    };
  }, [title, projectId, loadData, configure, imageBaseUrl, themeUrl]);
  return /* @__PURE__ */ jsxs3("main", { className: "game-compendium", "data-project": projectId, children: [
    pageStyleUrl && /* @__PURE__ */ jsx3("link", { rel: "stylesheet", href: pageStyleUrl }),
    /* @__PURE__ */ jsx3("nav", { "aria-label": `${title} navigation`, children: /* @__PURE__ */ jsx3(Link2, { to: backTo, children: "\u2039 Back" }) }),
    status && /* @__PURE__ */ jsx3("p", { role: "status", children: status }),
    /* @__PURE__ */ jsx3("div", { ref: container })
  ] });
}

// preview/compendium-data.mjs
function namedItems(items, convert) {
  const usedIds = /* @__PURE__ */ new Set();
  return (items ?? []).map((item2, index) => {
    const base = String(item2.id ?? item2.title ?? item2.name ?? "").trim() || String(index + 1);
    let id = base;
    for (let suffix = 2; usedIds.has(id); suffix++) id = `${base}-${suffix}`;
    usedIds.add(id);
    return { ...convert(item2, id), id };
  });
}
function compendiumBuilder() {
  const collections = [];
  function page(id, title, type, entries, options) {
    const collectionId = `collection-${collections.length + 1}`;
    collections.push({ id: collectionId, entries });
    return { id, title, type, collectionId, ...options };
  }
  return { collections, page };
}
var pyrrhicEquipment = [
  ["weapons", "Weapons", "weapons"],
  ["armors", "Armor", "armorShields", "Armor / Shields", "armor"],
  ["shields", "Shields", "armorShields", "Armor / Shields", "shields"],
  ["equipmentProperties", "Equipment Properties", "equipmentProperties"]
];
function pyrrhicEntries(entries) {
  const uploadPath = /(!\[[^\]\r\n]*\]\(\s*)\/games\/PyrrhicWar\/compendium\/images\/([a-z0-9-]+\.(?:png|jpg|webp)\s*\))/gi;
  return namedItems(entries, (entry) => Object.fromEntries(Object.entries(entry).map(([key, value]) => [
    key,
    typeof value === "string" ? value.replace(uploadPath, "$1$2") : value
  ])));
}
function legacySections(page, sections, tabType, tabFields) {
  return namedItems(sections, (section, id) => {
    const type = section.type ? legacyPageType(section.type) : tabType;
    return page(id, section.title ?? section.name ?? id, type, pyrrhicEntries(section.entries), {
      color: section.color,
      fields: section.gridSchema ?? tabFields
    });
  });
}
function legacyPageType(type) {
  return type === "grid" || type === "conditions" ? "grid" : "normal";
}
function classOptions(data) {
  const groups = data.classPageStructure?.groups ?? [];
  const known = new Set(groups.flatMap((group) => group.classes));
  const otherClasses = [...new Set((data.classAbilities ?? []).map((entry) => entry.class).filter(Boolean))].filter((name) => !known.has(name));
  const structure = otherClasses.length ? [...groups, { key: "other-classes", classes: otherClasses }] : groups;
  return {
    classPageLabels: {
      ...data.classPageLabels,
      groupLabels: { "other-classes": "Other Classes", ...data.classPageLabels?.groupLabels }
    },
    classPageStructure: structure.length ? { groups: structure } : void 0
  };
}
function pyrrhicWarCompendium(data) {
  if (Array.isArray(data?.tabs)) return data;
  if (!data || !["loreSections", "grid", "conditions", "customSections", "classAbilities", "weapons"].some((key) => Array.isArray(data[key]))) {
    throw new Error("The Pyrrhic War compendium has an unrecognized data format.");
  }
  const { page, collections } = compendiumBuilder();
  const { builtInTabs = {}, equipmentPageLabels = {} } = data;
  const lore = builtInTabs.lore ?? {};
  const grid = builtInTabs.grid ?? builtInTabs.conditions ?? {};
  const sections = pyrrhicEquipment.map(([key, defaultTitle, group, defaultGroupTitle, subcategory]) => page(key, equipmentPageLabels.subsectionLabels?.[subcategory] ?? equipmentPageLabels.sectionLabels?.[key] ?? defaultTitle, "table", pyrrhicEntries(data[key]), {
    navigationGroup: {
      id: group,
      title: equipmentPageLabels.sectionLabels?.[group] ?? defaultGroupTitle ?? defaultTitle
    }
  }));
  const tabs = /* @__PURE__ */ new Map([
    ["lore", lore.visible === false ? null : {
      id: "lore",
      title: lore.label || "Lore",
      type: "normal",
      color: lore.color,
      sections: legacySections(page, data.loreSections, "normal")
    }],
    ["grid", grid.visible === false ? null : page(
      "grid",
      grid.label || "Grid",
      "grid",
      pyrrhicEntries(data.grid ?? data.conditions),
      { color: grid.color, fields: data.gridSchema }
    )]
  ]);
  if (data.classAbilities?.length) {
    tabs.set("classes", page(
      "classes",
      builtInTabs.classes?.label || "Classes",
      "classes",
      pyrrhicEntries(data.classAbilities),
      classOptions(data)
    ));
  }
  if (pyrrhicEquipment.some(([key]) => data[key]?.length)) {
    tabs.set("equipment", { id: "equipment", title: "Equipment", type: "table", sections });
  }
  for (const tab of namedItems(data.customSections, (item2) => item2)) {
    const type = legacyPageType(tab.type);
    const id = `custom:${tab.id}`;
    const key = `custom:${tab.title}`;
    tabs.set(tabs.has(key) ? id : key, page(id, tab.title ?? tab.id, type, pyrrhicEntries(tab.entries), {
      color: tab.color,
      fields: tab.gridSchema,
      sections: legacySections(page, tab.sections, type, tab.gridSchema)
    }));
  }
  const requested = (data.tabOrder ?? []).map((key) => key === "conditions" ? "grid" : key);
  const order = [.../* @__PURE__ */ new Set([...requested, ...tabs.keys()])];
  return { tabs: order.map((key) => tabs.get(key)).filter(Boolean), collections };
}

// packages/pyrrhic-war.jsx
import { jsx as jsx4 } from "react/jsx-runtime";
var projectPath = "/projects/PyrrhicWar";
var assets = "/games/PyrrhicWar";
async function loadCompendium(signal) {
  const { response, payload } = await fetchJson("/pyrrhic-war/compendium/data", { signal });
  if (!response.ok) throw new Error(payload?.message || `Could not load Pyrrhic War data (HTTP ${response.status}).`);
  return payload;
}
function PyrrhicWarCompendium() {
  return /* @__PURE__ */ jsx4(
    GameCompendium,
    {
      title: "Pyrrhic War Compendium",
      projectId: "pyrrhic-war",
      backTo: projectPath,
      loadData: loadCompendium,
      configure: pyrrhicWarCompendium,
      imageBaseUrl: `${API_URL}${assets}/compendium/images/`,
      themeUrl: `${assets}/compendium-theme.css`,
      pageStyleUrl: `${assets}/compendium-page.css`
    }
  );
}
var routes = [
  { path: projectPath, Component: PyrrhicWar },
  { path: `${projectPath}Map`, Component: PyrrhicWarMap_default },
  { path: `${projectPath}Compendium`, Component: PyrrhicWarCompendium }
];
export {
  configureHost,
  routes
};
