// Expedition/expedition-membership.mjs
var expeditionRoles = ["viewer", "traveler", "admin"];
var expeditionTeams = ["", "red", "blue", "green", "yellow", "purple", "white", "black"];

// HybridCampaign/test-player-fixtures.mjs
var campaignTestPlayers = Object.freeze([
  { id: "test-adeptus-astartes", accountName: "[Test] Astartes Player", characterName: "Test Astartes", recipientId: "adeptus-astartes", supportingFactionName: "Test Astartes Cohort" },
  { id: "test-adeptus-mechanicus", accountName: "[Test] Mechanicus Player", characterName: "Test Mechanicus", recipientId: "adeptus-mechanicus", supportingFactionName: "Test Mechanicus Cohort" },
  { id: "test-agents-imperium", accountName: "[Test] Imperium Agent", characterName: "Test Imperium Agent", recipientId: "agents-imperium", supportingFactionName: "Test Inquisitorial Cell" },
  { id: "test-astra-militarum", accountName: "[Test] Astra Player", characterName: "Test Astra", recipientId: "astra-militarum", supportingFactionName: "Test Tavrellis Regiment" },
  { id: "test-grey-knights", accountName: "[Test] Grey Knight", characterName: "Test Grey Knight", recipientId: "grey-knights", supportingFactionName: "Test Grey Knights Strike Force" }
]);

// preview/accounts.mjs
var roles = ["user", "traveler", "manager", "owner"];
var membershipRoles = ["viewer", "participant", "writer", "admin"];
var expeditionRole = (account) => account.role === "owner" ? "owner" : account.expeditionMembershipRole || "viewer";
var campaignRoles = ["owner-gm", "gm", "co-gm", "player", "display"];
function createAccountStore(storage) {
  const key = "pyrrhic-preview-accounts-v1";
  const raw = storage?.getItem(key);
  let state = raw ? JSON.parse(raw) : { nextId: 1, accounts: [] };
  if (!Number.isSafeInteger(state.nextId) || !Array.isArray(state.accounts) || state.accounts.some((account) => !Number.isSafeInteger(account.id) || typeof account.username !== "string" || !(roles.includes(account.role) || account.role === "admin") || !membershipRoles.includes(account.membershipRole) || !Number.isInteger(account.team) || account.team < 0 || account.team > 4 || account.campaignRole !== void 0 && !campaignRoles.includes(account.campaignRole) || account.testFixtureId !== void 0 && !campaignTestPlayers.some((fixture) => fixture.id === account.testFixtureId) || account.campaignIdentityId !== void 0 && typeof account.campaignIdentityId !== "string")) {
    throw new Error("Saved preview accounts are invalid. Clear the pyrrhic-preview-accounts-v1 browser storage entry to reset them.");
  }
  state.accounts = state.accounts.map((account) => account.role === "admin" ? { ...account, role: "manager" } : account);
  const listeners = /* @__PURE__ */ new Set();
  const commit = (next) => {
    storage?.setItem(key, JSON.stringify(next));
    state = next;
    listeners.forEach((listener) => listener());
  };
  const find = (username) => state.accounts.find((account) => account.username.toLowerCase() === String(username).trim().toLowerCase());
  return {
    list: () => structuredClone(state.accounts),
    find: (username) => {
      const account = find(username);
      return account ? { ...account } : null;
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    save({ username, role }) {
      username = String(username).trim();
      if (!username || username.length > 80 || !roles.includes(role)) throw new Error("Enter a username and a valid site permission.");
      const existing = find(username);
      const account = { ...existing || { id: state.nextId, membershipRole: "viewer", team: 0 }, username, role };
      commit({ nextId: state.nextId + (existing ? 0 : 1), accounts: [...state.accounts.filter((item) => item.id !== account.id), account] });
      return { ...account };
    },
    remove(id) {
      commit({ ...state, accounts: state.accounts.filter((account) => account.id !== id) });
    },
    assign(id, membershipRole, team) {
      if (!membershipRoles.includes(membershipRole) || !Number.isInteger(team) || team < 0 || team > 4) throw new Error("Choose a valid Pyrrhic War permission and team.");
      const existing = state.accounts.find((account2) => account2.id === id);
      if (!existing) throw new Error("Saved account not found.");
      const account = { ...existing, membershipRole, team };
      commit({ ...state, accounts: state.accounts.map((item) => item.id === id ? account : item) });
      return { ...account };
    },
    assignExpedition(id, membershipRole, team) {
      if (!expeditionRoles.includes(membershipRole) || !expeditionTeams.includes(team)) throw new Error("Choose a valid Expedition permission and team.");
      const existing = state.accounts.find((account2) => account2.id === id);
      if (!existing) throw new Error("Saved account not found.");
      const account = { ...existing, expeditionMembershipRole: membershipRole, expeditionTeam: team };
      commit({ ...state, accounts: state.accounts.map((item) => item.id === id ? account : item) });
      return { ...account };
    },
    assignCampaignRole(id, campaignRole) {
      if (!campaignRoles.includes(campaignRole)) throw new Error("Choose a valid Hybrid Campaign role.");
      const existing = state.accounts.find((account2) => account2.id === id);
      if (!existing) throw new Error("Saved account not found.");
      const account = { ...existing, campaignRole, campaignIdentityId: campaignRole === "player" ? existing.campaignIdentityId : void 0 };
      commit({ ...state, accounts: state.accounts.map((item) => item.id === id ? account : item) });
      return { ...account };
    },
    assignCampaignIdentity(id, campaignIdentityId) {
      if (typeof campaignIdentityId !== "string" || !campaignIdentityId.trim()) throw new Error("A valid campaign identity is required.");
      const existing = state.accounts.find((account2) => account2.id === id);
      if (!existing || existing.campaignRole !== "player") throw new Error("Only a saved player account may receive a campaign identity.");
      const account = { ...existing, campaignIdentityId: campaignIdentityId.trim() };
      commit({ ...state, accounts: state.accounts.map((item) => item.id === id ? account : item) });
      return { ...account };
    },
    /** Seed the five clearly-labelled player fixtures only in the browser preview. */
    seedCampaignTestAccounts() {
      let nextId = state.nextId;
      const nextAccounts = [...state.accounts];
      for (const fixture of campaignTestPlayers) {
        if (nextAccounts.some((account) => account.testFixtureId === fixture.id)) continue;
        nextAccounts.push({ id: nextId++, username: fixture.accountName, role: "user", membershipRole: "viewer", team: 0, campaignRole: "player", testFixtureId: fixture.id });
      }
      if (nextId !== state.nextId) commit({ nextId, accounts: nextAccounts });
      return nextAccounts.filter((account) => account.testFixtureId).map((account) => ({ ...account }));
    }
  };
}

// Expedition/point-rewards.js
(() => {
  function rewardRow(label, key, campaign = 0, supply = 0, campaignKey = `${key}Campaign`) {
    return {
      label,
      fields: [[campaignKey, "Campaign Points", campaign], [`${key}Supply`, "Supply Points", supply, 10]]
    };
  }
  const standard = {
    victor: rewardRow("Victor", "standardWin", 2),
    draw: rewardRow("Draw", "standardDraw", 0, 1),
    loser: rewardRow("Loser", "standardLoss", 0, 1)
  };
  const joint = {
    victor: rewardRow("Victor", "jointWin", 1, 0, "jointCampaign"),
    draw: rewardRow("Draw", "jointDraw"),
    loser: rewardRow("Loser", "jointLoss")
  };
  const adversary = {
    victor: rewardRow("Victor", "adversaryWin", 3),
    draw: rewardRow("Draw", "adversaryDraw", 0, 2),
    loser: rewardRow("Loser", "adversaryLoss", 0, 2)
  };
  const multiplayer = {
    victor3: rewardRow("Victor \xB7 3 players", "multiplayerWin3", 3),
    draw3: rewardRow("Draw \xB7 3 players", "multiplayerDraw3", 3),
    victor4: rewardRow("Victor \xB7 4 players", "multiplayerWin4", 4),
    draw4: rewardRow("Draw \xB7 4 players", "multiplayerDraw4", 4),
    loser: rewardRow("Loser", "multiplayerLoss", 0, 2)
  };
  const battleGroups = [
    ["Standard", Object.values(standard)],
    ["Joint Op", Object.values(joint)],
    ["Adversary Op", Object.values(adversary)],
    ["Multiplayer Op", Object.values(multiplayer)]
  ];
  const battleFields2 = battleGroups.flatMap(([, rows]) => rows.flatMap((row) => row.fields));
  const mapGroups2 = [
    ["Resupply", [
      ["baseTarget", "Own base target balance", 10, 10],
      ["ownCampMin", "Own camp minimum", 4, 10],
      ["ownCampMax", "Own camp maximum", 6, 10],
      ["otherCampMin", "Other team\u2019s camp minimum", 1, 10],
      ["otherCampMax", "Other team\u2019s camp maximum", 3, 10],
      ["otherHexSupply", "Other hex Supply Points", 1, 10]
    ]],
    ["Reward Defaults", [
      ["searchSupply", "Search Supply Points", 0, 10],
      ["searchCampaign", "Search Campaign Points", 0],
      ["manoeuvreSupply", "Manoeuvre Supply Points", 0, 10],
      ["manoeuvreCampaign", "Manoeuvre Campaign Points", 0],
      ["bountySupply", "New bounty Supply Points", 0, 10],
      ["bountyCampaign", "New bounty Campaign Points", 0]
    ]]
  ];
  const fields = [...mapGroups2.flatMap(([, entries]) => entries), ...battleFields2];
  const defaults = Object.fromEntries(fields.map(([key, , amount]) => [key, amount]));
  const campRanges = [["ownCampMin", "ownCampMax"], ["otherCampMin", "otherCampMax"]];
  const validAmount = (value, max = Number.MAX_SAFE_INTEGER) => Number.isSafeInteger(value) && value >= 0 && value <= max;
  const validRanges = (rewards) => campRanges.every(([min, max]) => rewards[min] <= rewards[max]);
  function readSettings2(settings) {
    const legacyMultiplier = settings?.multiplayerWinCampaignPerTeam;
    const scaledReward = (size) => Math.min(Number.MAX_SAFE_INTEGER, size * legacyMultiplier);
    const legacyRewards = validAmount(legacyMultiplier) ? {
      multiplayerWin3Campaign: scaledReward(3),
      multiplayerDraw3Campaign: scaledReward(3),
      multiplayerWin4Campaign: scaledReward(4),
      multiplayerDraw4Campaign: scaledReward(4)
    } : {};
    const rewards = Object.fromEntries(fields.map(([key, , fallback, max]) => [
      key,
      validAmount(settings?.[key], max) ? settings[key] : legacyRewards[key] ?? fallback
    ]));
    for (const [min, max] of campRanges) {
      if (rewards[min] > rewards[max]) {
        rewards[min] = defaults[min];
        rewards[max] = defaults[max];
      }
    }
    return rewards;
  }
  function validateSettings2(rewards) {
    return rewards && Object.keys(rewards).length === fields.length && fields.every(([key, , , max]) => Object.hasOwn(rewards, key) && validAmount(rewards[key], max)) && validRanges(rewards);
  }
  function battleAwards(changeSet, settings, teams3) {
    const normalize = (value) => String(value || "").trim().toLowerCase();
    const type = normalize(changeSet.battleType);
    if (type === "compound-op") return [];
    const rewards = readSettings2(settings);
    const team = (value) => {
      const normalized = normalize(value);
      return normalized === "outside-player" || teams3.includes(normalized) ? normalized : "";
    };
    const teamList = (values) => [...new Set(
      (Array.isArray(values) ? values : String(values || "").split(",")).map(team).filter(Boolean)
    )];
    const requester = team(changeSet.requesterTeam);
    const opponent = team(changeSet.battleOpponent);
    const outcome = normalize(changeSet.battleOutcome || changeSet.battleResult);
    const winner = team(outcome) || (outcome === "won" ? requester : outcome === "lost" ? opponent : "");
    const participants = type === "multiplayer-op" ? teamList([requester, ...teamList(changeSet.battleOpponents)]) : teamList([requester, opponent]);
    const awardsFor = (recipient, row) => {
      if (!teams3.includes(recipient) || !row) return [];
      const [campaign, supply] = row.fields.map(([key]) => rewards[key]);
      return [["campaignPoints", campaign], ["supplyPoints", supply]].filter(([, amount]) => amount > 0).map(([field, amount]) => [recipient, field, amount]);
    };
    switch (type) {
      case "standard":
      case "adversary-op": {
        const rows = type === "standard" ? standard : adversary;
        if (outcome === "draw") return participants.flatMap((participant) => awardsFor(participant, rows.draw));
        if (!winner) return [];
        return [
          ...awardsFor(winner, rows.victor),
          ...participants.filter((participant) => participant !== winner).flatMap((participant) => awardsFor(participant, rows.loser))
        ];
      }
      case "joint-op": {
        let row;
        if (outcome === "draw") row = joint.draw;
        else if (outcome === "lost" || outcome === "joint-loss") row = joint.loser;
        else if (outcome === "joint-win" || participants.includes(winner)) row = joint.victor;
        return participants.flatMap((participant) => awardsFor(participant, row));
      }
      case "multiplayer-op": {
        const legacyWinners = teamList(changeSet.battleWinners);
        const leaders = outcome === "draw" ? teamList(changeSet.battleTiedTeams ?? participants) : winner ? [winner] : legacyWinners.length ? legacyWinners : teamList(changeSet.battleWinner);
        const row = multiplayer[`${leaders.length > 1 ? "draw" : "victor"}${participants.length}`];
        return participants.flatMap((participant) => awardsFor(participant, leaders.includes(participant) ? row : multiplayer.loser));
      }
      default:
        return [];
    }
  }
  globalThis.ExpeditionPointRewards = { battleFields: battleFields2, battleGroups, mapGroups: mapGroups2, readSettings: readSettings2, validateSettings: validateSettings2, battleAwards };
})();

// Expedition/battle-rules.mjs
var expeditionBattlesEnabled = true;
var battlesUnavailableMessage = "Battles are temporarily unavailable.";
var battleEquipmentLimit = 4;
var equipmentCount = (choices) => choices.reduce((total, { quantity }) => total + quantity, 0);
var battleTypes = {
  standard: "Standard",
  "joint-op": "Joint Op",
  "adversary-op": "Adversary Op",
  "multiplayer-op": "Multiplayer Op",
  "compound-op": "Compound Op"
};
var outsidePlayer = "outside-player";
var battleTeamList = (value) => Array.isArray(value) ? value : String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
function battleSubmissionRound(battle) {
  const round = Number(battle?.submissionRound);
  return Number.isSafeInteger(round) && round >= 1 ? round : null;
}
function battleParticipants(battle) {
  const multiplayer = battleTeamList(battle.battleOpponents);
  const opponents = battle.battleType === "multiplayer-op" && multiplayer.length ? multiplayer : [battle.battleOpponent];
  return [...new Set([battle.requesterTeam, ...opponents].filter(Boolean))];
}
function battleResultOptions(type) {
  if (type === "compound-op") return { attacker: "Attacker won", defender: "Defender won", draw: "Draw" };
  if (type === "joint-op") return { won: "Won", lost: "Lost" };
  return { won: "Won", lost: "Lost", draw: "Draw" };
}
function validBattleScores(battle) {
  const scores = battle.battleScores;
  const participants = battleParticipants(battle);
  return scores && typeof scores === "object" && !Array.isArray(scores) && Object.keys(scores).length === participants.length && participants.every((team) => Object.hasOwn(scores, team) && Number.isSafeInteger(scores[team]) && scores[team] >= 0);
}
function battleOutcome(battle) {
  const { battleType, battleResult, battleSide, requesterTeam, battleOpponent } = battle;
  if (Object.hasOwn(battle, "battleScores")) {
    if (!validBattleScores(battle)) return { winners: [], result: "Result unavailable" };
    const best = Math.max(...Object.values(battle.battleScores));
    const leaders = battleParticipants(battle).filter((team) => battle.battleScores[team] === best);
    return leaders.length === 1 ? { winners: leaders, result: "" } : { winners: [], result: "Draw", tied: leaders };
  }
  if (battle.battleOutcome === "draw") {
    const tied = battleType === "multiplayer-op" ? battle.battleTiedTeams ?? battleParticipants(battle) : [];
    return { winners: [], result: "Draw", tied };
  }
  if (battleType === "joint-op") {
    const result = battle.battleOutcome || battleResult;
    if (result === "joint-loss" || result === "lost") return { winners: [], result: "Joint Op lost" };
    if (result === "won" || result === "joint-win" || battleParticipants(battle).includes(result)) {
      return { winners: battleParticipants(battle), result: "" };
    }
  }
  if (battle.battleOutcome) return { winners: [battle.battleOutcome], result: "" };
  if (battleType === "multiplayer-op") {
    const listedWinners = battleTeamList(battle.battleWinners);
    const winners = listedWinners.length ? listedWinners : battleTeamList(battle.battleWinner);
    if (winners.length > 1) return { winners: [], result: "Draw", tied: winners };
    return { winners, result: winners.length ? "" : "Winner unavailable" };
  }
  if (battleResult === "draw") return { winners: [], result: "Draw" };
  if (battleType === "compound-op" && ["attacker", "defender"].includes(battleResult)) {
    return { winners: [battleSide === battleResult ? requesterTeam : battleOpponent].filter(Boolean), result: battleResult === "defender" ? "Defender won" : "Attacker won" };
  }
  if (battleResult === "won") return { winners: [requesterTeam].filter(Boolean), result: "" };
  if (battleResult === "lost") return { winners: [battleOpponent].filter(Boolean), result: "" };
  return { winners: [], result: "Result unavailable" };
}
function battleLocationOptions(battle, tiles) {
  let occupants = battleParticipants(battle).filter((team) => team !== outsidePlayer);
  let defender = "";
  if (battle.battleType === "compound-op") {
    if (battle.battleSide === "attacker") {
      occupants = [battle.requesterTeam];
      defender = battle.battleOpponent;
    } else if (battle.battleSide === "defender") {
      occupants = [battle.battleOpponent];
      defender = battle.requesterTeam;
    } else {
      return [];
    }
  }
  return (tiles ?? []).filter((tile) => tile?.id && [tile.marker, tile.secondaryMarker].some((team) => team && team !== outsidePlayer && occupants.includes(team)) && (!defender || battle.battleOpponent === outsidePlayer || tile.structure === "camp" && tile.structureColor === defender));
}
function validateBattle(battle, teams3, tiles, { recordedLocation } = {}) {
  const { battleType, requesterTeam, battleOpponent, battleSide, battleResult, battleLocation } = battle;
  const explicitOutcome = Object.hasOwn(battle, "battleOutcome");
  const scored = Object.hasOwn(battle, "battleScores");
  if (!Object.hasOwn(battleTypes, battleType) || !teams3.includes(requesterTeam)) return "Select a battle type and reporting team.";
  if (battleType === "multiplayer-op") {
    const opponents = battleTeamList(battle.battleOpponents);
    if (opponents.length < 2 || opponents.length > 3 || new Set(opponents).size !== opponents.length || opponents.some((team) => team === requesterTeam || team !== outsidePlayer && !teams3.includes(team))) {
      return "Select two or three distinct opponents.";
    }
    if (!scored && !explicitOutcome) {
      const { winners, tied } = battleOutcome(battle);
      const leaders = tied ?? winners;
      if (!leaders.length || leaders.some((team) => team !== requesterTeam && !opponents.includes(team))) return "Select at least one participating winner.";
    }
    if (!scored && battle.battleOutcome === "draw" && Object.hasOwn(battle, "battleTiedTeams")) {
      const tied = battle.battleTiedTeams;
      if (!Array.isArray(tied) || tied.length < 2 || new Set(tied).size !== tied.length || tied.some((team) => team !== requesterTeam && !opponents.includes(team))) return "Select at least two participating teams that tied.";
    }
  } else {
    const joint = battleType === "joint-op";
    if (!teams3.includes(battleOpponent) && (joint || battleOpponent !== outsidePlayer) || !joint && battleOpponent === requesterTeam) return joint ? "Select a teammate." : "Select an opponent.";
    if (battleType === "compound-op" && !["attacker", "defender"].includes(battleSide)) return "Select the reporting team\u2019s role.";
    if (!scored && !explicitOutcome && !Object.hasOwn(battleResultOptions(battleType), battleResult)) return "Select the battle result.";
  }
  if (scored && battleType === "joint-op") return "Choose a Joint Op outcome.";
  if (scored && !validBattleScores(battle)) return "Enter a non-negative whole-number score for each participant.";
  const jointOutcome = battleType === "joint-op" && ["joint-win", "joint-loss"].includes(battle.battleOutcome);
  if (!scored && explicitOutcome && !jointOutcome && battle.battleOutcome !== "draw" && !battleParticipants(battle).includes(battle.battleOutcome)) {
    return "Select a participating winner or a draw.";
  }
  if (!(battleLocation && battleLocation === recordedLocation) && !battleLocationOptions(battle, tiles).some((tile) => tile.id === battleLocation)) return "Select an eligible battle tile.";
  return "";
}
var battleRewardFields = {
  campaignPoints: { label: "Campaign Points", max: Number.MAX_SAFE_INTEGER },
  supplyPoints: { label: "Supply Points", max: 10 },
  credits: { label: "Credits", max: Number.MAX_SAFE_INTEGER }
};
function validRewardOverrides(battle, teams3, overrides) {
  if (!overrides || typeof overrides !== "object" || Array.isArray(overrides)) return false;
  const participants = battleParticipants(battle);
  return Object.entries(overrides).every(([team, values]) => teams3.includes(team) && participants.includes(team) && values && typeof values === "object" && !Array.isArray(values) && Object.entries(values).length > 0 && Object.entries(values).every(([field, amount]) => Object.hasOwn(battleRewardFields, field) && Number.isSafeInteger(amount) && amount >= 0 && amount <= battleRewardFields[field].max));
}
function battlePayoutAwards(battle, settings, teams3, overrides = {}) {
  let result = battle;
  if (Object.hasOwn(battle, "battleScores")) {
    if (!validBattleScores(battle)) return [];
    const { winners, tied } = battleOutcome(battle);
    result = { ...battle, battleOutcome: winners[0] ?? "draw", battleTiedTeams: tied };
  }
  const defaults = globalThis.ExpeditionPointRewards.battleAwards(result, settings, teams3);
  const awards = new Map(defaults.map((award) => [`${award[0]}:${award[1]}`, award]));
  for (const [team, values] of Object.entries(overrides)) {
    for (const [field, amount] of Object.entries(values)) awards.set(`${team}:${field}`, [team, field, amount]);
  }
  return [...awards.values()].filter(([, , amount]) => amount > 0);
}
function projectedBattlePayouts(battle, settings, teams3, balances, overrides) {
  const rows = battleParticipants(battle).filter((team) => teams3.includes(team)).map((team) => ({ team, campaignPoints: 0, supplyPoints: 0, credits: 0 }));
  for (const [team, field, amount] of battlePayoutAwards(battle, settings, teams3, overrides)) {
    const row = rows.find((row2) => row2.team === team);
    if (!row) continue;
    row[field] = Math.min(amount, Math.max(0, battleRewardFields[field].max - (balances?.[team]?.[field] ?? 0)));
    if (row[field] < amount) (row.cappedRewards ??= {})[field] = amount;
  }
  return rows;
}

// Expedition/unit-rules.mjs
var unitStatFields = [
  { key: "apl", label: "APL", min: 0, suffix: "" },
  { key: "move", label: "Move", min: 0, suffix: "\u2033" },
  { key: "save", label: "Save", min: 1, suffix: "+" },
  { key: "wounds", label: "Wounds", min: 1, suffix: "" }
];
var unitRuleLimits = { name: 100, text: 4e3 };
var trimText = (value) => typeof value === "string" ? value.trim() : "";
var validRuleText = (value) => value.length > 0 && value.length <= unitRuleLimits.text;
function validateUnitRule(input, isAction) {
  const name = trimText(input?.name);
  if (!name || name.length > unitRuleLimits.name) {
    return { error: `Enter a name from 1 to ${unitRuleLimits.name} characters.` };
  }
  if (!isAction) {
    const description = trimText(input.description);
    return validRuleText(description) ? { profile: { name, description } } : { error: `Enter an ability description from 1 to ${unitRuleLimits.text} characters.` };
  }
  const rawEffects = Object.hasOwn(input, "effects") ? input.effects : [input.description];
  const effects = Array.isArray(rawEffects) ? rawEffects.map(trimText) : [];
  if (!effects.length || !effects.every(validRuleText)) {
    return { error: `Add at least one effect. Each effect must contain 1 to ${unitRuleLimits.text} characters.` };
  }
  const { ap } = input;
  const restriction = trimText(input.restriction);
  if (!Number.isSafeInteger(ap) || ap < 0) return { error: "Enter a whole-number AP cost of at least 0." };
  if (input.restriction != null && typeof input.restriction !== "string" || restriction.length > unitRuleLimits.text) {
    return { error: `Enter the restriction as text up to ${unitRuleLimits.text} characters.` };
  }
  return { profile: { name, description: effects.join("\n\n"), effects, ap, restriction } };
}
var weaponTypes = { ranged: "Ranged", melee: "Melee" };
var weaponLimits = { name: 100, dmg: 40, wr: 300 };
function validateWeaponProfile(input) {
  const { type, atk, hit } = input ?? {};
  const name = typeof input?.name === "string" ? input.name.trim() : "";
  const dmg = typeof input?.dmg === "string" ? input.dmg.trim() : "";
  const wr = typeof input?.wr === "string" ? input.wr.trim() : "";
  if (typeof type !== "string" || !Object.hasOwn(weaponTypes, type)) return { error: "Select Ranged or Melee." };
  if (!name || name.length > weaponLimits.name) return { error: "Enter a weapon name from 1 to 100 characters." };
  if (!Number.isSafeInteger(atk) || atk < 0) return { error: "Enter a whole-number ATK value of at least 0." };
  if (!Number.isSafeInteger(hit) || hit < 1) return { error: "Enter a whole-number HIT value of at least 1." };
  if (dmg.length > weaponLimits.dmg || !/^\d+(?:\s*\/\s*\d+)?$/.test(dmg)) {
    return { error: "Enter damage as a whole number or a pair such as 3/4." };
  }
  const damageValues = dmg.split("/").map(Number);
  if (!damageValues.every(Number.isSafeInteger)) return { error: "Enter smaller damage values." };
  if (input.wr != null && typeof input.wr !== "string" || wr.length > weaponLimits.wr) {
    return { error: "Enter Weapon Rules as text up to 300 characters." };
  }
  return { profile: { type, name, atk, hit, dmg: damageValues.join("/"), wr } };
}
var weaponRank = (weapon) => weapon.type === "ranged" ? 0 : weapon.type === "melee" ? 1 : 2;
function orderedUnitEntries(collection, entries = []) {
  return collection === "weapons" ? [...entries].sort((left, right) => weaponRank(left) - weaponRank(right)) : entries;
}
function unitMoveTarget(collection, entries, index, direction) {
  const target = index + direction;
  if (index < 0 || target < 0 || target >= entries.length) return -1;
  if (collection === "weapons" && weaponRank(entries[index]) !== weaponRank(entries[target])) return -1;
  return target;
}
var maxUnitImageFileBytes = 20 * 1024 * 1024;
var maxSavedImageBytes = 150 * 1024;
var imageData = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/;
function validUnitImage(value) {
  if (typeof value !== "string" || value.length > Math.ceil(maxSavedImageBytes / 3) * 4 + 32) return false;
  const [, type, encoded] = imageData.exec(value) ?? [];
  if (!encoded || encoded.length % 4 !== 0) return false;
  try {
    const bytes = atob(encoded);
    if (bytes.length > maxSavedImageBytes) return false;
    if (type === "image/png") return bytes.startsWith("\x89PNG\r\n\n");
    if (type === "image/jpeg") return bytes.startsWith("\xFF\xD8\xFF");
    return bytes.startsWith("RIFF") && bytes.slice(8, 12) === "WEBP";
  } catch {
    return false;
  }
}

// Expedition/faction-equipment.mjs
var factionEquipmentSlotCount = 4;
var factionEquipmentLimits = { name: 100, description: 4e3 };
function factionEquipmentSlots(entries) {
  return Array.from({ length: factionEquipmentSlotCount }, (_, index) => entries?.[index] ?? null);
}

// Expedition/universal-equipment.mjs
var universalEquipment = [
  "Ammo Cache",
  "Portable Barricade",
  "Razor Wire",
  "Comms Device",
  "Mines",
  "Light Barricade",
  "Utility Grenades",
  "Heavy Barricade",
  "Ladders",
  "Explosive Grenades",
  "Breaching Charge"
].map((name) => ({
  id: name.toLowerCase().replaceAll(" ", "-"),
  name,
  description: ""
}));

// preview/expedition-api.mjs
var { validateSettings, readSettings, battleFields, mapGroups } = globalThis.ExpeditionPointRewards;
var teams = expeditionTeams.filter(Boolean);
var isBattle = (request) => request?.changeSet?.requestType === "battle";
var battleStateKey = "expedition-preview-battles";
var roundStorageKey = "expedition-preview-round";
var shopStorageKey = "expedition-preview-shop";
var universalEquipmentStorageKey = "expedition-preview-universal-equipment";
var unitEntryTypes = {
  weapons: { key: "weapon", validate: validateWeaponProfile },
  abilities: { key: "ability", validate: (input) => validateUnitRule(input, false) },
  actions: { key: "action", validate: (input) => validateUnitRule(input, true) }
};
var supplyCostActions = ["manoeuvre", "regroup", "scout", "encamp", "demolish", "search"];
var requestSettings = {
  "/supply-point-costs": {
    field: "supplyPointCosts",
    label: "Supply Point costs",
    validate: validSupplyCosts,
    invalidMessage: "Enter a whole number from 0 to 10 for each Supply Point cost."
  },
  "/movement-limit": {
    field: "movementLimit",
    label: "Movement limit",
    validate: (value) => Number.isSafeInteger(value) && value >= 0,
    invalidMessage: "Enter a non-negative whole number for the movement limit."
  },
  "/point-rewards": {
    field: "pointRewards",
    label: "Point rewards",
    validate: validateSettings,
    invalidMessage: "Enter non-negative whole numbers, with Supply Points at most 10 and each camp minimum at most its maximum."
  }
};
function validSupplyCosts(costs) {
  return costs && Object.keys(costs).length === supplyCostActions.length && supplyCostActions.every((action) => Object.hasOwn(costs, action) && Number.isInteger(costs[action]) && costs[action] >= 0 && costs[action] <= 10);
}
var validCredits = (credits) => Number.isSafeInteger(credits) && credits >= 0;
var validRound = (round) => Number.isSafeInteger(round) && round >= 1;
var positiveQuantity = (value) => Number.isSafeInteger(value) && value > 0;
var purchaseRemaining = (purchase) => purchase.quantity - (purchase.usedQuantity ?? 0);
function equipmentAction(value) {
  if (value === void 0) return "";
  if (typeof value !== "string") return null;
  const action = value.trim();
  return action.length <= factionEquipmentLimits.description ? action : null;
}
var equipmentRules = ({ description, action }) => ({
  ...description ? { description } : {},
  ...action ? { action } : {}
});
var validStockLimit = (value) => value === null || positiveQuantity(value);
function validTeamPoints(points) {
  return Number.isSafeInteger(points?.supplyPoints) && points.supplyPoints >= 0 && points.supplyPoints <= 10 && Number.isSafeInteger(points.campaignPoints) && points.campaignPoints >= 0 && (!Object.hasOwn(points, "credits") || validCredits(points.credits));
}
function getTeamLocations(tiles) {
  const locations = new Map(teams.map((team) => [team, { bases: [], camps: [], positions: [] }]));
  for (const tile of Array.isArray(tiles) ? tiles : []) {
    if (typeof tile?.id !== "string" || !tile.id) continue;
    const owner = locations.get(tile.structureColor);
    if (tile.structure === "base") owner?.bases.push(tile.id);
    if (tile.structure === "camp") owner?.camps.push(tile.id);
    locations.get(tile.marker)?.positions.push(tile.id);
    if (tile.secondaryMarker !== tile.marker) locations.get(tile.secondaryMarker)?.positions.push(tile.id);
  }
  return locations;
}
function createExpeditionApi(seed, accounts, storage, { battlesEnabled = expeditionBattlesEnabled, identify } = {}) {
  let map = structuredClone(seed);
  let savedRound;
  const readSavedRound = () => {
    try {
      const stored = Number(storage?.getItem(roundStorageKey));
      if (validRound(stored)) return stored;
    } catch {
    }
    return savedRound;
  };
  const readRound = () => {
    const round = readSavedRound() ?? Number(map.round);
    return validRound(round) ? round : 1;
  };
  const rosters = /* @__PURE__ */ new Map();
  const rosterKey = (team) => `expedition-preview-roster-${team}`;
  const readRoster = (team) => {
    const stored = storage?.getItem(rosterKey(team));
    if (!stored) return rosters.get(team) ?? { units: [], items: [] };
    const { units, items, displayName, lore, factionEquipment } = JSON.parse(stored);
    if (!Array.isArray(units) || !Array.isArray(items)) throw new Error("Invalid stored roster.");
    return {
      units,
      items,
      ...Array.isArray(factionEquipment) ? { factionEquipment } : {},
      ...typeof displayName === "string" && displayName.trim() ? { displayName } : {},
      ...typeof lore === "string" ? { lore } : {}
    };
  };
  const writeRoster = (team, roster) => {
    if (storage) storage.setItem(rosterKey(team), JSON.stringify(roster));
    else rosters.set(team, roster);
  };
  let universalProfiles = {};
  const readUniversalProfiles = () => {
    const stored = storage?.getItem(universalEquipmentStorageKey);
    return stored ? JSON.parse(stored) : universalProfiles;
  };
  const universalCatalog = () => {
    const profiles = readUniversalProfiles();
    return universalEquipment.map((item) => ({ ...item, ...profiles[item.id] }));
  };
  let shopState;
  const readShop = () => {
    if (shopState) return shopState;
    const items = JSON.parse(storage?.getItem(shopStorageKey) ?? "[]");
    if (!Array.isArray(items)) throw new Error("Invalid stored shop inventory.");
    return {
      items: items.map((item) => ({ ...item, perUser: 1, remaining: null })),
      purchases: []
    };
  };
  const readTeamPoints = (team) => {
    const { supplyPoints, campaignPoints, credits } = map.teamStats?.[team] ?? {};
    return {
      supplyPoints: Number.isSafeInteger(supplyPoints) && supplyPoints > 0 ? Math.min(10, supplyPoints) : 0,
      campaignPoints: Number.isSafeInteger(campaignPoints) && campaignPoints > 0 ? campaignPoints : 0,
      credits: validCredits(credits) ? credits : 0
    };
  };
  function withCurrentCredits(teamStats) {
    if (!teamStats || typeof teamStats !== "object" || Array.isArray(teamStats)) return map.teamStats;
    const next = structuredClone(teamStats);
    for (const team of teams) {
      const credits = map.teamStats?.[team]?.credits;
      if (validCredits(credits)) next[team] = { ...next[team], credits };
      else if (next[team]) delete next[team].credits;
    }
    return next;
  }
  const savedSettings = {};
  for (const { field, validate } of Object.values(requestSettings)) {
    if (validate(map[field])) savedSettings[field] = map[field];
    delete map[field];
  }
  const storageKey = (route) => `expedition-preview-${route.slice(1)}`;
  const readMap = () => {
    const result = { ...map, ...savedSettings };
    const round = readSavedRound();
    if (round !== void 0) result.round = round;
    for (const [route, { field, validate }] of Object.entries(requestSettings)) {
      try {
        const value = JSON.parse(storage?.getItem(storageKey(route)) ?? "null");
        if (validate(value)) result[field] = value;
      } catch {
      }
    }
    return result;
  };
  let requests = [];
  let lorePosts = [];
  function purchaseUses(reports) {
    const uses = /* @__PURE__ */ new Map();
    for (const report of reports) {
      for (const { items } of report.equipmentUsed ?? []) {
        for (const item of items) {
          if (item.kind === "purchased") uses.set(item.id, (uses.get(item.id) ?? 0) + item.quantity);
        }
      }
    }
    return uses;
  }
  function battleEquipmentOptions(team, replacingReport) {
    const reserved = purchaseUses(requests.filter((report) => report.status === "pending" && report.id !== replacingReport));
    const faction = factionEquipmentSlots(readRoster(team).factionEquipment).flatMap((entry, index) => entry ? [{ id: `faction:${index + 1}`, name: entry.name, kind: "faction", available: 1, ...equipmentRules(entry) }] : []);
    const purchased = readShop().purchases.filter((item) => item.team === team).map((item) => ({
      id: item.id,
      name: item.name,
      kind: "purchased",
      available: purchaseRemaining(item) - (reserved.get(item.id) ?? 0),
      ...equipmentRules(item)
    })).filter((item) => item.available > 0);
    const universal = universalCatalog().map((item) => ({ ...item, id: `universal:${item.id}`, kind: "universal", available: 1 }));
    return [...faction, ...purchased, ...universal];
  }
  function readBattleEquipment(choices, team, replacingReport) {
    if (!Array.isArray(choices) || choices.some((choice) => typeof choice?.id !== "string" || !positiveQuantity(choice.quantity)) || equipmentCount(choices) > battleEquipmentLimit || new Set(choices.map((choice) => choice.id)).size !== choices.length) {
      return { status: 400, message: `Choose up to ${battleEquipmentLimit} pieces of equipment.` };
    }
    if (!choices.length) return { items: [] };
    let options;
    try {
      options = new Map(battleEquipmentOptions(team, replacingReport).map((item) => [item.id, item]));
    } catch {
      return { status: 500, message: "Unable to load available battle equipment." };
    }
    const items = [];
    for (const { id, quantity } of choices) {
      const option = options.get(id);
      if (!option || quantity > option.available) return { status: 409, message: "Some selected equipment is unavailable. Refresh the equipment list and choose again." };
      items.push({ id, quantity, name: option.name, kind: option.kind });
    }
    return { items };
  }
  function commitCampaignState(nextRequests, teamStats = map.teamStats, shop = shopState, nextMap) {
    try {
      const state = { battles: nextRequests.filter(isBattle), teamStats, shop };
      if (storage?.writeCampaignState) storage.writeCampaignState({ ...state, map: nextMap });
      else storage?.setItem(battleStateKey, JSON.stringify(state));
      requests = nextRequests;
      map.teamStats = teamStats;
      shopState = shop;
      return true;
    } catch {
      return false;
    }
  }
  const reply = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
  async function handleRequest(account, input, options = {}) {
    let identity;
    if (identify) {
      identity = identify(account);
    } else {
      if (!account || !roles.includes(account.role)) return reply({ message: "Invalid simulated account." }, 401);
      const saved = accounts.find(account.username);
      const role2 = expeditionRole({ ...saved, role: account.role });
      identity = {
        role: role2,
        team: saved?.expeditionTeam || "",
        membershipRole: saved?.expeditionMembershipRole || "viewer",
        user: { id: saved?.id || `preview:${account.username.trim().toLowerCase()}`, username: account.username, role: account.role }
      };
    }
    const { user, role, team, membershipRole } = identity;
    const admin = ["admin", "owner"].includes(role);
    const canManageRoles = admin || user.role === "manager";
    const route = new URL(input).pathname.replace(/^\/expedition/, "");
    const method = (options.method || "GET").toUpperCase();
    let body;
    try {
      body = options.body ? JSON.parse(options.body) : {};
    } catch {
      return reply({ message: "Invalid JSON request." }, 400);
    }
    const forbidden = () => reply({ message: "This account cannot perform that Expedition action." }, 403);
    const battlesUnavailable = () => reply({ message: battlesUnavailableMessage }, 503);
    if (!battlesEnabled && ["/battles", "/battle-settings", "/battle-equipment"].includes(route)) return battlesUnavailable();
    const own = (request) => user.id != null && request.requesterUserId === user.id;
    const canSeeBattle = (request) => admin || own(request) || team && battleParticipants(request.changeSet).includes(team);
    const canLog = admin || role === "traveler" && Boolean(team);
    const battleReview = (request) => {
      const { changeSet, status } = request;
      const sameTeamJointOp = changeSet.battleType === "joint-op" && changeSet.battleOpponent === changeSet.requesterTeam;
      const requiredTeams = battleParticipants(changeSet).filter((participant) => teams.includes(participant) && (participant !== changeSet.requesterTeam || sameTeamJointOp));
      const confirmedTeams = (request.confirmedTeams ?? []).filter((participant) => requiredTeams.includes(participant));
      return {
        requiredTeams,
        confirmedTeams,
        canConfirm: status === "pending" && canLog && !own(request) && requiredTeams.includes(team) && !confirmedTeams.includes(team),
        canApprove: status === "pending" && admin,
        canEdit: status === "accepted" ? admin : status === "pending" && (admin || canLog && own(request)),
        requiresAdminApproval: Object.keys(request.rewardOverrides ?? {}).length > 0
      };
    };
    const battleReport = ({ requesterEmail, historical, ...request }) => ({
      ...request,
      own: own(request),
      revision: request.revision ?? 1,
      review: historical ? { ...battleReview(request), canEdit: false } : battleReview(request),
      ...request.status === "pending" ? {
        projectedRewards: projectedBattlePayouts(request.changeSet, readMap().pointRewards, teams, map.teamStats, request.rewardOverrides)
      } : {}
    });
    const isStaleReview = (request) => body?.expectedRevision != null && body.expectedRevision !== (request.revision ?? 1);
    const staleReview = () => reply({ message: "The battle report was edited. Refresh the report before continuing." }, 409);
    const saveError = () => reply({ message: "Unable to save Expedition battles and point balances in browser storage." }, 500);
    const acceptRequest = (request, awards, approvalMethod, shop = shopState) => {
      const stats = structuredClone(map.teamStats ?? {});
      const awardedPoints = [];
      for (const [recipient, field, amount] of awards) {
        stats[recipient] ??= { supplyPoints: 0, campaignPoints: 0 };
        const limit = field === "supplyPoints" ? 10 : Number.MAX_SAFE_INTEGER;
        const previous = stats[recipient][field] ?? 0;
        stats[recipient][field] = Math.min(limit, Math.max(0, previous + amount));
        const gained = stats[recipient][field] - previous;
        if (gained > 0) awardedPoints.push({ team: recipient, field, amount: gained });
      }
      const battle = isBattle(request);
      const updated = {
        ...request,
        status: "accepted",
        reviewedAt: (/* @__PURE__ */ new Date()).toISOString(),
        reviewedByUsername: user.username,
        ...battle ? { awardedPoints, approvalMethod } : {}
      };
      const next = requests.some((item) => item.id === updated.id) ? requests.map((item) => item.id === updated.id ? updated : item) : [...requests, updated];
      if (!commitCampaignState(next, stats, shop)) return saveError();
      return reply({ request: battle ? battleReport(updated) : updated, map: readMap(), message: "Expedition request accepted." });
    };
    const acceptBattle = (request, approvalMethod) => {
      const uses = purchaseUses([request]);
      let shop = shopState;
      if (uses.size) {
        const current = readShop();
        const purchases = new Map(current.purchases.map((item) => [item.id, item]));
        for (const [id, quantity] of uses) {
          const item = purchases.get(id);
          if (!item || quantity > purchaseRemaining(item)) return reply({ message: "Purchased equipment used in this report is unavailable." }, 409);
        }
        shop = { ...current, purchases: current.purchases.map((item) => uses.has(item.id) ? { ...item, usedQuantity: (item.usedQuantity ?? 0) + uses.get(item.id) } : item) };
      }
      return acceptRequest(request, battlePayoutAwards(request.changeSet, readMap().pointRewards, teams, request.rewardOverrides), approvalMethod, shop);
    };
    try {
      const stored = storage?.getItem(battleStateKey);
      if (stored) {
        const { battles, teamStats, shop, map: savedMap } = JSON.parse(stored);
        requests = [...requests.filter((request) => !isBattle(request)), ...battles];
        if (savedMap) map = savedMap;
        if (teamStats) map.teamStats = teamStats;
        shopState = shop;
      }
    } catch {
      return reply({ message: "Unable to load Expedition battles and point balances from browser storage." }, 500);
    }
    if (route === "/battles" || route === "/lore") {
      requests = [...requests.filter((request) => !request.historical), ...options.historicalBattles ?? []];
    }
    if (route === "/shop" || route.startsWith("/shop/")) {
      const purchase = route === "/shop/purchase" && method === "POST";
      const create = route === "/shop" && method === "POST";
      const read = route === "/shop" && method === "GET";
      const manage = route === "/shop" && method === "PATCH";
      if (!read && !create && !manage && !purchase) return reply({ message: "Invalid shop action." }, 405);
      const canPurchase = teams.includes(team) && (admin || role === "traveler");
      if (purchase ? !canPurchase : !read && !admin) return forbidden();
      try {
        let catalog = function(state, balance2 = credits) {
          const owned2 = /* @__PURE__ */ new Map();
          for (const entry of state.purchases) {
            if (entry.buyer === user.id) owned2.set(entry.listingId, (owned2.get(entry.listingId) ?? 0) + entry.quantity);
          }
          return {
            items: state.items.filter((item2) => admin || item2.visible === true).map((item2) => ({ ...item2, owned: owned2.get(item2.id) ?? 0 })),
            canManage: admin,
            canPurchase,
            credits: balance2
          };
        };
        const shop = readShop();
        const { items, purchases } = shop;
        const credits = canPurchase ? readTeamPoints(team).credits : null;
        if (read) return reply(catalog(shop));
        const saveError2 = () => reply({ message: "Unable to save the shop in browser storage." }, 500);
        if (create) {
          const name = typeof body?.name === "string" ? body.name.trim() : "";
          const description = typeof body?.description === "string" ? body.description.trim() : "";
          if (!name || name.length > 100) return reply({ message: "Enter a name from 1 to 100 characters." }, 400);
          if (!description || description.length > 2e3) return reply({ message: "Enter an ability from 1 to 2,000 characters." }, 400);
          const action = equipmentAction(body.action);
          if (action === null) return reply({ message: "Enter the optional action as text up to 4,000 characters." }, 400);
          if (!validCredits(body.cost)) return reply({ message: "Enter a credit cost of 0 or more in whole numbers." }, 400);
          const item2 = { id: crypto.randomUUID(), name, description, ...action ? { action } : {}, cost: body.cost, visible: false, perUser: 1, remaining: null };
          const next2 = { ...shop, items: [...items, item2] };
          return commitCampaignState(requests, map.teamStats, next2) ? reply({ ...catalog(next2), message: `${name} added to Backrooms.` }, 201) : saveError2();
        }
        const item = items.find((entry) => entry.id === body?.id);
        if (!item || purchase && item.visible !== true) {
          return reply({ ...purchase && catalog(shop), message: "Shop listing not found." }, 404);
        }
        const replaceItem = (updated2) => items.map((entry) => entry === item ? updated2 : entry);
        if (manage) {
          const { stock, visible } = body;
          if (visible !== false && (!validStockLimit(stock?.perUser) || !validStockLimit(stock?.total))) {
            return reply({ message: "Enter a whole number of at least 1 or choose Unlimited." }, 400);
          }
          const updated2 = visible === false ? { ...item, visible: false } : { ...item, visible: true, perUser: stock.perUser, remaining: stock.total };
          const next2 = { ...shop, items: replaceItem(updated2) };
          const message = visible === false ? `${item.name} removed from Storefront.` : `${item.name} stocked in Storefront.`;
          return commitCampaignState(requests, map.teamStats, next2) ? reply({ ...catalog(next2), message }) : saveError2();
        }
        const { quantity } = body;
        if (!positiveQuantity(quantity)) return reply({ message: "Enter a quantity of at least 1." }, 400);
        if (item.remaining !== null && quantity > item.remaining) {
          return reply({ ...catalog(shop), message: "There is not enough stock for this purchase." }, 409);
        }
        const owned = purchases.filter((entry) => entry.listingId === item.id && entry.buyer === user.id).reduce((sum, entry) => sum + entry.quantity, 0);
        if (item.perUser !== null && quantity > item.perUser - owned) {
          return reply({ ...catalog(shop), message: "This purchase exceeds your limit for this item." }, 409);
        }
        const cost = item.cost * quantity;
        if (cost > credits) return reply({ ...catalog(shop), message: "Your team does not have enough credits." }, 409);
        const equipment = {
          id: crypto.randomUUID(),
          listingId: item.id,
          buyer: user.id,
          team,
          name: item.name,
          description: item.description,
          ...item.action ? { action: item.action } : {},
          quantity
        };
        const balance = credits - cost;
        const stats = { ...map.teamStats, [team]: { ...map.teamStats?.[team], credits: balance } };
        const updated = { ...item, remaining: item.remaining === null ? null : item.remaining - quantity };
        const next = { items: replaceItem(updated), purchases: [...purchases, equipment] };
        return commitCampaignState(requests, stats, next) ? reply({ ...catalog(next, balance), message: `${item.name} added to team Equipment.` }, 201) : saveError2();
      } catch {
        return reply({ message: "Unable to load or save the shop in browser storage." }, 500);
      }
    }
    const patron = (target) => ({
      id: target.id,
      username: target.username,
      email: "",
      siteRole: target.role,
      expeditionRole: expeditionRole(target),
      expeditionMembershipRole: target.role === "owner" ? "owner" : target.expeditionMembershipRole || "viewer",
      expeditionTeam: target.expeditionTeam || "",
      canEditExpeditionRole: canManageRoles && target.role !== "owner",
      canEditExpeditionTeam: admin && (target.role !== "owner" || role === "owner")
    });
    if (route === "/access") return reply({ user, access: { role, membershipRole, team, canManageRoles, canUseAdminMode: admin } });
    if (route === "/roles/list") return canManageRoles ? reply({ patrons: accounts.list().map(patron) }) : forbidden();
    if (route === "/roles/set-role" && method === "POST") {
      if (!canManageRoles) return forbidden();
      const target = accounts.list().find((item) => item.id === body.targetUserId);
      if (!target) return reply({ message: "Saved account not found." }, 404);
      const currentRole = target.expeditionMembershipRole || "viewer";
      const currentTeam = target.expeditionTeam || "";
      const nextRole = target.role === "owner" && body.role === "owner" ? currentRole : body.role;
      const nextTeam = admin ? body.team : currentTeam;
      if (target.role === "owner" && (nextRole !== currentRole || role !== "owner" && (!admin || nextTeam !== currentTeam))) return forbidden();
      if (!expeditionRoles.includes(nextRole) || !expeditionTeams.includes(nextTeam)) return reply({ message: "Invalid Expedition permission or team." }, 400);
      try {
        return reply({ patron: patron(accounts.assignExpedition(target.id, nextRole, nextTeam)), message: "Expedition membership saved." });
      } catch (error) {
        return reply({ message: error.message }, 500);
      }
    }
    if (route === "/round") {
      if (method === "GET") return reply({ round: readRound() });
      if (method === "POST") {
        if (!admin) return forbidden();
        const { round, expectedRound } = body ?? {};
        if (!validRound(round) || !validRound(expectedRound)) {
          return reply({ message: "Enter a whole round number of at least 1." }, 400);
        }
        const current = readRound();
        if (current !== expectedRound) {
          return reply({ round: current, message: "The round changed while you were editing. Review the current round before saving." }, 409);
        }
        try {
          storage?.setItem(roundStorageKey, String(round));
          savedRound = round;
          return reply({ round, message: "Expedition round saved." });
        } catch {
          return reply({ message: "Unable to save the round in browser storage." }, 500);
        }
      }
    }
    if (route === "/lore") {
      const canPost = canLog && teams.includes(team);
      const round = readRound();
      const tiles = (map.tiles ?? []).filter((tile) => typeof tile?.id === "string" && tile.id && Number(tile.type) !== 0).map(({ id, locationNumber }) => ({ id, locationNumber }));
      const visibleBattles = battlesEnabled ? requests.filter((request) => isBattle(request) && request.status === "accepted" && canSeeBattle(request)) : [];
      const battleById = new Map(visibleBattles.map(({ id, changeSet, createdAt }) => [id, {
        id,
        name: typeof changeSet.battleName === "string" && changeSet.battleName.trim() || "Unnamed battle",
        type: battleTypes[changeSet.battleType],
        date: String(changeSet.battleDate || createdAt || "").slice(0, 10),
        round: battleSubmissionRound(changeSet),
        tileId: typeof changeSet.battleLocation === "string" ? changeSet.battleLocation.trim() || null : null
      }]));
      const eligibleBattleIds = new Set(canPost ? visibleBattles.filter(({ changeSet }) => battleParticipants(changeSet).includes(team)).map(({ id }) => id) : []);
      const visiblePost = ({ battleId: battleId2, ...post }) => ({
        ...post,
        battle: battleById.get(battleId2) ?? null,
        hasBattle: Boolean(battleId2)
      });
      if (method !== "GET" && method !== "POST") return reply({ message: "Invalid lore action." }, 405);
      if (method === "POST" && !canPost) return forbidden();
      try {
        const posts = storage?.readLore?.() ?? lorePosts;
        if (method === "GET") {
          const battles = [...eligibleBattleIds].map((id) => battleById.get(id)).sort((first, second) => second.date.localeCompare(first.date));
          return reply({ posts: posts.map(visiblePost), round, canPost, tiles, battles });
        }
        const title = typeof body?.title === "string" ? body.title.trim() : "";
        const text = typeof body?.text === "string" ? body.text.trim() : "";
        if (!title || title.length > 120 || !text || text.length > 12e3) {
          return reply({ message: "Enter a title of up to 120 characters and lore of up to 12,000 characters." }, 400);
        }
        const battleId2 = body.battleId ?? "";
        if (battleId2 !== "" && !eligibleBattleIds.has(battleId2)) {
          return reply({ message: "Choose an approved battle your team participated in." }, 400);
        }
        const linkedBattle = battleById.get(battleId2);
        const manualTile = typeof body.tileId === "string" ? body.tileId.trim() : body.tileId ?? "";
        const tileId = linkedBattle?.tileId ?? manualTile;
        if (linkedBattle?.tileId == null && tileId !== "" && !tiles.some((tile) => tile.id === tileId)) {
          return reply({ message: "Enter an existing map tile ID, such as 9-20." }, 400);
        }
        const linkedRound = linkedBattle?.round;
        if (linkedRound == null && (!validRound(body.round) || body.round > round)) {
          return reply({ message: `Choose a round from 1 through ${round}.` }, 400);
        }
        const post = {
          id: crypto.randomUUID(),
          title,
          text,
          round: linkedRound ?? body.round,
          team,
          teamName: readRoster(team).displayName ?? "",
          author: user.username,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          tileId,
          battleId: battleId2
        };
        const next = [post, ...posts];
        if (storage?.writeLore) storage.writeLore(next);
        else lorePosts = next;
        return reply({ post: visiblePost(post) }, 201);
      } catch {
        return reply({ message: `Unable to ${method === "POST" ? "save" : "load"} Expedition lore.` }, 500);
      }
    }
    if (route === "/battles" && method === "GET") {
      const visible = requests.filter((request) => isBattle(request) && canSeeBattle(request));
      return reply({
        battles: visible.filter((request) => request.status === "accepted").map(battleReport),
        pendingBattles: visible.filter((request) => request.status === "pending" && (canLog || own(request))).map(battleReport),
        team,
        teams,
        canLog,
        canReview: admin
      });
    }
    if (route === "/battle-equipment" && method === "GET") {
      const params = new URL(input).searchParams;
      const target = params.get("team");
      if (!canLog || !teams.includes(target) || !admin && team !== target) return forbidden();
      const editing = requests.find((report) => report.id === params.get("edit") && report.status === "pending" && isBattle(report) && own(report));
      try {
        return reply({ equipment: battleEquipmentOptions(target, editing?.id) });
      } catch {
        return reply({ message: "Unable to load available battle equipment." }, 500);
      }
    }
    if (route === "/universal-equipment" && method === "PATCH") {
      if (!admin) return forbidden();
      const item = universalEquipment.find((entry) => entry.id === body?.id);
      if (!item) return reply({ message: "Universal equipment not found." }, 404);
      const description = typeof body.description === "string" ? body.description.trim() : null;
      const action = equipmentAction(body.action);
      if (description === null || description.length > factionEquipmentLimits.description || action === null) {
        return reply({ message: "Enter ability and action text up to 4,000 characters each." }, 400);
      }
      try {
        const profiles = readUniversalProfiles();
        const current = { ...item, ...profiles[item.id] };
        if (body.expectedDescription !== current.description || body.expectedAction !== (current.action ?? "")) {
          return reply({ equipment: current, message: "This equipment changed while you were editing. Review the saved rules before saving again." }, 409);
        }
        const updated = { ...item, description, ...action ? { action } : {} };
        const next = { ...profiles, [item.id]: { description, ...action ? { action } : {} } };
        storage?.setItem(universalEquipmentStorageKey, JSON.stringify(next));
        universalProfiles = next;
        return reply({ equipment: updated, message: "Universal equipment saved." });
      } catch {
        return reply({ message: "Unable to save universal equipment in browser storage." }, 500);
      }
    }
    if (method === "POST" && (route === "/battle-settings" || Object.hasOwn(requestSettings, route))) {
      if (!admin) return forbidden();
      const settingsRoute = route === "/battle-settings" ? "/point-rewards" : route;
      const { field, label, validate, invalidMessage } = requestSettings[settingsRoute];
      let value = body?.[field];
      if (settingsRoute === "/point-rewards" && (route === "/battle-settings" || !validate(value))) {
        const fields = route === "/battle-settings" ? battleFields : mapGroups.flatMap(([, group]) => group);
        if (!value || Object.keys(value).length !== fields.length || !fields.every(([key]) => Object.hasOwn(value, key))) {
          return reply({ message: invalidMessage }, 400);
        }
        value = { ...readSettings(readMap().pointRewards), ...value };
      }
      if (!validate(value)) return reply({ message: invalidMessage }, 400);
      if (!battlesEnabled && settingsRoute === "/point-rewards") {
        const existing = readSettings(readMap().pointRewards);
        value = { ...value, ...Object.fromEntries(battleFields.map(([key]) => [key, existing[key]])) };
      }
      try {
        storage?.setItem(storageKey(settingsRoute), JSON.stringify(value));
      } catch {
        return reply({ message: `Unable to save ${label.toLowerCase()} in browser storage.` }, 500);
      }
      savedSettings[field] = value;
      return reply({ [field]: value, message: `${label} saved.` });
    }
    if (route === "/map" && method === "GET") return reply(readMap());
    if (route === "/map" && method === "POST") {
      if (!admin) return forbidden();
      if (!body.map || !Array.isArray(body.map.tiles)) return reply({ message: "A map with tiles is required." }, 400);
      const teamStats = storage?.writeCampaignState ? map.teamStats : withCurrentCredits(body.map.teamStats);
      if (!commitCampaignState(requests, teamStats, shopState, body.map)) return saveError();
      map = { ...structuredClone(body.map), ...map.teamStats ? { teamStats: map.teamStats } : {} };
      for (const { field } of Object.values(requestSettings)) delete map[field];
      return reply({ map: readMap(), message: "Expedition map saved locally." });
    }
    if (route === "/team-stats" && method === "POST") {
      if (!admin) return forbidden();
      const stats = body.teamStats;
      if (!stats || teams.some((team2) => !Number.isFinite(stats[team2]?.supplyPoints) || stats[team2].supplyPoints < 0 || !Number.isFinite(stats[team2]?.campaignPoints) || stats[team2].campaignPoints < 0)) return reply({ message: "Invalid team points." }, 400);
      if (!commitCampaignState(requests, withCurrentCredits(stats))) return saveError();
      return reply({ teamStats: map.teamStats, message: "Team points saved locally." });
    }
    if (route === "/teams" && method === "GET") {
      try {
        const locations = getTeamLocations(map.tiles);
        return reply({
          assignedTeam: team,
          universalEquipment: universalCatalog(),
          teams: teams.map((name) => {
            const roster = readRoster(name);
            const purchased = (shopState?.purchases ?? []).filter((item) => item.team === name && purchaseRemaining(item) > 0).map((item) => ({
              id: item.id,
              name: item.name,
              description: item.description,
              ...item.action ? { action: item.action } : {},
              quantity: purchaseRemaining(item)
            }));
            return {
              name,
              ...roster,
              items: [...roster.items, ...purchased],
              factionEquipment: factionEquipmentSlots(roster.factionEquipment),
              points: readTeamPoints(name),
              locations: locations.get(name),
              canAddEntries: admin || role === "traveler" && name === team,
              canAddEquipment: admin,
              canUploadUnitImages: role === "traveler" && name === team,
              canEditPoints: admin
            };
          })
        });
      } catch {
        return reply({ message: "Unable to load team rosters from browser storage." }, 500);
      }
    }
    const teamRoute = route.match(/^\/teams\/([a-z]+)\/(name|lore|units|items|faction-equipment|points|weapons|abilities|actions|unit-image|unit-order)$/);
    if (teamRoute && ["POST", "PATCH", "DELETE"].includes(method)) {
      const [, target, collection] = teamRoute;
      if (!teams.includes(target)) return reply({ message: "Expedition team not found." }, 404);
      const editing = method === "PATCH";
      const deleting = method === "DELETE";
      if (deleting && !["abilities", "actions"].includes(collection)) {
        return reply({ message: "Removal is available for abilities and actions." }, 405);
      }
      if (editing && ["name", "lore", "items", "faction-equipment", "points", "unit-image", "unit-order"].includes(collection)) {
        return reply({ message: "Use POST for this team endpoint." }, 405);
      }
      if (collection === "points") {
        if (!admin) return forbidden();
        if (!validTeamPoints(body?.points) || !validTeamPoints(body.expectedPoints)) {
          return reply({ message: "Enter whole-number balances with Supply Points from 0 to 10 and Campaign Points and Credits at least 0." }, 400);
        }
        const current = readTeamPoints(target);
        if (body.expectedPoints.supplyPoints !== current.supplyPoints || body.expectedPoints.campaignPoints !== current.campaignPoints || Object.hasOwn(body.points, "credits") && (body.expectedPoints.credits ?? 0) !== current.credits) {
          return reply({ points: current, message: "The balances changed while you were editing. Review the latest balances before saving." }, 409);
        }
        const { supplyPoints, campaignPoints, credits = current.credits } = body.points;
        const points = { supplyPoints, campaignPoints, credits };
        const stats = { ...map.teamStats, [target]: { ...map.teamStats?.[target], ...points } };
        if (!commitCampaignState(requests, stats)) return saveError();
        return reply({ points, message: "Team points saved." });
      }
      if (collection === "unit-image") {
        if (role !== "traveler" || target !== team) return forbidden();
        const image = body?.image;
        if (!validUnitImage(image)) return reply({ message: "Choose a valid PNG, JPEG, or WebP image." }, 400);
        try {
          const roster = readRoster(target);
          const unit = roster.units.find((entry2) => entry2.id === body.unitId);
          if (!unit) return reply({ message: "Unit not found on this team." }, 404);
          const units = roster.units.map((entry2) => entry2 === unit ? { ...entry2, image } : entry2);
          writeRoster(target, { ...roster, units });
          return reply({ image, message: "Unit image saved." });
        } catch {
          return reply({ message: "Unable to save the image in browser storage." }, 500);
        }
      }
      if (!admin && (role !== "traveler" || target !== team)) return forbidden();
      if (collection === "items" && !admin) return forbidden();
      if (collection === "faction-equipment") {
        const { slot, equipment, expectedEquipment } = body ?? {};
        const isEquipment = (entry2) => entry2 === null || entry2 && typeof entry2.name === "string" && typeof entry2.description === "string" && equipmentAction(entry2.action) !== null;
        if (!Number.isInteger(slot) || slot < 1 || slot > factionEquipmentSlotCount || !isEquipment(equipment) || !isEquipment(expectedEquipment)) {
          return reply({ message: `Choose a faction equipment slot from 1 to ${factionEquipmentSlotCount} and enter its name and description as text.` }, 400);
        }
        const name2 = equipment?.name.trim() ?? "";
        const description = equipment?.description.trim() ?? "";
        const action = equipmentAction(equipment?.action);
        if (equipment && (!name2 || name2.length > factionEquipmentLimits.name || description.length > factionEquipmentLimits.description)) {
          return reply({ message: `Enter a name up to ${factionEquipmentLimits.name} characters and a description up to ${factionEquipmentLimits.description} characters.` }, 400);
        }
        try {
          const roster = readRoster(target);
          const factionEquipment = factionEquipmentSlots(roster.factionEquipment);
          const current = factionEquipment[slot - 1];
          if (current?.name !== expectedEquipment?.name || current?.description !== expectedEquipment?.description || (current?.action ?? "") !== (expectedEquipment?.action ?? "")) {
            return reply({ equipment: current, message: "This slot changed while you were editing. Review the saved equipment before saving again." }, 409);
          }
          const updated = equipment ? { name: name2, description, ...action ? { action } : {} } : null;
          factionEquipment[slot - 1] = updated;
          writeRoster(target, { ...roster, factionEquipment });
          return reply({ equipment: updated, message: updated ? "Faction equipment saved." : "Faction equipment slot cleared." });
        } catch {
          return reply({ message: "Unable to save faction equipment in browser storage." }, 500);
        }
      }
      if (collection === "unit-order") {
        const { unitId, entryId, direction, collection: section } = body ?? {};
        if (typeof section !== "string" || !Object.hasOwn(unitEntryTypes, section) || ![-1, 1].includes(direction)) {
          return reply({ message: "Choose a section and a valid move direction." }, 400);
        }
        try {
          const roster = readRoster(target);
          const unit = roster.units.find((entry2) => entry2.id === unitId);
          if (!unit) return reply({ message: "Unit not found on this team." }, 404);
          const entries = [...orderedUnitEntries(section, unit[section] ?? [])];
          const index = entries.findIndex((entry2) => entry2.id === entryId);
          if (index === -1) return reply({ message: "Entry not found in this unit section." }, 404);
          const nextIndex = unitMoveTarget(section, entries, index, direction);
          if (nextIndex === -1) return reply({ message: "This entry cannot move further in that direction." }, 409);
          [entries[index], entries[nextIndex]] = [entries[nextIndex], entries[index]];
          const units = roster.units.map((entry2) => entry2 === unit ? { ...entry2, [section]: entries } : entry2);
          writeRoster(target, { ...roster, units });
          return reply({ order: entries.map((entry2) => entry2.id), message: "Order saved." });
        } catch {
          return reply({ message: "Unable to save the new order in browser storage." }, 500);
        }
      }
      if (collection === "name") {
        const displayName = typeof body?.name === "string" ? body.name.trim() : "";
        if (!displayName || displayName.length > 100) return reply({ message: "Enter a team name from 1 to 100 characters." }, 400);
        try {
          writeRoster(target, { ...readRoster(target), displayName });
          return reply({ displayName, message: "Team name saved." });
        } catch {
          return reply({ message: "Unable to save the team name in browser storage." }, 500);
        }
      }
      if (collection === "lore") {
        if (typeof body?.lore !== "string" || typeof body.expectedLore !== "string") {
          return reply({ message: "Enter team lore as text." }, 400);
        }
        try {
          const roster = readRoster(target);
          const current = roster.lore ?? "";
          if (body.expectedLore !== current) {
            return reply({ lore: current, message: "Team lore changed while you were editing. Review the saved version before saving again." }, 409);
          }
          const lore = body.lore.trim();
          writeRoster(target, { ...roster, lore });
          return reply({ lore });
        } catch {
          return reply({ message: "Unable to save team lore in browser storage." }, 500);
        }
      }
      if (Object.hasOwn(unitEntryTypes, collection)) {
        const { key, validate } = unitEntryTypes[collection];
        const { profile, error } = deleting ? {} : validate(body?.[key]);
        if (error) return reply({ message: error }, 400);
        try {
          const roster = readRoster(target);
          const unit = roster.units.find((entry2) => entry2.id === body?.unitId);
          if (!unit) return reply({ message: "Unit not found on this team." }, 404);
          const entries = unit[collection] ?? [];
          const existing = editing || deleting ? entries.find((entry2) => entry2.id === body.entryId) : null;
          if ((editing || deleting) && !existing) return reply({ message: `The ${key} was not found on this unit.` }, 404);
          if (deleting) {
            const units2 = roster.units.map((entry2) => entry2 === unit ? { ...entry2, [collection]: entries.filter((item) => item !== existing) } : entry2);
            writeRoster(target, { ...roster, units: units2 });
            return reply({ entryId: existing.id, message: `${existing.name} removed.` });
          }
          const updated = { ...existing, id: existing?.id ?? crypto.randomUUID(), ...profile };
          const updatedEntries = editing ? entries.map((entry2) => entry2 === existing ? updated : entry2) : [...entries, updated];
          const units = roster.units.map((entry2) => entry2 === unit ? { ...entry2, [collection]: orderedUnitEntries(collection, updatedEntries) } : entry2);
          writeRoster(target, { ...roster, units });
          return reply({ [key]: updated, message: `${updated.name} ${editing ? "saved" : "added"}.` }, editing ? 200 : 201);
        } catch {
          return reply({ message: "Unable to save the team roster in browser storage." }, 500);
        }
      }
      const name = typeof body?.name === "string" ? body.name.trim() : "";
      if (!name || name.length > 100) return reply({ message: "Enter a name from 1 to 100 characters." }, 400);
      const entry = { id: editing ? body.unitId : crypto.randomUUID(), name };
      if (collection === "units") {
        const stats = body?.stats;
        if (editing && stats !== void 0 && (!stats || typeof stats !== "object" || Array.isArray(stats))) {
          return reply({ message: "Enter valid unit stats." }, 400);
        }
        const updatedStats = {};
        for (const { key, label, min } of unitStatFields) {
          if (editing && !Object.hasOwn(stats ?? {}, key)) continue;
          if (!Number.isSafeInteger(stats?.[key]) || stats[key] < min) {
            return reply({ message: `Enter a whole-number ${label} stat of at least ${min}.` }, 400);
          }
          updatedStats[key] = stats[key];
        }
        if (Object.keys(updatedStats).length) entry.stats = updatedStats;
      } else if (collection === "items") {
        const description = body.description === void 0 ? "" : typeof body.description === "string" ? body.description.trim() : null;
        const action = equipmentAction(body.action);
        if (description === null || description.length > factionEquipmentLimits.description || action === null) {
          return reply({ message: "Enter ability and action text up to 4,000 characters each." }, 400);
        }
        Object.assign(entry, equipmentRules({ description, action }));
      }
      try {
        const roster = readRoster(target);
        if (editing) {
          const unit = roster.units.find((unit2) => unit2.id === entry.id);
          if (!unit) return reply({ message: "Unit not found on this team." }, 404);
          const updated = { ...unit, name, ...entry.stats ? { stats: { ...unit.stats, ...entry.stats } } : {} };
          writeRoster(target, { ...roster, units: roster.units.map((item) => item === unit ? updated : item) });
          return reply({ entry: updated, message: "Unit saved." });
        }
        const entries = [...roster[collection], entry];
        writeRoster(target, { ...roster, [collection]: entries });
        return reply({ entry, entries, message: "Roster updated." }, 201);
      } catch {
        return reply({ message: "Unable to save the team roster in browser storage." }, 500);
      }
    }
    if (route === "/bounties/list") {
      try {
        const saved = JSON.parse(storage?.getItem("expedition-preview-bounties") ?? "null");
        return reply(saved ?? { bounties: [], pendingRequests: [] });
      } catch {
        return reply({ message: "Unable to read the Expedition bounty data." }, 500);
      }
    }
    if (route.startsWith("/map-requests")) {
      const pending = requests.filter((request) => request.status === "pending");
      const visible = (request) => battlesEnabled || !isBattle(request);
      if (route === "/map-requests/list") return admin ? reply({ requests: pending.filter(visible) }) : forbidden();
      if (route === "/map-requests/mine") return reply({ requests: pending.filter((request) => visible(request) && own(request)) });
      if (route === "/map-requests/history") return reply({
        requests: requests.filter((request) => request.status !== "pending" && visible(request) && (!isBattle(request) || canSeeBattle(request)))
      });
      if (method === "POST" && ["/map-requests", "/map-requests/update"].includes(route)) {
        if (!admin && role !== "traveler") return forbidden();
        if (!body.changeSet || typeof body.changeSet !== "object" || Array.isArray(body.changeSet)) return reply({ message: "A change set is required." }, 400);
        const existing = route.endsWith("/update") ? requests.find((request2) => request2.id === body.requestId && (request2.status === "pending" || request2.status === "accepted" && isBattle(request2))) : null;
        if (route.endsWith("/update") && !existing) return reply({ message: "Request not found." }, 404);
        if (existing?.status === "accepted" && !admin) return forbidden();
        if (existing && !admin && !own(existing)) return forbidden();
        if (!admin && (!team || body.changeSet.requesterTeam !== team)) return reply({ message: "Choose your assigned Expedition team." }, 403);
        if (!visible(existing) || !visible(body)) return battlesUnavailable();
        if (existing && isBattle(existing) !== (body.changeSet.requestType === "battle")) {
          return reply({ message: "A battle report cannot be converted into a map request or vice versa." }, 400);
        }
        if (isBattle(existing) && isStaleReview(existing)) return staleReview();
        const changeSet = structuredClone(body.changeSet);
        if (isBattle(body)) {
          const submissionRound = existing ? battleSubmissionRound(existing.changeSet) : readRound();
          if (submissionRound == null) delete changeSet.submissionRound;
          else changeSet.submissionRound = submissionRound;
        }
        if (existing?.status === "accepted") {
          const error = validateBattle(changeSet, teams, map.tiles, { recordedLocation: existing.changeSet.battleLocation });
          if (error) return reply({ message: error }, 400);
          const updated = {
            ...existing,
            changeSet,
            revision: (existing.revision ?? 1) + 1,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          if (!commitCampaignState(requests.map((item) => item === existing ? updated : item))) return saveError();
          return reply({ request: battleReport(updated), message: "Battle report updated." });
        }
        let equipmentUsed;
        let rewardOverrides;
        if (body.changeSet.requestType === "battle") {
          const error = validateBattle(body.changeSet, teams, map.tiles);
          if (error) return reply({ message: error }, 400);
          rewardOverrides = body.rewardOverrides === void 0 ? existing?.rewardOverrides ?? {} : body.rewardOverrides;
          if (!validRewardOverrides(body.changeSet, teams, rewardOverrides)) {
            return reply({ message: "Enter valid reward amounts for participating Expedition teams. Supply Points must be between 0 and 10." }, 400);
          }
          const reporter = existing?.equipmentUsed?.find((use) => use.source === "reporter");
          if (!existing || own(existing)) {
            const previousChoices = reporter?.team === body.changeSet.requesterTeam ? reporter.items : [];
            const result = readBattleEquipment(body.equipment ?? previousChoices, body.changeSet.requesterTeam, existing?.id);
            if (result.message) return reply({ message: result.message }, result.status);
            equipmentUsed = [{ source: "reporter", team: body.changeSet.requesterTeam, player: user.username, items: result.items }];
          } else {
            equipmentUsed = reporter?.team === body.changeSet.requesterTeam ? [reporter] : [];
          }
        }
        const request = {
          ...existing || { id: crypto.randomUUID(), requesterUserId: user.id, requesterUsername: user.username, requesterEmail: "", createdAt: (/* @__PURE__ */ new Date()).toISOString() },
          changeSet,
          status: "pending",
          updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
          ...body.changeSet.requestType === "battle" ? {
            equipmentUsed,
            rewardOverrides,
            confirmedTeams: [],
            revision: existing ? (existing.revision ?? 1) + 1 : 1
          } : {}
        };
        if (isBattle(request)) {
          const review = battleReview(request);
          if (!review.requiresAdminApproval && review.requiredTeams.length === 0) return acceptBattle(request, "participants");
        }
        const next = existing ? requests.map((item) => item === existing ? request : item) : [...requests, request];
        if (isBattle(request) && !commitCampaignState(next)) return saveError();
        requests = next;
        return reply({ request: isBattle(request) ? battleReport(request) : request, message: "Expedition request saved locally." });
      }
      if (method === "POST" && route === "/map-requests/history/delete") {
        if (!admin) return forbidden();
        const request = requests.find((item) => item.id === body.requestId && isBattle(item) && item.status === "accepted");
        if (!request) return reply({ message: "Approved battle report not found." }, 404);
        if (!commitCampaignState(requests.filter((item) => item !== request))) return saveError();
        return reply({ message: "Battle history entry deleted." });
      }
      if (method === "POST" && route === "/map-requests/confirm") {
        const request = pending.find((item) => item.id === body?.requestId && isBattle(item));
        if (!request || !canSeeBattle(request)) return reply({ message: "Battle report not found." }, 404);
        if (!visible(request)) return battlesUnavailable();
        const review = battleReview(request);
        if (!canLog || own(request) || !review.requiredTeams.includes(team)) return forbidden();
        if (isStaleReview(request)) return staleReview();
        if (review.confirmedTeams.includes(team)) return reply({ request: battleReport(request), message: "Your team already confirmed this report." });
        const result = readBattleEquipment(body.equipment ?? [], team);
        if (result.message) return reply({ message: result.message }, result.status);
        const updated = {
          ...request,
          confirmedTeams: [...review.confirmedTeams, team],
          updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
          equipmentUsed: [...request.equipmentUsed ?? [], { source: "participant", team, player: user.username, items: result.items }]
        };
        if (!review.requiresAdminApproval && updated.confirmedTeams.length === review.requiredTeams.length) return acceptBattle(updated, "participants");
        if (!commitCampaignState(requests.map((item) => item === request ? updated : item))) return saveError();
        return reply({ request: battleReport(updated), message: "Your team confirmed the battle report." });
      }
      if (method === "POST" && ["/map-requests/deny", "/map-requests/cancel-own"].includes(route)) {
        const request = pending.find((request2) => request2.id === body.requestId);
        if (!request) return reply({ message: "Request not found." }, 404);
        if (route.endsWith("/deny") ? !admin : !own(request)) return forbidden();
        if (!visible(request)) return battlesUnavailable();
        if (isBattle(request) && isStaleReview(request)) return staleReview();
        const updated = { ...request, status: route.endsWith("/deny") ? "denied" : "canceled", reviewedAt: (/* @__PURE__ */ new Date()).toISOString(), reviewedByUsername: user.username };
        const next = requests.map((item) => item === request ? updated : item);
        if (isBattle(request) && !commitCampaignState(next)) return saveError();
        requests = next;
        return reply({ request: isBattle(updated) ? battleReport(updated) : updated, message: "Request closed." });
      }
      if (method === "POST" && route === "/map-requests/accept" && typeof body?.requestId === "string") {
        if (!admin) return forbidden();
        const request = pending.find((item) => item.id === body.requestId);
        if (!request) return reply({ message: "Request not found." }, 404);
        if (!visible(request)) return battlesUnavailable();
        const change = request.changeSet;
        const isResupply = change.requestType === "action" && change.actionType === "resupply";
        const isPointOnly = Array.isArray(change.changes) && change.changes.length === 0 && (change.requestType === "action" && change.actionType === "search" || change.requestType === "movement" && change.movementType === "manoeuvre");
        let awards;
        if (change.requestType === "battle") {
          if (isStaleReview(request)) return staleReview();
          return acceptBattle(request, "admin");
        }
        if (isResupply || isPointOnly) {
          const { requesterTeam, supplyPointsCost = 0, supplyPointsGain = 0, campaignPointsGain = 0 } = change;
          if (!teams.includes(requesterTeam) || [supplyPointsCost, supplyPointsGain, campaignPointsGain].some((value) => !Number.isSafeInteger(value) || value < 0) || supplyPointsGain > 10 || isResupply && (campaignPointsGain || supplyPointsCost)) {
            return reply({ message: "Invalid point amounts in this request." }, 400);
          }
          if (supplyPointsCost > (map.teamStats?.[requesterTeam]?.supplyPoints ?? 0)) {
            return reply({ message: "The requester team has insufficient Supply Points." }, 409);
          }
          awards = [
            [requesterTeam, "supplyPoints", supplyPointsGain - supplyPointsCost],
            [requesterTeam, "campaignPoints", campaignPointsGain]
          ];
        }
        if (awards) return acceptRequest(request, awards);
      }
    }
    return reply({ message: `The local simulator does not implement ${method} /expedition${route}. No changes were saved.` }, 501);
  }
  const locks = globalThis.window?.navigator?.locks;
  return (account, input, options) => storage && locks ? locks.request(battleStateKey, () => handleRequest(account, input, options)) : handleRequest(account, input, options);
}

// preview/expedition-storage.mjs
import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
var teams2 = expeditionTeams.filter(Boolean);
var root = fileURLToPath(new URL("../", import.meta.url));
var expeditionDataDirectory = path.resolve(process.env.EXPEDITION_DATA_DIRECTORY || path.join(root, "data", "expedition"));
var prefix = "expedition-preview-";
var accountKey = "pyrrhic-preview-accounts-v1";
var settingNames = { round: "round", "supply-point-costs": "supplyPointCosts", "movement-limit": "movementLimit", "point-rewards": "pointRewards" };
var teamFile = (team) => `teams/${team}.json`;
var savedPointDefaults = { supplyPoints: 0, campaignPoints: 0, credits: 0 };
var json = (value) => `${JSON.stringify(value, null, 2)}
`;
var equal = (first, second) => JSON.stringify(first) === JSON.stringify(second);
var seededAccounts;
createAccountStore({
  getItem: () => null,
  setItem: (_key, value) => {
    seededAccounts = JSON.parse(value);
  }
}).seedCampaignTestAccounts();
function mapOnly({ rows, cols, tiles }) {
  return { rows, cols, tiles };
}
function defaultsFor(seed, previewAccounts = true) {
  return {
    "map.json": mapOnly(seed),
    "battles.json": { battles: [] },
    "lore.json": { posts: [] },
    "shop.json": { items: [] },
    "bounties.json": { bounties: [], pendingRequests: [] },
    "universal-equipment.json": {},
    "settings.json": Object.fromEntries(Object.values(settingNames).filter((key) => seed[key] !== void 0).map((key) => [key, seed[key]])),
    ...previewAccounts ? { "accounts.json": { nextId: 1, accounts: [] } } : {},
    ...Object.fromEntries(teams2.map((team) => [teamFile(team), {
      units: [],
      items: [],
      purchases: [],
      points: { ...savedPointDefaults, ...seed.teamStats?.[team] }
    }]))
  };
}
function readExpeditionSeed(file = path.join(root, "Expedition", "expeditionmap.json")) {
  try {
    return JSON.parse(readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
  } catch (error) {
    if (error.code === "ENOENT") return { rows: 1, cols: 1, tiles: [] };
    throw error;
  }
}
function initializeExpeditionData(directory = expeditionDataDirectory, seed = readExpeditionSeed(), previewAccounts = true) {
  mkdirSync(path.join(directory, "teams"), { recursive: true });
  for (const [file, value] of Object.entries(defaultsFor(seed, previewAccounts))) {
    try {
      writeFileSync(path.join(directory, file), json(value), { flag: "wx" });
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
    }
  }
}
function openExpeditionStorage(directory = expeditionDataDirectory, seed = readExpeditionSeed(), { previewAccounts = true } = {}) {
  const defaults = defaultsFor(seed, previewAccounts);
  const journalFile = path.join(directory, ".pending-write.json");
  const read = (file) => JSON.parse(readFileSync(path.join(directory, file), "utf8").replace(/^\uFEFF/, ""));
  function replace(target, value) {
    const temp = `${target}.${randomUUID()}.tmp`;
    try {
      writeFileSync(temp, json(value), { flag: "wx" });
      renameSync(temp, target);
    } finally {
      rmSync(temp, { force: true });
    }
  }
  function recover() {
    if (!existsSync(journalFile)) return;
    const writes = JSON.parse(readFileSync(journalFile, "utf8"));
    for (const [file, value] of Object.entries(writes)) {
      if (!Object.hasOwn(defaults, file)) throw new Error("Invalid file in the Expedition save journal.");
      replace(path.join(directory, file), value);
    }
    rmSync(journalFile);
  }
  function commit(values) {
    recover();
    const writes = Object.fromEntries(Object.entries(values).filter(([file, value]) => !equal(read(file), value)));
    if (!Object.keys(writes).length) return;
    replace(journalFile, writes);
    recover();
  }
  initializeExpeditionData(directory, seed, previewAccounts);
  recover();
  const fileKeys = {
    ...previewAccounts ? { [accountKey]: "accounts.json" } : {},
    [`${prefix}shop`]: "shop.json",
    [`${prefix}bounties`]: "bounties.json",
    [`${prefix}universal-equipment`]: "universal-equipment.json",
    ...Object.fromEntries(teams2.map((team) => [`${prefix}roster-${team}`, teamFile(team)]))
  };
  const teamStats = () => Object.fromEntries(teams2.map((team) => [team, read(teamFile(team)).points]));
  function readShop() {
    const { purchases = [], ...catalog } = read("shop.json");
    return { ...catalog, purchases: [...purchases, ...teams2.flatMap((team) => read(teamFile(team)).purchases ?? [])] };
  }
  function writeCampaignState({ battles, teamStats: stats, shop, map }) {
    const values = { "battles.json": { battles } };
    const { purchases, ...catalog } = shop ?? {};
    if (shop !== void 0) values["shop.json"] = catalog;
    if (map) values["map.json"] = mapOnly(map);
    for (const team of teams2) {
      if (stats?.[team] || purchases) values[teamFile(team)] = {
        ...read(teamFile(team)),
        ...stats?.[team] ? { points: stats[team] } : {},
        ...purchases ? { purchases: purchases.filter((item) => item.team === team) } : {}
      };
    }
    commit(values);
  }
  return {
    recover,
    seed: () => ({ ...read("map.json"), ...read("settings.json"), teamStats: teamStats() }),
    writeCampaignState,
    readLore: () => read("lore.json").posts,
    writeLore: (posts) => commit({ "lore.json": { posts } }),
    getItem(key) {
      if (key === `${prefix}battles`) return JSON.stringify({ ...read("battles.json"), teamStats: teamStats(), shop: readShop(), map: read("map.json") });
      if (key === `${prefix}shop`) return null;
      const setting = settingNames[key.slice(prefix.length)];
      if (key.startsWith(prefix) && setting) return JSON.stringify(read("settings.json")[setting]) ?? null;
      const file = fileKeys[key];
      return file ? JSON.stringify(read(file)) : null;
    },
    setItem(key, raw) {
      const value = JSON.parse(raw);
      const setting = settingNames[key.slice(prefix.length)];
      if (key.startsWith(prefix) && setting) {
        commit({ "settings.json": { ...read("settings.json"), [setting]: value } });
        return;
      }
      const file = fileKeys[key];
      if (!file) throw new Error("Unknown Expedition save key.");
      const current = file.startsWith("teams/") ? read(file) : null;
      commit({ [file]: current ? { ...value, points: current.points, purchases: current.purchases ?? [] } : value });
    },
    importLegacy(legacy) {
      if (!legacy || !Object.keys(legacy).length || Object.keys(defaults).some((file) => {
        const saved = read(file);
        if (file === "accounts.json" && equal(saved, seededAccounts)) return false;
        if (file === "shop.json" && equal(saved, { items: [], purchases: [] })) return false;
        if (file.startsWith("teams/") && saved.purchases === void 0) return !equal(saved, { ...defaults[file], purchases: void 0 });
        return !equal(saved, defaults[file]);
      })) return false;
      const values = {};
      for (const [key, file] of Object.entries(fileKeys)) {
        if (!Object.hasOwn(legacy, key)) continue;
        if (key === accountKey) createAccountStore({ getItem: () => legacy[key] });
        const value = JSON.parse(legacy[key]);
        if (file.startsWith("teams/")) {
          if (!Array.isArray(value?.units) || !Array.isArray(value?.items)) throw new Error("Invalid legacy Expedition roster.");
          values[file] = { ...value, points: defaults[file].points, purchases: [] };
        } else if (file === "shop.json") {
          if (!Array.isArray(value)) throw new Error("Invalid legacy Expedition shop.");
          values[file] = { items: value.map((item) => ({ ...item, perUser: 1, remaining: null })) };
        } else values[file] = value;
      }
      const oldCampaign = legacy[`${prefix}battles`] ? JSON.parse(legacy[`${prefix}battles`]) : {};
      if (oldCampaign.battles) {
        if (!Array.isArray(oldCampaign.battles)) throw new Error("Invalid legacy Expedition battle reports.");
        values["battles.json"] = { battles: oldCampaign.battles };
      }
      if (oldCampaign.shop && (!Array.isArray(oldCampaign.shop.items) || !Array.isArray(oldCampaign.shop.purchases))) {
        throw new Error("Invalid legacy Expedition shop.");
      }
      const { purchases = [], ...catalog } = oldCampaign.shop ?? {};
      if (oldCampaign.shop) values["shop.json"] = catalog;
      const importedSettings = { ...defaults["settings.json"] };
      for (const [key, field] of Object.entries(settingNames)) {
        if (legacy[prefix + key] !== void 0) importedSettings[field] = JSON.parse(legacy[prefix + key]);
      }
      values["settings.json"] = importedSettings;
      for (const team of teams2) {
        const file = teamFile(team);
        if (oldCampaign.teamStats?.[team] || purchases.some((item) => item.team === team)) values[file] = {
          ...values[file] ?? defaults[file],
          points: { ...defaults[file].points, ...oldCampaign.teamStats?.[team] },
          purchases: purchases.filter((item) => item.team === team)
        };
      }
      commit(values);
      return true;
    }
  };
}

// packages/expedition-backend.mjs
var newRoutes = /* @__PURE__ */ new Set([
  "/battles",
  "/battle-equipment",
  "/battle-settings",
  "/lore",
  "/shop",
  "/shop/purchase",
  "/teams",
  "/universal-equipment",
  "/point-rewards",
  "/supply-point-costs",
  "/movement-limit"
]);
var battleActions = /* @__PURE__ */ new Set([
  "/map-requests/update",
  "/map-requests/confirm",
  "/map-requests/accept",
  "/map-requests/deny",
  "/map-requests/cancel-own",
  "/map-requests/history/delete"
]);
var battleId = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
function handlesCampaignRoute(path2, method, body) {
  const route = path2.startsWith("/expedition/") ? path2.slice("/expedition".length) : "";
  if (newRoutes.has(route) || /^\/teams\/[a-z]+\/[a-z-]+$/.test(route)) return true;
  if (method !== "POST") return false;
  if (route === "/map-requests") return body?.changeSet?.requestType === "battle";
  return battleActions.has(route) && typeof body?.requestId === "string" && battleId.test(body.requestId);
}
function createExpeditionBackend({ directory, seed }) {
  if (!directory || !seed) throw new TypeError("Provide an Expedition save directory and map seed.");
  const storage = openExpeditionStorage(directory, seed, { previewAccounts: false });
  const dispatch = createExpeditionApi(seed, null, storage, { identify: (identity) => identity });
  return async function handleCampaignRequest(input, { identity, method, body, historicalBattles } = {}) {
    storage.recover();
    return dispatch(identity, new URL(input, "http://expedition.local").href, {
      method,
      body: body === void 0 ? void 0 : JSON.stringify(body),
      historicalBattles
    });
  };
}
export {
  createExpeditionBackend,
  handlesCampaignRoute
};
