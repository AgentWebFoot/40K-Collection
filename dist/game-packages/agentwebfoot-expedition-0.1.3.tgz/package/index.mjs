// packages/expedition.jsx
import { Link as Link8 } from "react-router-dom";

// Expedition/Expedition.jsx
import React, { useEffect as useEffect3, useRef as useRef2, useState as useState3 } from "react";
import { Link as Link2, Navigate, useNavigate, useSearchParams } from "react-router-dom";

// packages/host.mjs
var API_URL = "";
var host;
function configureHost(options) {
  if (typeof options?.API_URL !== "string" || typeof options.fetchJson !== "function" || typeof options.getAuthEventName !== "function") {
    throw new TypeError("Provide the host API_URL, fetchJson, and getAuthEventName.");
  }
  API_URL = options.API_URL.replace(/\/$/, "");
  host = options;
}
function hasCampaignTools() {
  return host?.campaignTools !== false;
}
function hostFunction(name, args) {
  if (typeof host?.[name] !== "function") {
    throw new Error(`Configure the game host with ${name} before opening this page.`);
  }
  return host[name](...args);
}
function fetchJson(...args) {
  return hostFunction("fetchJson", args);
}
function getAuthEventName(...args) {
  return hostFunction("getAuthEventName", args);
}

// Expedition/point-rewards.js
(() => {
  function rewardRow(label, key, campaign = 0, supply = 0, campaignKey = `${key}Campaign`) {
    return {
      label,
      fields: [[campaignKey, "Campaign Points", campaign], [`${key}Supply`, "Supply Points", supply, 10]]
    };
  }
  const standard = {
    victor: rewardRow("Victor", "standardWin", 2),
    draw: rewardRow("Draw", "standardDraw", 0, 1),
    loser: rewardRow("Loser", "standardLoss", 0, 1)
  };
  const joint = {
    victor: rewardRow("Victor", "jointWin", 1, 0, "jointCampaign"),
    draw: rewardRow("Draw", "jointDraw"),
    loser: rewardRow("Loser", "jointLoss")
  };
  const adversary = {
    victor: rewardRow("Victor", "adversaryWin", 3),
    draw: rewardRow("Draw", "adversaryDraw", 0, 2),
    loser: rewardRow("Loser", "adversaryLoss", 0, 2)
  };
  const multiplayer = {
    victor3: rewardRow("Victor \xB7 3 players", "multiplayerWin3", 3),
    draw3: rewardRow("Draw \xB7 3 players", "multiplayerDraw3", 3),
    victor4: rewardRow("Victor \xB7 4 players", "multiplayerWin4", 4),
    draw4: rewardRow("Draw \xB7 4 players", "multiplayerDraw4", 4),
    loser: rewardRow("Loser", "multiplayerLoss", 0, 2)
  };
  const battleGroups2 = [
    ["Standard", Object.values(standard)],
    ["Joint Op", Object.values(joint)],
    ["Adversary Op", Object.values(adversary)],
    ["Multiplayer Op", Object.values(multiplayer)]
  ];
  const battleFields2 = battleGroups2.flatMap(([, rows]) => rows.flatMap((row) => row.fields));
  const mapGroups = [
    ["Resupply", [
      ["baseTarget", "Own base target balance", 10, 10],
      ["ownCampMin", "Own camp minimum", 4, 10],
      ["ownCampMax", "Own camp maximum", 6, 10],
      ["otherCampMin", "Other team\u2019s camp minimum", 1, 10],
      ["otherCampMax", "Other team\u2019s camp maximum", 3, 10],
      ["otherHexSupply", "Other hex Supply Points", 1, 10]
    ]],
    ["Reward Defaults", [
      ["searchSupply", "Search Supply Points", 0, 10],
      ["searchCampaign", "Search Campaign Points", 0],
      ["manoeuvreSupply", "Manoeuvre Supply Points", 0, 10],
      ["manoeuvreCampaign", "Manoeuvre Campaign Points", 0],
      ["bountySupply", "New bounty Supply Points", 0, 10],
      ["bountyCampaign", "New bounty Campaign Points", 0]
    ]]
  ];
  const fields = [...mapGroups.flatMap(([, entries]) => entries), ...battleFields2];
  const defaults = Object.fromEntries(fields.map(([key, , amount]) => [key, amount]));
  const campRanges = [["ownCampMin", "ownCampMax"], ["otherCampMin", "otherCampMax"]];
  const validAmount = (value, max = Number.MAX_SAFE_INTEGER) => Number.isSafeInteger(value) && value >= 0 && value <= max;
  const validRanges = (rewards) => campRanges.every(([min, max]) => rewards[min] <= rewards[max]);
  function readSettings3(settings) {
    const legacyMultiplier = settings?.multiplayerWinCampaignPerTeam;
    const scaledReward = (size) => Math.min(Number.MAX_SAFE_INTEGER, size * legacyMultiplier);
    const legacyRewards = validAmount(legacyMultiplier) ? {
      multiplayerWin3Campaign: scaledReward(3),
      multiplayerDraw3Campaign: scaledReward(3),
      multiplayerWin4Campaign: scaledReward(4),
      multiplayerDraw4Campaign: scaledReward(4)
    } : {};
    const rewards = Object.fromEntries(fields.map(([key, , fallback, max]) => [
      key,
      validAmount(settings?.[key], max) ? settings[key] : legacyRewards[key] ?? fallback
    ]));
    for (const [min, max] of campRanges) {
      if (rewards[min] > rewards[max]) {
        rewards[min] = defaults[min];
        rewards[max] = defaults[max];
      }
    }
    return rewards;
  }
  function validateSettings(rewards) {
    return rewards && Object.keys(rewards).length === fields.length && fields.every(([key, , , max]) => Object.hasOwn(rewards, key) && validAmount(rewards[key], max)) && validRanges(rewards);
  }
  function battleAwards(changeSet, settings, teams2) {
    const normalize2 = (value) => String(value || "").trim().toLowerCase();
    const type = normalize2(changeSet.battleType);
    if (type === "compound-op") return [];
    const rewards = readSettings3(settings);
    const team = (value) => {
      const normalized = normalize2(value);
      return normalized === "outside-player" || teams2.includes(normalized) ? normalized : "";
    };
    const teamList = (values) => [...new Set(
      (Array.isArray(values) ? values : String(values || "").split(",")).map(team).filter(Boolean)
    )];
    const requester = team(changeSet.requesterTeam);
    const opponent = team(changeSet.battleOpponent);
    const outcome = normalize2(changeSet.battleOutcome || changeSet.battleResult);
    const winner = team(outcome) || (outcome === "won" ? requester : outcome === "lost" ? opponent : "");
    const participants = type === "multiplayer-op" ? teamList([requester, ...teamList(changeSet.battleOpponents)]) : teamList([requester, opponent]);
    const awardsFor = (recipient, row) => {
      if (!teams2.includes(recipient) || !row) return [];
      const [campaign, supply] = row.fields.map(([key]) => rewards[key]);
      return [["campaignPoints", campaign], ["supplyPoints", supply]].filter(([, amount]) => amount > 0).map(([field, amount]) => [recipient, field, amount]);
    };
    switch (type) {
      case "standard":
      case "adversary-op": {
        const rows = type === "standard" ? standard : adversary;
        if (outcome === "draw") return participants.flatMap((participant) => awardsFor(participant, rows.draw));
        if (!winner) return [];
        return [
          ...awardsFor(winner, rows.victor),
          ...participants.filter((participant) => participant !== winner).flatMap((participant) => awardsFor(participant, rows.loser))
        ];
      }
      case "joint-op": {
        let row;
        if (outcome === "draw") row = joint.draw;
        else if (outcome === "lost" || outcome === "joint-loss") row = joint.loser;
        else if (outcome === "joint-win" || participants.includes(winner)) row = joint.victor;
        return participants.flatMap((participant) => awardsFor(participant, row));
      }
      case "multiplayer-op": {
        const legacyWinners = teamList(changeSet.battleWinners);
        const leaders = outcome === "draw" ? teamList(changeSet.battleTiedTeams ?? participants) : winner ? [winner] : legacyWinners.length ? legacyWinners : teamList(changeSet.battleWinner);
        const row = multiplayer[`${leaders.length > 1 ? "draw" : "victor"}${participants.length}`];
        return participants.flatMap((participant) => awardsFor(participant, leaders.includes(participant) ? row : multiplayer.loser));
      }
      default:
        return [];
    }
  }
  globalThis.ExpeditionPointRewards = { battleFields: battleFields2, battleGroups: battleGroups2, mapGroups, readSettings: readSettings3, validateSettings, battleAwards };
})();

// Expedition/battle-rules.mjs
var expeditionBattlesEnabled = true;
var battlesUnavailableMessage = "Battles are temporarily unavailable.";
var battleEquipmentLimit = 4;
var equipmentCount = (choices) => choices.reduce((total, { quantity }) => total + quantity, 0);
var battleTypes = {
  standard: "Standard",
  "joint-op": "Joint Op",
  "adversary-op": "Adversary Op",
  "multiplayer-op": "Multiplayer Op",
  "compound-op": "Compound Op"
};
var outsidePlayer = "outside-player";
var battleTeamList = (value) => Array.isArray(value) ? value : String(value || "").split(",").map((item2) => item2.trim()).filter(Boolean);
function battleSubmissionRound(battle) {
  const round = Number(battle?.submissionRound);
  return Number.isSafeInteger(round) && round >= 1 ? round : null;
}
function battleParticipants(battle) {
  const multiplayer = battleTeamList(battle.battleOpponents);
  const opponents = battle.battleType === "multiplayer-op" && multiplayer.length ? multiplayer : [battle.battleOpponent];
  return [...new Set([battle.requesterTeam, ...opponents].filter(Boolean))];
}
function battleResultOptions(type) {
  if (type === "compound-op") return { attacker: "Attacker won", defender: "Defender won", draw: "Draw" };
  if (type === "joint-op") return { won: "Won", lost: "Lost" };
  return { won: "Won", lost: "Lost", draw: "Draw" };
}
function validBattleScores(battle) {
  const scores = battle.battleScores;
  const participants = battleParticipants(battle);
  return scores && typeof scores === "object" && !Array.isArray(scores) && Object.keys(scores).length === participants.length && participants.every((team) => Object.hasOwn(scores, team) && Number.isSafeInteger(scores[team]) && scores[team] >= 0);
}
function battleOutcome(battle) {
  const { battleType, battleResult, battleSide, requesterTeam, battleOpponent } = battle;
  if (Object.hasOwn(battle, "battleScores")) {
    if (!validBattleScores(battle)) return { winners: [], result: "Result unavailable" };
    const best = Math.max(...Object.values(battle.battleScores));
    const leaders = battleParticipants(battle).filter((team) => battle.battleScores[team] === best);
    return leaders.length === 1 ? { winners: leaders, result: "" } : { winners: [], result: "Draw", tied: leaders };
  }
  if (battle.battleOutcome === "draw") {
    const tied = battleType === "multiplayer-op" ? battle.battleTiedTeams ?? battleParticipants(battle) : [];
    return { winners: [], result: "Draw", tied };
  }
  if (battleType === "joint-op") {
    const result = battle.battleOutcome || battleResult;
    if (result === "joint-loss" || result === "lost") return { winners: [], result: "Joint Op lost" };
    if (result === "won" || result === "joint-win" || battleParticipants(battle).includes(result)) {
      return { winners: battleParticipants(battle), result: "" };
    }
  }
  if (battle.battleOutcome) return { winners: [battle.battleOutcome], result: "" };
  if (battleType === "multiplayer-op") {
    const listedWinners = battleTeamList(battle.battleWinners);
    const winners = listedWinners.length ? listedWinners : battleTeamList(battle.battleWinner);
    if (winners.length > 1) return { winners: [], result: "Draw", tied: winners };
    return { winners, result: winners.length ? "" : "Winner unavailable" };
  }
  if (battleResult === "draw") return { winners: [], result: "Draw" };
  if (battleType === "compound-op" && ["attacker", "defender"].includes(battleResult)) {
    return { winners: [battleSide === battleResult ? requesterTeam : battleOpponent].filter(Boolean), result: battleResult === "defender" ? "Defender won" : "Attacker won" };
  }
  if (battleResult === "won") return { winners: [requesterTeam].filter(Boolean), result: "" };
  if (battleResult === "lost") return { winners: [battleOpponent].filter(Boolean), result: "" };
  return { winners: [], result: "Result unavailable" };
}
function battleLocationOptions(battle, tiles) {
  let occupants = battleParticipants(battle).filter((team) => team !== outsidePlayer);
  let defender = "";
  if (battle.battleType === "compound-op") {
    if (battle.battleSide === "attacker") {
      occupants = [battle.requesterTeam];
      defender = battle.battleOpponent;
    } else if (battle.battleSide === "defender") {
      occupants = [battle.battleOpponent];
      defender = battle.requesterTeam;
    } else {
      return [];
    }
  }
  return (tiles ?? []).filter((tile) => tile?.id && [tile.marker, tile.secondaryMarker].some((team) => team && team !== outsidePlayer && occupants.includes(team)) && (!defender || battle.battleOpponent === outsidePlayer || tile.structure === "camp" && tile.structureColor === defender));
}
function validateBattle(battle, teams2, tiles, { recordedLocation } = {}) {
  const { battleType, requesterTeam, battleOpponent, battleSide, battleResult, battleLocation } = battle;
  const explicitOutcome = Object.hasOwn(battle, "battleOutcome");
  const scored = Object.hasOwn(battle, "battleScores");
  if (!Object.hasOwn(battleTypes, battleType) || !teams2.includes(requesterTeam)) return "Select a battle type and reporting team.";
  if (battleType === "multiplayer-op") {
    const opponents = battleTeamList(battle.battleOpponents);
    if (opponents.length < 2 || opponents.length > 3 || new Set(opponents).size !== opponents.length || opponents.some((team) => team === requesterTeam || team !== outsidePlayer && !teams2.includes(team))) {
      return "Select two or three distinct opponents.";
    }
    if (!scored && !explicitOutcome) {
      const { winners, tied } = battleOutcome(battle);
      const leaders = tied ?? winners;
      if (!leaders.length || leaders.some((team) => team !== requesterTeam && !opponents.includes(team))) return "Select at least one participating winner.";
    }
    if (!scored && battle.battleOutcome === "draw" && Object.hasOwn(battle, "battleTiedTeams")) {
      const tied = battle.battleTiedTeams;
      if (!Array.isArray(tied) || tied.length < 2 || new Set(tied).size !== tied.length || tied.some((team) => team !== requesterTeam && !opponents.includes(team))) return "Select at least two participating teams that tied.";
    }
  } else {
    const joint = battleType === "joint-op";
    if (!teams2.includes(battleOpponent) && (joint || battleOpponent !== outsidePlayer) || !joint && battleOpponent === requesterTeam) return joint ? "Select a teammate." : "Select an opponent.";
    if (battleType === "compound-op" && !["attacker", "defender"].includes(battleSide)) return "Select the reporting team\u2019s role.";
    if (!scored && !explicitOutcome && !Object.hasOwn(battleResultOptions(battleType), battleResult)) return "Select the battle result.";
  }
  if (scored && battleType === "joint-op") return "Choose a Joint Op outcome.";
  if (scored && !validBattleScores(battle)) return "Enter a non-negative whole-number score for each participant.";
  const jointOutcome = battleType === "joint-op" && ["joint-win", "joint-loss"].includes(battle.battleOutcome);
  if (!scored && explicitOutcome && !jointOutcome && battle.battleOutcome !== "draw" && !battleParticipants(battle).includes(battle.battleOutcome)) {
    return "Select a participating winner or a draw.";
  }
  if (!(battleLocation && battleLocation === recordedLocation) && !battleLocationOptions(battle, tiles).some((tile) => tile.id === battleLocation)) return "Select an eligible battle tile.";
  return "";
}
var battleRewardFields = {
  campaignPoints: { label: "Campaign Points", max: Number.MAX_SAFE_INTEGER },
  supplyPoints: { label: "Supply Points", max: 10 },
  credits: { label: "Credits", max: Number.MAX_SAFE_INTEGER }
};
function validRewardOverrides(battle, teams2, overrides) {
  if (!overrides || typeof overrides !== "object" || Array.isArray(overrides)) return false;
  const participants = battleParticipants(battle);
  return Object.entries(overrides).every(([team, values]) => teams2.includes(team) && participants.includes(team) && values && typeof values === "object" && !Array.isArray(values) && Object.entries(values).length > 0 && Object.entries(values).every(([field, amount]) => Object.hasOwn(battleRewardFields, field) && Number.isSafeInteger(amount) && amount >= 0 && amount <= battleRewardFields[field].max));
}
function battlePayoutAwards(battle, settings, teams2, overrides = {}) {
  let result = battle;
  if (Object.hasOwn(battle, "battleScores")) {
    if (!validBattleScores(battle)) return [];
    const { winners, tied } = battleOutcome(battle);
    result = { ...battle, battleOutcome: winners[0] ?? "draw", battleTiedTeams: tied };
  }
  const defaults = globalThis.ExpeditionPointRewards.battleAwards(result, settings, teams2);
  const awards = new Map(defaults.map((award) => [`${award[0]}:${award[1]}`, award]));
  for (const [team, values] of Object.entries(overrides)) {
    for (const [field, amount] of Object.entries(values)) awards.set(`${team}:${field}`, [team, field, amount]);
  }
  return [...awards.values()].filter(([, , amount]) => amount > 0);
}
function projectedBattlePayouts(battle, settings, teams2, balances, overrides) {
  const rows = battleParticipants(battle).filter((team) => teams2.includes(team)).map((team) => ({ team, campaignPoints: 0, supplyPoints: 0, credits: 0 }));
  for (const [team, field, amount] of battlePayoutAwards(battle, settings, teams2, overrides)) {
    const row = rows.find((row2) => row2.team === team);
    if (!row) continue;
    row[field] = Math.min(amount, Math.max(0, battleRewardFields[field].max - (balances?.[team]?.[field] ?? 0)));
    if (row[field] < amount) (row.cappedRewards ??= {})[field] = amount;
  }
  return rows;
}

// Expedition/ExpeditionBounties.jsx
import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";

// Expedition/expedition-membership.mjs
var expeditionRoles = ["viewer", "traveler", "admin"];
var expeditionTeams = ["", "red", "blue", "green", "yellow", "purple", "white", "black"];

// Expedition/ExpeditionBounties.jsx
import { jsx, jsxs } from "react/jsx-runtime";
var { readSettings } = globalThis.ExpeditionPointRewards;
var teams = expeditionTeams.filter(Boolean);
var teamLabel = (team) => team[0].toUpperCase() + team.slice(1);
var integer = (value, min = 0, max = Infinity) => {
  const number = Number(value);
  return Number.isInteger(number) && number >= min ? Math.min(number, max) : min;
};
function getBountyProgress(bounty) {
  const progressMax = integer(bounty.progressMax, 0, 999);
  const progress = integer(bounty.myProgress?.progress, 0, 999);
  const maxClaimants = integer(bounty.maxClaimants, 1, 99);
  const claimCount = integer(bounty.claimCount);
  return {
    progress,
    progressMax,
    maxClaimants,
    claimCount,
    isOpen: Boolean(bounty.isActive) && claimCount < maxClaimants,
    isClaimed: Boolean(bounty.myProgress?.isClaimed)
  };
}
var styles = {
  page: { minHeight: "100%", padding: "clamp(16px, 4vw, 40px)", background: "#1e1e1e", color: "#fff", fontFamily: "system-ui, sans-serif" },
  layout: { display: "grid", gap: "18px", width: "100%", maxWidth: "900px", margin: "0 auto" },
  stack: { display: "grid", gap: "12px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" },
  title: { margin: 0, color: "inherit", font: "700 1.8rem system-ui, sans-serif" },
  link: { color: "#eee", textUnderlineOffset: "4px", justifySelf: "start" },
  heading: { margin: 0, color: "inherit", fontSize: "1.1rem" },
  card: { display: "grid", gap: "10px", padding: "12px", background: "#1b1b1b", border: "1px solid #555", borderRadius: "8px", overflowWrap: "anywhere" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(145px, 100%), 1fr))", gap: "10px" },
  row: { display: "flex", gap: "8px", flexWrap: "wrap" },
  label: { display: "grid", gap: "4px", minWidth: 0 },
  input: { width: "100%", minWidth: 0, padding: "7px 9px", background: "#161616", border: "1px solid #666", borderRadius: "5px", color: "#fff", font: "inherit", boxSizing: "border-box" },
  button: { padding: "7px 10px", background: "#343434", color: "#fff", border: "1px solid #666", borderRadius: "5px", font: "inherit" },
  text: { margin: 0 },
  description: { margin: 0, whiteSpace: "pre-wrap" }
};
async function bountyRequest(path, fallback, body, signal) {
  const { response, payload } = await fetchJson(`/expedition/bounties/${path}`, {
    method: "POST",
    ...body && { body: JSON.stringify(body) },
    signal
  });
  if (!response.ok) throw new Error(payload?.message || fallback);
  return payload;
}
function loadBounties(signal) {
  return bountyRequest("list", "Unable to load Expedition bounties.", void 0, signal);
}
function BountyFields({ rewards, busy, onCreate }) {
  function submit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const fields = new FormData(form);
    const bounty = Object.fromEntries(fields);
    bounty.allowedTeams = fields.getAll("allowedTeams");
    bounty.supplyPointsReward ||= 0;
    bounty.campaignPointsReward ||= 0;
    bounty.maxClaimants ||= 1;
    bounty.progressMax ||= 0;
    onCreate({ bounty }, () => form.reset());
  }
  return /* @__PURE__ */ jsxs("form", { onSubmit: submit, style: styles.card, "aria-labelledby": "expedition-bounty-create", children: [
    /* @__PURE__ */ jsx("h2", { id: "expedition-bounty-create", style: styles.heading, children: "Create Bounty" }),
    /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
      "Name",
      /* @__PURE__ */ jsx("input", { name: "name", maxLength: 120, required: true, style: styles.input })
    ] }),
    /* @__PURE__ */ jsxs("div", { style: styles.grid, children: [
      /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
        "Supply Reward",
        /* @__PURE__ */ jsx("input", { name: "supplyPointsReward", type: "number", min: "0", max: "10", defaultValue: rewards.bountySupply, style: styles.input })
      ] }),
      /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
        "Campaign Reward",
        /* @__PURE__ */ jsx("input", { name: "campaignPointsReward", type: "number", min: "0", defaultValue: rewards.bountyCampaign, style: styles.input })
      ] }),
      /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
        "Claim Slots",
        /* @__PURE__ */ jsx("input", { name: "maxClaimants", type: "number", min: "1", defaultValue: "1", style: styles.input })
      ] }),
      /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
        "Progress Max",
        /* @__PURE__ */ jsx("input", { name: "progressMax", type: "number", min: "0", defaultValue: "0", style: styles.input })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("fieldset", { children: [
      /* @__PURE__ */ jsx("legend", { children: "Eligible Teams" }),
      /* @__PURE__ */ jsx("div", { style: styles.row, children: teams.map((team) => /* @__PURE__ */ jsxs("label", { children: [
        /* @__PURE__ */ jsx("input", { type: "checkbox", name: "allowedTeams", value: team }),
        " ",
        teamLabel(team)
      ] }, team)) }),
      /* @__PURE__ */ jsx("p", { style: styles.text, children: "Leave every team unchecked to make the bounty available to all teams." })
    ] }),
    /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
      "Description",
      /* @__PURE__ */ jsx("textarea", { name: "description", maxLength: 2e3, rows: 3, style: styles.input })
    ] }),
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("button", { type: "submit", style: styles.button, disabled: busy, children: "Create Bounty" }) })
  ] });
}
function BountyCard({ bounty, canSubmit, canReview, showProgress, busy, onToggleProgress, onRequest, onDelete }) {
  const { progress, progressMax, maxClaimants, claimCount, isOpen, isClaimed } = getBountyProgress(bounty);
  const name = bounty.name || "Untitled Bounty";
  const eligibleTeams = Array.isArray(bounty.allowedTeams) ? [...new Set(bounty.allowedTeams)].filter((team) => teams.includes(team)) : [];
  const pending = bounty.myPendingRequest;
  const canAct = canSubmit && bounty.canAccess !== false && isOpen && !pending && !isClaimed;
  const needsProgress = progress < progressMax;
  const progressOpen = canAct && needsProgress && showProgress;
  function submitProgress(event) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    onRequest(bounty.id, {
      requestType: "progress",
      progressAmount: fields.get("progressAmount") || 1,
      comment: fields.get("comment") || ""
    }, onToggleProgress);
  }
  return /* @__PURE__ */ jsxs("article", { id: `bounty-${bounty.id}`, tabIndex: -1, style: styles.card, children: [
    /* @__PURE__ */ jsx("h3", { style: styles.heading, children: name }),
    bounty.description && /* @__PURE__ */ jsx("p", { style: styles.description, children: bounty.description }),
    /* @__PURE__ */ jsxs("div", { style: styles.grid, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: "Supply Reward" }),
        /* @__PURE__ */ jsx("br", {}),
        integer(bounty.supplyPointsReward, 0, 10)
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: "Campaign Reward" }),
        /* @__PURE__ */ jsx("br", {}),
        integer(bounty.campaignPointsReward)
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: "Claims" }),
        /* @__PURE__ */ jsx("br", {}),
        claimCount,
        " / ",
        maxClaimants
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: "Eligible Teams" }),
        /* @__PURE__ */ jsx("br", {}),
        eligibleTeams.map(teamLabel).join(", ") || "All Teams"
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: "Created By" }),
        /* @__PURE__ */ jsx("br", {}),
        bounty.createdByUsername || "Unknown"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      /* @__PURE__ */ jsx("strong", { children: "Your Progress" }),
      " ",
      progressMax ? `${progress} / ${progressMax}` : "No progress tracker required"
    ] }),
    bounty.myProgress?.claimedAt && /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      "Claimed on ",
      new Date(bounty.myProgress.claimedAt).toLocaleString(),
      "."
    ] }),
    !isOpen && /* @__PURE__ */ jsx("p", { style: styles.text, children: "This bounty is closed." }),
    pending && /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      "You already have a pending ",
      String(pending.request?.requestType).toLowerCase() === "claim" ? "claim" : "progress",
      " request for this bounty."
    ] }),
    progressOpen && /* @__PURE__ */ jsxs("form", { onSubmit: submitProgress, style: styles.card, children: [
      /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
        "Progress Increase",
        /* @__PURE__ */ jsx("input", { name: "progressAmount", type: "number", min: "1", defaultValue: "1", style: styles.input })
      ] }),
      /* @__PURE__ */ jsxs("label", { style: styles.label, children: [
        "Progress Comment",
        /* @__PURE__ */ jsx("textarea", { name: "comment", maxLength: 1e3, rows: 3, style: styles.input })
      ] }),
      /* @__PURE__ */ jsxs("div", { style: styles.row, children: [
        /* @__PURE__ */ jsx("button", { type: "submit", disabled: busy, style: styles.button, children: "Send Progress Request" }),
        /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, style: styles.button, onClick: onToggleProgress, children: "Cancel" })
      ] })
    ] }),
    (canAct || canReview) && /* @__PURE__ */ jsxs("div", { style: styles.row, children: [
      canAct && needsProgress && /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, style: styles.button, "aria-expanded": progressOpen, onClick: onToggleProgress, children: progressOpen ? "Hide Progress Form" : "Update Progress" }),
      canAct && !needsProgress && /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, style: styles.button, onClick: () => onRequest(bounty.id, { requestType: "claim" }), children: "Send Claim Request" }),
      canReview && /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, style: styles.button, onClick: () => onDelete(bounty.id, name), children: "Delete Bounty" })
    ] })
  ] });
}
function PendingRequest({ record, bountyName, busy, onReview }) {
  const request2 = record.request;
  const type = String(request2?.requestType).toLowerCase();
  return /* @__PURE__ */ jsxs("article", { id: `bounty-request-${record.id}`, tabIndex: -1, style: styles.card, children: [
    /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      /* @__PURE__ */ jsx("strong", { children: "Bounty" }),
      " ",
      bountyName || `Bounty #${record.bountyId}`
    ] }),
    /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      /* @__PURE__ */ jsx("strong", { children: "Traveler" }),
      " ",
      record.requesterUsername || "Unknown"
    ] }),
    /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      /* @__PURE__ */ jsx("strong", { children: "Type" }),
      " ",
      type === "claim" ? "Claim" : "Progress"
    ] }),
    type === "progress" && /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      /* @__PURE__ */ jsx("strong", { children: "Progress Increase" }),
      " ",
      integer(request2.progressAmount)
    ] }),
    /* @__PURE__ */ jsxs("p", { style: styles.text, children: [
      /* @__PURE__ */ jsx("strong", { children: "Submitted Round" }),
      " ",
      integer(request2?.submissionRound, 1)
    ] }),
    request2?.comment && /* @__PURE__ */ jsxs("p", { style: styles.description, children: [
      /* @__PURE__ */ jsx("strong", { children: "Comment" }),
      " ",
      request2.comment
    ] }),
    /* @__PURE__ */ jsxs("div", { style: styles.row, children: [
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, style: styles.button, onClick: () => onReview("accept", record.id), children: "Accept Request" }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, style: styles.button, onClick: () => onReview("deny", record.id), children: "Deny Request" })
    ] })
  ] });
}
function ExpeditionBounties() {
  const [authRevision, setAuthRevision] = useState(0);
  useEffect(() => {
    const event = getAuthEventName();
    const refresh = () => setAuthRevision((value) => value + 1);
    window.addEventListener(event, refresh);
    return () => window.removeEventListener(event, refresh);
  }, []);
  return /* @__PURE__ */ jsx(BountyPage, {}, authRevision);
}
function BountyPage() {
  const { hash } = useLocation();
  const [access, setAccess] = useState(null);
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(true);
  const [feedback, setFeedback] = useState({ message: "Loading Expedition bounties\u2026" });
  const [rewards, setRewards] = useState(null);
  const [progressFormId, setProgressFormId] = useState(null);
  const canReview = access?.role === "admin" || access?.role === "owner";
  const canSubmit = access?.role === "traveler" && teams.includes(access.team);
  const bounties = Array.isArray(data?.bounties) ? data.bounties : [];
  const pending = Array.isArray(data?.pendingRequests) ? data.pendingRequests : [];
  useEffect(() => {
    if (!data || !hash) return;
    const card = document.getElementById(hash.slice(1));
    card?.focus({ preventScroll: true });
    card?.scrollIntoView({ block: "nearest" });
  }, [data, canReview, hash]);
  useEffect(() => {
    const controller = new AbortController();
    const { signal } = controller;
    fetchJson("/expedition/access", { method: "GET", signal }).then(({ response, payload }) => {
      if (!signal.aborted && response.ok) setAccess(payload?.access);
    }).catch(() => {
    });
    loadBounties(signal).then((result) => {
      if (!signal.aborted) {
        setData(result);
        setFeedback(null);
      }
    }).catch((error) => {
      if (!signal.aborted) setFeedback({ error: true, message: error.message });
    }).finally(() => {
      if (!signal.aborted) setBusy(false);
    });
    return () => controller.abort();
  }, []);
  useEffect(() => {
    if (!canReview) return;
    const controller = new AbortController();
    const { signal } = controller;
    fetchJson("/expedition/map", { method: "GET", signal }).then(({ response, payload }) => {
      if (!signal.aborted) setRewards(readSettings(response.ok ? payload?.pointRewards : void 0));
    }).catch(() => {
      if (!signal.aborted) setRewards(readSettings());
    });
    return () => controller.abort();
  }, [canReview]);
  async function run(action) {
    if (busy) return;
    setBusy(true);
    setFeedback({ message: action ? "Saving bounty changes\u2026" : "Refreshing bounties\u2026" });
    let success;
    try {
      success = await action?.();
      try {
        setData(await loadBounties());
      } catch (error) {
        setData(null);
        throw error;
      }
      setFeedback(success ? { message: success } : null);
    } catch (error) {
      setFeedback({ error: true, message: success ? `${success} ${error.message}` : error.message });
    } finally {
      setBusy(false);
    }
  }
  function mutate(path, body, failure, success, onSaved) {
    run(async () => {
      const result = await bountyRequest(path, failure, body);
      onSaved?.();
      return result?.message || success;
    });
  }
  function submitRequest(bountyId, request2, onSaved) {
    mutate("requests", { bountyId, request: request2 }, "Unable to submit the bounty request.", "Bounty request submitted.", onSaved);
  }
  function reviewRequest(action, requestId) {
    const accepted = action === "accept";
    mutate(
      `requests/${action}`,
      { requestId },
      `Unable to ${action} the bounty request.`,
      accepted ? "Bounty request accepted." : "Bounty request denied."
    );
  }
  function deleteBounty(bountyId, name) {
    if (window.confirm(`Delete "${name}"? This will remove its pending requests and progress.`)) {
      mutate("delete", { bountyId }, "Unable to delete the bounty.", "Bounty deleted.");
    }
  }
  return /* @__PURE__ */ jsx("main", { style: styles.page, children: /* @__PURE__ */ jsxs("div", { style: styles.layout, children: [
    /* @__PURE__ */ jsx(Link, { to: "/projects/Expedition", style: styles.link, children: "\u2190 Back to Expedition" }),
    /* @__PURE__ */ jsxs("div", { style: styles.header, children: [
      /* @__PURE__ */ jsx("h1", { style: styles.title, children: "Expedition Bounties" }),
      /* @__PURE__ */ jsx("button", { type: "button", style: styles.button, disabled: busy, onClick: () => run(), children: "Refresh Bounties" })
    ] }),
    feedback && /* @__PURE__ */ jsx("p", { role: feedback.error ? "alert" : "status", style: styles.text, children: feedback.message }),
    canReview && rewards && /* @__PURE__ */ jsx(BountyFields, { rewards, busy, onCreate: (body, onSaved) => mutate("create", body, "Unable to create the bounty.", "Bounty created.", onSaved) }),
    data && /* @__PURE__ */ jsxs("section", { style: styles.stack, "aria-labelledby": "expedition-available-bounties", children: [
      /* @__PURE__ */ jsx("h2", { id: "expedition-available-bounties", style: styles.heading, children: "Available Bounties" }),
      bounties.length === 0 && /* @__PURE__ */ jsx("p", { style: styles.text, children: "No Expedition bounties have been created yet." }),
      bounties.map((bounty) => /* @__PURE__ */ jsx(
        BountyCard,
        {
          bounty,
          busy,
          canSubmit,
          canReview,
          showProgress: progressFormId === bounty.id,
          onToggleProgress: () => setProgressFormId((current) => current === bounty.id ? null : bounty.id),
          onRequest: submitRequest,
          onDelete: deleteBounty
        },
        bounty.id
      ))
    ] }),
    canReview && data && /* @__PURE__ */ jsxs("section", { style: styles.stack, "aria-labelledby": "expedition-pending-bounties", children: [
      /* @__PURE__ */ jsx("h2", { id: "expedition-pending-bounties", style: styles.heading, children: "Pending Bounty Requests" }),
      pending.length === 0 && /* @__PURE__ */ jsx("p", { style: styles.text, children: "No pending bounty requests." }),
      pending.map((record) => /* @__PURE__ */ jsx(
        PendingRequest,
        {
          record,
          busy,
          onReview: reviewRequest,
          bountyName: bounties.find((bounty) => String(bounty.id) === String(record.bountyId))?.name
        },
        record.id
      ))
    ] })
  ] }) });
}

// Expedition/ExpeditionSettings.jsx
import { useEffect as useEffect2, useRef, useState as useState2 } from "react";
import { Fragment, jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
var styles2 = {
  dialog: { width: "min(680px, calc(100% - 32px))", maxHeight: "82dvh", boxSizing: "border-box", overflow: "auto", border: "1px solid #555", borderRadius: "12px", padding: "18px", background: "#242424", color: "#fff" },
  layout: { display: "grid", gap: "16px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: "10px", flexWrap: "wrap" },
  heading: { margin: 0, color: "inherit", fontSize: "1.1rem" },
  label: { display: "grid", gap: "4px", minWidth: 0, fontSize: "0.875rem" },
  form: { display: "flex", flexWrap: "wrap", alignItems: "end", gap: "8px" },
  input: { width: "100%", minWidth: 0, padding: "7px 9px", background: "#161616", border: "1px solid #666", borderRadius: "5px", color: "#fff", font: "inherit", boxSizing: "border-box" },
  button: { padding: "7px 10px", background: "#343434", color: "#fff", border: "1px solid #666", borderRadius: "5px", font: "inherit" },
  members: { display: "grid", gap: "8px" },
  member: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(150px, 100%), 1fr))", alignItems: "center", gap: "10px", padding: "10px", background: "#1b1b1b", border: "1px solid #494949", borderRadius: "6px", overflowWrap: "anywhere" },
  status: { margin: 0, color: "#ddd" },
  error: { margin: 0, color: "#ffb5a7" }
};
var capitalize = (value) => value ? value[0].toUpperCase() + value.slice(1) : "";
function SettingsStatus({ feedback }) {
  return feedback && /* @__PURE__ */ jsx2("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles2.error : styles2.status, children: feedback.message });
}
function ExpeditionSettings({ canUseAdminMode, round, onRoundChange, onMemberChange, onClose }) {
  const dialog = useRef(null);
  const [draftRound, setDraftRound] = useState2(null);
  const [roundBusy, setRoundBusy] = useState2(false);
  const [roundFeedback, setRoundFeedback] = useState2(null);
  const [members, setMembers] = useState2(null);
  const [membersBusy, setMembersBusy] = useState2(true);
  const [memberFeedback, setMemberFeedback] = useState2(null);
  const [memberRevision, setMemberRevision] = useState2(0);
  useEffect2(() => {
    dialog.current.showModal();
  }, []);
  useEffect2(() => {
    let ignore = false;
    setMembersBusy(true);
    setMemberFeedback(null);
    async function loadMembers() {
      try {
        const { response, payload } = await fetchJson("/expedition/roles/list", { method: "POST" });
        if (!response.ok) throw new Error(payload.message || "Unable to load Expedition members.");
        if (!ignore) setMembers(Array.isArray(payload.patrons) ? payload.patrons : []);
      } catch (error) {
        if (!ignore) setMemberFeedback({ error: true, message: error.message });
      } finally {
        if (!ignore) setMembersBusy(false);
      }
    }
    loadMembers();
    return () => {
      ignore = true;
    };
  }, [canUseAdminMode, memberRevision]);
  async function saveRound(event) {
    event.preventDefault();
    if (roundBusy || round == null) return;
    setRoundBusy(true);
    setRoundFeedback(null);
    try {
      const { response, payload } = await fetchJson("/expedition/round", {
        method: "POST",
        body: JSON.stringify({ round: Number(draftRound ?? round), expectedRound: round })
      });
      if (Number.isSafeInteger(payload.round) && payload.round >= 1) {
        onRoundChange(payload.round);
        setDraftRound(null);
      }
      if (!response.ok) throw new Error(payload.message || "Unable to save the round.");
      setRoundFeedback({ message: "Round saved." });
    } catch (error) {
      setRoundFeedback({ error: true, message: error.message });
    } finally {
      setRoundBusy(false);
    }
  }
  async function saveMember(member, nextRole, nextTeam) {
    if (membersBusy) return;
    setMembersBusy(true);
    setMemberFeedback(null);
    try {
      const { response, payload } = await fetchJson("/expedition/roles/set-role", {
        method: "POST",
        body: JSON.stringify({ targetUserId: member.id, role: nextRole, team: nextTeam })
      });
      if (!response.ok) throw new Error(payload.message || "Unable to save the team assignment.");
      setMembers((current) => current.map((item2) => item2.id === payload.patron.id ? payload.patron : item2));
      setMemberFeedback({ message: payload.message || "Team assignment saved." });
      onMemberChange(payload.patron);
    } catch (error) {
      setMemberFeedback({ error: true, message: error.message });
    } finally {
      setMembersBusy(false);
    }
  }
  return /* @__PURE__ */ jsx2("dialog", { id: "expedition-menu-settings", ref: dialog, "aria-labelledby": "expedition-menu-settings-title", onClose, style: styles2.dialog, children: /* @__PURE__ */ jsxs2("div", { style: styles2.layout, children: [
    /* @__PURE__ */ jsxs2("div", { style: styles2.header, children: [
      /* @__PURE__ */ jsx2("h2", { id: "expedition-menu-settings-title", style: styles2.heading, children: "Expedition Settings" }),
      /* @__PURE__ */ jsx2("button", { type: "button", style: styles2.button, onClick: () => dialog.current.close(), "aria-label": "Close settings", children: "\xD7" })
    ] }),
    canUseAdminMode && /* @__PURE__ */ jsxs2(Fragment, { children: [
      /* @__PURE__ */ jsxs2("form", { onSubmit: saveRound, style: styles2.form, children: [
        /* @__PURE__ */ jsxs2("label", { style: { ...styles2.label, width: "125px" }, children: [
          "Round Number",
          /* @__PURE__ */ jsx2(
            "input",
            {
              type: "number",
              min: "1",
              max: Number.MAX_SAFE_INTEGER,
              step: "1",
              required: true,
              value: draftRound ?? round ?? "",
              onChange: (event) => setDraftRound(event.target.value),
              disabled: roundBusy || round == null,
              style: styles2.input
            }
          )
        ] }),
        /* @__PURE__ */ jsx2("button", { type: "submit", disabled: roundBusy || round == null, style: styles2.button, children: "Save Round" })
      ] }),
      /* @__PURE__ */ jsx2(SettingsStatus, { feedback: roundFeedback })
    ] }),
    /* @__PURE__ */ jsxs2("section", { style: styles2.layout, "aria-labelledby": "expedition-menu-team-assignments", children: [
      /* @__PURE__ */ jsxs2("div", { style: styles2.header, children: [
        /* @__PURE__ */ jsx2("h3", { id: "expedition-menu-team-assignments", style: styles2.heading, children: "Expedition Members" }),
        /* @__PURE__ */ jsx2("button", { type: "button", disabled: membersBusy, style: styles2.button, onClick: () => setMemberRevision((value) => value + 1), children: "Refresh Members" })
      ] }),
      /* @__PURE__ */ jsx2(SettingsStatus, { feedback: memberFeedback }),
      members == null && membersBusy && /* @__PURE__ */ jsx2("p", { role: "status", style: styles2.status, children: "Loading Expedition members\u2026" }),
      members?.length === 0 && /* @__PURE__ */ jsx2("p", { style: styles2.status, children: "No Expedition members found." }),
      members?.length > 0 && /* @__PURE__ */ jsx2("div", { style: styles2.members, children: members.map((member) => {
        const name = member.username || member.email || "Unnamed user";
        const membershipRole = member.canEditExpeditionRole ? member.expeditionMembershipRole || "viewer" : "owner";
        const team = member.expeditionTeam || "";
        return /* @__PURE__ */ jsxs2("div", { style: styles2.member, children: [
          /* @__PURE__ */ jsxs2("div", { children: [
            /* @__PURE__ */ jsx2("strong", { children: name }),
            /* @__PURE__ */ jsxs2("div", { style: styles2.label, children: [
              "Site role \xB7 ",
              capitalize(member.siteRole)
            ] })
          ] }),
          /* @__PURE__ */ jsxs2("label", { style: styles2.label, children: [
            "Expedition role",
            /* @__PURE__ */ jsx2(
              "select",
              {
                "aria-label": `Expedition access for ${name}`,
                value: membershipRole,
                disabled: !member.canEditExpeditionRole || membersBusy,
                style: styles2.input,
                onChange: (event) => saveMember(member, event.target.value, team),
                children: member.canEditExpeditionRole ? expeditionRoles.map((access) => /* @__PURE__ */ jsx2("option", { value: access, children: capitalize(access) }, access)) : /* @__PURE__ */ jsx2("option", { value: "owner", children: capitalize(member.expeditionRole) })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs2("label", { style: styles2.label, children: [
            "Team",
            /* @__PURE__ */ jsx2(
              "select",
              {
                "aria-label": `Team for ${name}`,
                value: team,
                disabled: membersBusy || !canUseAdminMode || !member.canEditExpeditionTeam,
                style: styles2.input,
                onChange: (event) => saveMember(member, membershipRole, event.target.value),
                children: expeditionTeams.map((color) => /* @__PURE__ */ jsx2("option", { value: color, children: capitalize(color) || "No Team" }, color))
              }
            )
          ] })
        ] }, member.id);
      }) })
    ] })
  ] }) });
}

// Expedition/expedition-log-styles.mjs
var teamMarkerColors = {
  red: "#ff6b6b",
  blue: "#5aa9ff",
  green: "#7ad67a",
  yellow: "#f3d35b",
  purple: "#c28bff",
  white: "#f5f5f5",
  black: "#111111"
};
var styles3 = {
  page: { minHeight: "100%", padding: "clamp(16px, 4vw, 40px)", background: "#1e1e1e", color: "#fff", fontFamily: "system-ui, sans-serif" },
  layout: { display: "grid", gap: "18px", width: "100%", maxWidth: "900px", margin: "0 auto" },
  row: { display: "flex", flexWrap: "wrap", alignItems: "center", gap: "12px" },
  heading: { margin: 0, color: "inherit", font: "700 1.8rem system-ui, sans-serif" },
  subheading: { margin: 0, fontSize: "1.1rem" },
  link: { color: "#eee", textUnderlineOffset: "4px" },
  card: { display: "grid", gap: "12px", minWidth: 0, padding: "16px", background: "#272727", border: "1px solid #4a4a4a", borderRadius: "8px" },
  stack: { display: "grid", gridTemplateColumns: "minmax(0, 1fr)", gap: "12px" },
  fields: { display: "grid", gap: "12px", gridTemplateColumns: "repeat(auto-fit, minmax(min(210px, 100%), 1fr))" },
  field: { width: "100%", boxSizing: "border-box", color: "#fff", background: "#1a1a1a", padding: "8px", border: "1px solid #666", borderRadius: "5px", font: "inherit" },
  button: { color: "#fff", background: "#383838", border: "1px solid #666", borderRadius: "5px", padding: "8px 12px", font: "inherit" },
  label: { display: "grid", gap: "5px", fontSize: "0.9rem" },
  labelRow: { display: "flex", alignItems: "center", gap: "6px" },
  teamMarker: { width: "12px", height: "12px", border: "1px solid #aaa", borderRadius: "50%" },
  note: { margin: 0, color: "#ddd" },
  prose: { margin: 0, color: "#ddd", whiteSpace: "pre-wrap", overflowWrap: "anywhere" },
  error: { margin: 0, color: "#ffb5a7" },
  details: { display: "grid", gap: "6px", margin: 0, overflowWrap: "anywhere" },
  log: { display: "flex", flexWrap: "wrap", alignItems: "start", gap: "18px" },
  sidebar: { flex: "1 1 300px", minWidth: 0 },
  report: { flex: "3 1 420px", minWidth: 0 },
  reportList: { maxHeight: "min(65vh, 720px)", overflowY: "auto", padding: "3px" },
  filterDialog: {
    width: "min(520px, calc(100% - 32px))",
    maxHeight: "80vh",
    boxSizing: "border-box",
    overflowY: "auto",
    padding: "16px",
    color: "#fff",
    background: "#272727",
    border: "1px solid #666",
    borderRadius: "8px"
  },
  entries: { display: "grid", gap: "8px", listStyle: "none", padding: 0, margin: 0 },
  entry: {
    display: "grid",
    gap: "6px",
    color: "#fff",
    textDecoration: "none",
    padding: "12px",
    border: "1px solid #666",
    borderRadius: "6px",
    overflowWrap: "anywhere"
  }
};
var sortButton = { ...styles3.button, display: "inline-grid", placeItems: "center", width: "36px", height: "34px", padding: 0, fontSize: "1.1rem" };
var clockFace = { display: "grid", placeItems: "center", width: "14px", height: "14px", border: "1px solid currentColor", borderRadius: "50%" };
var clockHands = { width: "4px", height: "5px", borderLeft: "1px solid currentColor", borderBottom: "1px solid currentColor", transform: "translate(2px, -2px)" };
var filterIcon = {
  width: "15px",
  height: "15px",
  backgroundColor: "currentColor",
  clipPath: "polygon(0 5%, 100% 5%, 62% 51%, 62% 85%, 38% 100%, 38% 51%)"
};
var filterBadge = {
  position: "absolute",
  top: "-5px",
  right: "-5px",
  minWidth: "1rem",
  padding: "0 2px",
  color: "#1e1e1e",
  backgroundColor: "#eee",
  borderRadius: "10px",
  fontSize: "0.7rem",
  fontWeight: 700
};

// Expedition/Expedition.jsx
import { Fragment as Fragment2, jsx as jsx3, jsxs as jsxs3 } from "react/jsx-runtime";
var styles4 = {
  page: {
    position: "relative",
    minHeight: "100dvh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "16px",
    padding: "24px",
    boxSizing: "border-box",
    background: "#1e1e1e",
    color: "#ffffff",
    fontFamily: "system-ui, sans-serif",
    textAlign: "center"
  },
  actions: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    width: "min(412px, 100%)",
    boxSizing: "border-box",
    gap: "14px",
    padding: "18px",
    border: "1px solid #444",
    borderRadius: "8px",
    background: "#2a2a2a",
    boxShadow: "0 16px 40px rgba(0, 0, 0, 0.35)"
  },
  titleBox: {
    width: "min(374px, 100%)",
    padding: "14px 18px",
    border: "1px solid #444",
    borderRadius: "8px",
    background: "#2a2a2a",
    color: "#ffffff",
    fontSize: "1.25rem",
    fontWeight: 700,
    boxSizing: "border-box",
    boxShadow: "0 16px 40px rgba(0, 0, 0, 0.35)"
  },
  button: {
    padding: "12px clamp(6px, 2vw, 18px)",
    overflowWrap: "anywhere",
    border: "1px solid #666",
    borderRadius: "6px",
    background: "#202020",
    color: "#ffffff",
    fontFamily: "system-ui, sans-serif",
    fontSize: "1rem",
    fontWeight: 700,
    textDecoration: "none",
    cursor: "pointer",
    boxSizing: "border-box"
  },
  disabledButton: {
    opacity: 0.6,
    cursor: "not-allowed"
  },
  tools: { position: "absolute", top: "8px", right: "12px", display: "flex", gap: "8px" },
  icon: { width: "42px", height: "42px", padding: 0, fontSize: "1.25rem" },
  badge: {
    position: "absolute",
    top: "-5px",
    right: "-5px",
    minWidth: "17px",
    padding: "1px 3px",
    color: "#171717",
    background: "#ffce73",
    borderRadius: "10px",
    fontSize: "0.7rem",
    boxSizing: "border-box"
  },
  round: { margin: "5px 0 0", fontSize: "0.9rem", fontWeight: 600, color: "#ccc" },
  backButton: {
    position: "absolute",
    top: "8px",
    left: "12px",
    zIndex: 1e3,
    minWidth: "104px",
    padding: "9px 14px",
    border: "1px solid #666",
    borderRadius: "6px",
    background: "#202020",
    color: "#ffffff",
    cursor: "pointer",
    fontFamily: "system-ui, sans-serif",
    fontSize: "0.92rem",
    fontWeight: 700,
    boxSizing: "border-box"
  }
};
async function requestList(path, signal, method = "GET") {
  const { response, payload } = await fetchJson(path, { method, signal, ...method === "POST" && { body: "{}" } });
  if (response.status === 403 && path.endsWith("/mine")) return { requests: [] };
  if (!response.ok) throw new Error("Unable to load requests.");
  return payload;
}
async function loadRequestAlerts(session, signal, includeBattles) {
  const admin = session.access.canUseAdminMode;
  const own = (record) => record.own === true || session.user?.id != null && String(record.requesterUserId) === String(session.user.id);
  const pending = (record) => record?.id != null && (record.status == null || record.status === "pending");
  const sources = [
    ["Map", requestList(`/expedition/map-requests/${admin ? "list" : "mine"}`, signal, "POST")],
    ["Bounties", loadBounties(signal)]
  ];
  if (includeBattles) sources.push(["Battles", requestList("/expedition/battles", signal)]);
  const results = await Promise.allSettled(sources.map(([, request2]) => request2));
  const entries = [];
  const errors = [];
  function add(area, record, mine, title, to, round, action) {
    const date = typeof record.createdAt === "string" ? record.createdAt : "";
    entries.push({
      key: `${area}-${record.id}`,
      area,
      mine,
      title,
      to,
      round,
      date,
      from: record.requesterUsername,
      action
    });
  }
  results.forEach((result, index) => {
    const [area] = sources[index];
    if (result.status === "rejected") {
      errors.push(area);
      return;
    }
    const payload = result.value;
    if (area === "Map") {
      for (const record of payload.requests ?? []) {
        const change = record?.changeSet ?? {};
        if (!pending(record) || change.requestType === "battle" || !admin && !own(record)) continue;
        const kind = change.requestType === "movement" ? change.movementType : change.actionType || change.requestType;
        const title = kind ? `${kind[0].toUpperCase()}${kind.slice(1)} request` : "Map request";
        add(
          area,
          record,
          own(record),
          title,
          `/projects/ExpeditionMap?${new URLSearchParams({ request: record.id })}`,
          change.submissionRound
        );
      }
    } else if (area === "Bounties") {
      const bounties = payload.bounties ?? [];
      const names = new Map(bounties.map((bounty) => [String(bounty.id), bounty.name]));
      const requests = /* @__PURE__ */ new Map();
      for (const record of payload.pendingRequests ?? []) {
        if (pending(record) && (admin || own(record))) requests.set(String(record.id), { record, mine: own(record), bountyId: record.bountyId });
      }
      for (const bounty of bounties) {
        const record = bounty.myPendingRequest;
        if (pending(record) && (record.requesterUserId == null || own(record))) {
          requests.set(String(record.id), { record, mine: true, bountyId: bounty.id });
        }
      }
      for (const { record, mine, bountyId } of requests.values()) {
        const kind = record.request?.requestType === "claim" ? "Claim" : "Progress";
        const anchor = admin ? `bounty-request-${record.id}` : `bounty-${bountyId}`;
        add(
          area,
          record,
          mine,
          `${names.get(String(bountyId)) || "Bounty"} \xB7 ${kind}`,
          `/projects/ExpeditionBounties#${anchor}`,
          record.request?.submissionRound
        );
      }
    } else {
      for (const record of payload.pendingBattles ?? []) {
        if (!pending(record)) continue;
        const mine = own(record);
        if (!mine && !record.review?.canConfirm && !record.review?.canApprove) continue;
        const change = record.changeSet ?? {};
        const name = typeof change.battleName === "string" && change.battleName.trim() || battleTypes[change.battleType] || "Battle report";
        const action = !mine && record.review?.canConfirm ? "Confirm battle" : void 0;
        add(
          area,
          record,
          mine,
          name,
          `/projects/ExpeditionBattles?${new URLSearchParams({ view: "review", battle: record.id })}`,
          change.submissionRound,
          action
        );
      }
    }
  });
  entries.sort((first, second) => second.date.localeCompare(first.date));
  return { entries, errors };
}
function RequestAlerts({ session, includeBattles }) {
  const dialog = useRef2(null);
  const [open, setOpen] = useState3(false);
  const [data, setData] = useState3(null);
  const [revision, setRevision] = useState3(0);
  const count = data?.entries.length ?? 0;
  const label = count ? `Expedition request alerts (${count})` : "Expedition request alerts";
  useEffect3(() => {
    if (!session) return;
    const controller = new AbortController();
    loadRequestAlerts(session, controller.signal, includeBattles).then(
      (result) => {
        if (!controller.signal.aborted) setData(result);
      },
      () => {
        if (!controller.signal.aborted) setData({ entries: [], errors: ["Expedition"] });
      }
    );
    return () => controller.abort();
  }, [session, revision, includeBattles]);
  function show() {
    setRevision((value) => value + 1);
    dialog.current.showModal();
    setOpen(true);
  }
  return /* @__PURE__ */ jsxs3(Fragment2, { children: [
    /* @__PURE__ */ jsxs3(
      "button",
      {
        type: "button",
        style: { ...styles4.button, ...styles4.icon, position: "relative" },
        onClick: show,
        "aria-label": label,
        title: label,
        "aria-haspopup": "dialog",
        "aria-controls": "expedition-request-alerts",
        "aria-expanded": open,
        children: [
          /* @__PURE__ */ jsx3("span", { "aria-hidden": "true", children: "!" }),
          count > 0 && /* @__PURE__ */ jsx3("span", { "aria-hidden": "true", style: styles4.badge, children: count })
        ]
      }
    ),
    /* @__PURE__ */ jsx3(
      "dialog",
      {
        ref: dialog,
        id: "expedition-request-alerts",
        "aria-labelledby": "expedition-alert-title",
        style: { ...styles3.filterDialog, textAlign: "left" },
        onClose: () => setOpen(false),
        children: /* @__PURE__ */ jsxs3("div", { style: styles3.stack, children: [
          /* @__PURE__ */ jsxs3("div", { style: { ...styles3.row, justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsx3("h2", { id: "expedition-alert-title", style: styles3.subheading, children: "Expedition Requests" }),
            /* @__PURE__ */ jsx3("form", { method: "dialog", children: /* @__PURE__ */ jsx3("button", { style: styles3.button, children: "Close" }) })
          ] }),
          session === null ? /* @__PURE__ */ jsx3("p", { role: "alert", style: styles3.error, children: "Unable to verify Expedition access." }) : !data ? /* @__PURE__ */ jsx3("p", { role: "status", style: styles3.note, children: "Loading requests\u2026" }) : /* @__PURE__ */ jsxs3(Fragment2, { children: [
            data.errors.length > 0 && /* @__PURE__ */ jsxs3("p", { role: "alert", style: styles3.error, children: [
              "Couldn\u2019t load requests from ",
              data.errors.join(", "),
              "."
            ] }),
            !count && !data.errors.length && /* @__PURE__ */ jsx3("p", { style: styles3.note, children: "You have no active requests or approvals waiting." }),
            [["My active requests", true], ["Needs your approval", false]].map(([title, mine]) => {
              const entries = data.entries.filter((entry) => entry.mine === mine);
              return entries.length > 0 && /* @__PURE__ */ jsxs3("section", { style: styles3.stack, children: [
                /* @__PURE__ */ jsx3("h3", { style: styles3.subheading, children: title }),
                /* @__PURE__ */ jsx3("ul", { style: styles3.entries, children: entries.map((entry) => /* @__PURE__ */ jsx3("li", { children: /* @__PURE__ */ jsxs3(Link2, { style: { ...styles3.entry, background: "#1a1a1a" }, to: entry.to, children: [
                  /* @__PURE__ */ jsx3("strong", { children: entry.title }),
                  /* @__PURE__ */ jsx3("span", { style: styles3.note, children: [
                    entry.area,
                    entry.round ? `Round ${entry.round}` : "",
                    !mine && entry.from ? `From ${entry.from}` : "",
                    mine ? "Pending review" : entry.action || "Awaiting approval"
                  ].filter(Boolean).join(" \xB7 ") }),
                  entry.date && Number.isFinite(Date.parse(entry.date)) && /* @__PURE__ */ jsx3("time", { dateTime: entry.date, style: { ...styles3.note, fontSize: "0.85rem" }, children: new Date(entry.date).toLocaleString(void 0, { dateStyle: "medium", timeStyle: "short" }) })
                ] }) }, entry.key)) })
              ] }, title);
            })
          ] })
        ] })
      }
    )
  ] });
}
function Expedition({ compendiumPath, campaignTools = true } = {}) {
  const [searchParams] = useSearchParams();
  const view = searchParams.get("view");
  if (view === "bounties") return /* @__PURE__ */ jsx3(Navigate, { to: "/projects/ExpeditionBounties", replace: true });
  if (view === "shop") return /* @__PURE__ */ jsx3(Navigate, { to: "/projects/ExpeditionShop", replace: true });
  return /* @__PURE__ */ jsx3(ExpeditionMenu, { compendiumPath, campaignTools });
}
function ExpeditionMenu({ compendiumPath, campaignTools }) {
  const navigate = useNavigate();
  const [session, setSession] = useState3();
  const [round, setRound] = useState3(null);
  const [settingsOpen, setSettingsOpen] = useState3(false);
  const [authRevision, setAuthRevision] = useState3(0);
  useEffect3(() => {
    const eventName = getAuthEventName();
    const refresh = () => {
      setSettingsOpen(false);
      setSession(void 0);
      setAuthRevision((value) => value + 1);
    };
    window.addEventListener(eventName, refresh);
    return () => window.removeEventListener(eventName, refresh);
  }, []);
  useEffect3(() => {
    let ignore = false;
    fetchJson("/expedition/access", { method: "GET" }).then(({ response, payload }) => {
      if (!ignore) setSession(response.ok ? payload : null);
    }).catch(() => {
      if (!ignore) setSession(null);
    });
    fetchJson("/expedition/round", { method: "GET" }).then(({ response, payload }) => {
      if (!ignore && response.ok && Number.isSafeInteger(payload.round)) setRound(payload.round);
    }).catch(() => {
      if (!ignore) setRound(null);
    });
    return () => {
      ignore = true;
    };
  }, [authRevision]);
  const canManage = Boolean(session?.access?.canManageRoles);
  const includeBattles = campaignTools && expeditionBattlesEnabled;
  const assignedTeam = session?.access?.team;
  const teamSearch = assignedTeam && expeditionTeams.includes(assignedTeam) ? `?${new URLSearchParams({ team: assignedTeam })}` : "";
  function handleMemberChange(member) {
    if (member.id !== session?.user?.id) return;
    const role = member.expeditionRole;
    const canUseAdminMode = ["admin", "owner"].includes(role);
    const canManageRoles = canUseAdminMode || member.siteRole === "manager";
    setSession((current) => current && {
      ...current,
      access: { ...current.access, canManageRoles, canUseAdminMode, role, team: member.expeditionTeam }
    });
    if (!canManageRoles) setSettingsOpen(false);
  }
  return /* @__PURE__ */ jsxs3("main", { style: styles4.page, children: [
    /* @__PURE__ */ jsx3("button", { type: "button", onClick: () => navigate("/projects"), style: styles4.backButton, children: "< Back" }),
    /* @__PURE__ */ jsxs3("div", { style: styles4.tools, children: [
      /* @__PURE__ */ jsx3(RequestAlerts, { session, includeBattles }, authRevision),
      canManage && /* @__PURE__ */ jsx3(
        "button",
        {
          type: "button",
          onClick: () => setSettingsOpen(true),
          style: { ...styles4.button, ...styles4.icon },
          "aria-label": "Open Expedition settings",
          "aria-haspopup": "dialog",
          "aria-expanded": settingsOpen,
          title: "Expedition settings",
          children: /* @__PURE__ */ jsx3("span", { "aria-hidden": "true", children: "\u2699" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxs3("div", { style: styles4.titleBox, children: [
      "Expedition",
      round != null && /* @__PURE__ */ jsxs3("p", { style: styles4.round, children: [
        "Round ",
        round
      ] })
    ] }),
    /* @__PURE__ */ jsxs3("div", { style: styles4.actions, children: [
      compendiumPath ? /* @__PURE__ */ jsx3(Link2, { to: compendiumPath, style: styles4.button, children: "Compendium" }) : /* @__PURE__ */ jsx3("button", { type: "button", disabled: true, style: { ...styles4.button, ...styles4.disabledButton }, children: "Compendium" }),
      /* @__PURE__ */ jsx3(Link2, { to: "/projects/ExpeditionMap", style: styles4.button, children: "Map" }),
      includeBattles ? /* @__PURE__ */ jsx3(Link2, { to: "/projects/ExpeditionBattles", style: styles4.button, children: "Battles" }) : /* @__PURE__ */ jsx3("button", { type: "button", disabled: true, title: battlesUnavailableMessage, style: { ...styles4.button, ...styles4.disabledButton }, children: "Battles" }),
      campaignTools && /* @__PURE__ */ jsx3(Link2, { to: "/projects/ExpeditionLore", style: styles4.button, children: "Lore" }),
      /* @__PURE__ */ jsx3(Link2, { to: "/projects/ExpeditionBounties", style: styles4.button, children: "Bounties" }),
      campaignTools && /* @__PURE__ */ jsxs3(Fragment2, { children: [
        /* @__PURE__ */ jsx3(Link2, { to: "/projects/ExpeditionShop", style: styles4.button, children: "Shop" }),
        /* @__PURE__ */ jsx3(Link2, { to: { pathname: "/projects/ExpeditionTeams", search: teamSearch }, style: { ...styles4.button, gridColumn: "1 / -1" }, children: "Team Management" })
      ] })
    ] }),
    canManage && settingsOpen && /* @__PURE__ */ jsx3(
      ExpeditionSettings,
      {
        canUseAdminMode: session.access.canUseAdminMode,
        round,
        onRoundChange: setRound,
        onMemberChange: handleMemberChange,
        onClose: () => setSettingsOpen(false)
      }
    )
  ] });
}

// Expedition/ExpeditionMap.jsx
import { useNavigate as useNavigate2, useSearchParams as useSearchParams2 } from "react-router-dom";
import { jsx as jsx4, jsxs as jsxs4 } from "react/jsx-runtime";
var ExpeditionMap = () => {
  const navigate = useNavigate2();
  const [params] = useSearchParams2();
  const boardParams = new URLSearchParams({ apiUrl: API_URL });
  const tile = params.get("tile");
  if (tile) boardParams.set("tile", tile);
  const request2 = params.get("request");
  if (request2) boardParams.set("request", request2);
  return /* @__PURE__ */ jsxs4(
    "div",
    {
      style: {
        position: "fixed",
        inset: 0,
        width: "100%",
        height: "100dvh",
        overflow: "hidden"
      },
      children: [
        /* @__PURE__ */ jsx4(
          "button",
          {
            onClick: () => navigate("/projects/Expedition"),
            style: {
              position: "absolute",
              top: "8px",
              left: "12px",
              zIndex: 1e3,
              minWidth: "104px",
              padding: "9px 14px",
              border: "1px solid #666",
              borderRadius: "6px",
              background: "#202020",
              color: "#ffffff",
              fontFamily: "system-ui, sans-serif",
              fontSize: "0.92rem",
              fontWeight: 700,
              boxSizing: "border-box",
              cursor: "pointer"
            },
            children: "< Back"
          }
        ),
        /* @__PURE__ */ jsx4(
          "iframe",
          {
            src: `/games/Expedition/ExpeditionMap.html?${boardParams}`,
            title: "Expedition Crusade Board",
            style: {
              width: "100%",
              height: "100%",
              border: "none",
              display: "block"
            }
          }
        )
      ]
    }
  );
};
var ExpeditionMap_default = ExpeditionMap;

// Expedition/ExpeditionTeams.jsx
import { useEffect as useEffect4, useId, useState as useState4 } from "react";
import { Link as Link3, Navigate as Navigate2, useLocation as useLocation2, useSearchParams as useSearchParams3 } from "react-router-dom";

// Expedition/unit-rules.mjs
var unitStatFields = [
  { key: "apl", label: "APL", min: 0, suffix: "" },
  { key: "move", label: "Move", min: 0, suffix: "\u2033" },
  { key: "save", label: "Save", min: 1, suffix: "+" },
  { key: "wounds", label: "Wounds", min: 1, suffix: "" }
];
var unitRuleLimits = { name: 100, text: 4e3 };
function getActionEffects(action) {
  if (Array.isArray(action?.effects)) {
    return action.effects.filter((effect) => typeof effect === "string" && effect.trim());
  }
  return typeof action?.description === "string" && action.description.trim() ? [action.description] : [];
}
var weaponTypes = { ranged: "Ranged", melee: "Melee" };
var weaponLimits = { name: 100, dmg: 40, wr: 300 };
var weaponRank = (weapon) => weapon.type === "ranged" ? 0 : weapon.type === "melee" ? 1 : 2;
function orderedUnitEntries(collection, entries = []) {
  return collection === "weapons" ? [...entries].sort((left, right) => weaponRank(left) - weaponRank(right)) : entries;
}
function unitMoveTarget(collection, entries, index, direction) {
  const target = index + direction;
  if (index < 0 || target < 0 || target >= entries.length) return -1;
  if (collection === "weapons" && weaponRank(entries[index]) !== weaponRank(entries[target])) return -1;
  return target;
}
var unitImageTypes = ["image/jpeg", "image/png", "image/webp"];
var maxUnitImageFileBytes = 20 * 1024 * 1024;
var maxSavedImageBytes = 150 * 1024;
var imageData = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/;
function validUnitImage(value) {
  if (typeof value !== "string" || value.length > Math.ceil(maxSavedImageBytes / 3) * 4 + 32) return false;
  const [, type, encoded] = imageData.exec(value) ?? [];
  if (!encoded || encoded.length % 4 !== 0) return false;
  try {
    const bytes = atob(encoded);
    if (bytes.length > maxSavedImageBytes) return false;
    if (type === "image/png") return bytes.startsWith("\x89PNG\r\n\n");
    if (type === "image/jpeg") return bytes.startsWith("\xFF\xD8\xFF");
    return bytes.startsWith("RIFF") && bytes.slice(8, 12) === "WEBP";
  } catch {
    return false;
  }
}
async function prepareUnitImage(file) {
  if (!unitImageTypes.includes(file?.type) || !file.size) throw new Error("Choose a PNG, JPEG, or WebP image.");
  if (file.size > maxUnitImageFileBytes) throw new Error("Choose an image no larger than 20 MB.");
  let bitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error("Unable to read this image. Choose another PNG, JPEG, or WebP file.");
  }
  try {
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Image processing is unavailable in this browser.");
    const longestSide = Math.max(bitmap.width, bitmap.height);
    for (const target of [1024, 768, 512, 384, 256]) {
      const scale = Math.min(1, target / longestSide);
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const image = canvas.toDataURL("image/webp", 0.8);
      if (validUnitImage(image)) return image;
    }
    throw new Error("Unable to resize the image for preview storage. Try a smaller file.");
  } finally {
    bitmap.close();
  }
}

// Expedition/faction-equipment.mjs
var factionEquipmentSlotCount = 4;
var factionEquipmentLimits = { name: 100, description: 4e3 };
function factionEquipmentSlots(entries) {
  return Array.from({ length: factionEquipmentSlotCount }, (_, index) => entries?.[index] ?? null);
}

// Expedition/universal-equipment.mjs
var universalEquipment = [
  "Ammo Cache",
  "Portable Barricade",
  "Razor Wire",
  "Comms Device",
  "Mines",
  "Light Barricade",
  "Utility Grenades",
  "Heavy Barricade",
  "Ladders",
  "Explosive Grenades",
  "Breaching Charge"
].map((name) => ({
  id: name.toLowerCase().replaceAll(" ", "-"),
  name,
  description: ""
}));

// Expedition/EquipmentRules.jsx
import { jsx as jsx5, jsxs as jsxs5 } from "react/jsx-runtime";
var textStyle = { margin: 0, color: "#ddd", whiteSpace: "pre-wrap", overflowWrap: "anywhere" };
function EquipmentRules({ equipment, showEmptyAbility = false }) {
  if (!showEmptyAbility && !equipment.description && !equipment.action) return null;
  return /* @__PURE__ */ jsxs5("div", { style: { display: "grid", gap: "8px", fontSize: "0.875rem" }, children: [
    /* @__PURE__ */ jsxs5("div", { children: [
      /* @__PURE__ */ jsx5("strong", { children: "Ability" }),
      /* @__PURE__ */ jsx5("p", { style: textStyle, children: equipment.description || "No ability entered yet." })
    ] }),
    equipment.action && /* @__PURE__ */ jsxs5("div", { children: [
      /* @__PURE__ */ jsx5("strong", { children: "Action" }),
      /* @__PURE__ */ jsx5("p", { style: textStyle, children: equipment.action })
    ] })
  ] });
}

// Expedition/ExpeditionTeams.jsx
import { Fragment as Fragment3, jsx as jsx6, jsxs as jsxs6 } from "react/jsx-runtime";
var profileHeaderBackground = "#91421f";
var styles5 = {
  page: { minHeight: "100%", padding: "clamp(16px, 4vw, 48px)", background: "radial-gradient(ellipse at top, var(--team-tint), #1e1e1e 65%)", color: "#fff", fontFamily: "system-ui, sans-serif" },
  layout: { width: "100%", maxWidth: "880px", margin: "0 auto", display: "grid", gap: "20px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "end", flexWrap: "wrap", gap: "16px" },
  headerControls: { display: "flex", alignItems: "end", gap: "8px", marginLeft: "auto", minWidth: 0, maxWidth: "100%" },
  pencil: { display: "grid", placeItems: "center", width: "40px", height: "40px", padding: 0, flexShrink: 0, fontSize: "1.3rem", cursor: "pointer" },
  title: { margin: "12px 0 0", color: "var(--team-accent)", font: "700 clamp(1.65rem, 4vw, 2.25rem) system-ui, sans-serif", overflowWrap: "anywhere" },
  teamColor: { margin: "4px 0 0", color: "#ddd", fontSize: "0.9rem" },
  teamNameForm: { display: "flex", flexWrap: "wrap", alignItems: "stretch", gap: "8px", marginTop: "10px", width: "min(420px, 100%)" },
  link: { color: "#ddd", textUnderlineOffset: "3px" },
  card: { display: "grid", alignContent: "start", gap: "14px", minWidth: 0, padding: "18px", border: "1px solid #444", borderTopColor: "var(--team-accent)", borderRadius: "8px", background: "linear-gradient(145deg, var(--team-tint), #252525 85%)" },
  heading: { margin: 0, fontSize: "1.1rem" },
  label: { display: "grid", gap: "5px", fontSize: "0.875rem" },
  form: { display: "flex", alignItems: "end", flexWrap: "wrap", gap: "10px" },
  field: { color: "#fff", background: "#191919", border: "1px solid #666", borderRadius: "6px", font: "inherit", padding: "8px 10px", width: "100%" },
  button: { color: "#fff", background: "#353535", border: "1px solid #666", borderRadius: "6px", font: "inherit", padding: "8px 12px" },
  note: { color: "#ccc", margin: 0 },
  error: { color: "#ffb5a7", margin: 0 },
  balances: { display: "flex", flexWrap: "wrap", gap: "28px", margin: 0 },
  balance: { fontSize: "1.35rem", fontWeight: 700, margin: "4px 0 0", overflowWrap: "anywhere" },
  balanceActions: { display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px" },
  teamOverview: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(310px, 100%), 1fr))", gap: "16px" },
  loreForm: { display: "grid", gap: "10px", alignItems: "start" },
  locationList: { display: "grid", gap: "8px", margin: 0 },
  locationRow: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1.25fr)", gap: "8px", fontSize: "0.875rem" },
  locationValue: { margin: 0, fontWeight: 600, overflowWrap: "anywhere" },
  mapLink: { justifySelf: "start", textDecoration: "none", background: "var(--team-accent)", color: "#171717", fontWeight: 700 },
  rosterList: { display: "grid", gap: "8px", listStyle: "none", padding: 0, margin: 0 },
  rosterEntry: { padding: "8px 10px", border: "1px solid #555", borderRadius: "6px", background: "#242424", overflowWrap: "anywhere" },
  unitCard: { minWidth: 0, border: "1px solid #444", borderRadius: "6px", overflow: "hidden" },
  unitHeader: { display: "flex", flexWrap: "wrap", alignItems: "stretch", width: "100%", padding: 0, border: 0, borderRadius: 0, background: profileHeaderBackground, color: "inherit", textAlign: "left", font: "inherit", cursor: "pointer" },
  unitName: { display: "flex", alignItems: "center", gap: "8px", flex: "1 1 100px", minWidth: 0, padding: "10px", overflowWrap: "anywhere" },
  unitDisclosure: { flexShrink: 0, color: "var(--team-accent)" },
  sectionToggle: { display: "inline-flex", alignItems: "center", gap: "8px", padding: 0, border: 0, background: "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: "pointer" },
  sectionBody: { display: "grid", gap: "14px", minWidth: 0 },
  unitProfile: { display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", flex: "1 1 176px", minWidth: 0, margin: 0 },
  statCell: { display: "grid", alignContent: "start", gap: "3px", padding: "7px 2px", borderInlineStart: "1px solid #444", textAlign: "center", overflowWrap: "anywhere" },
  statLabel: { color: "#ccc", fontSize: "0.65rem", fontWeight: 700, textTransform: "uppercase" },
  unitFields: { display: "flex", flexWrap: "wrap", alignItems: "end", gap: "8px", width: "100%" },
  unitNameField: { flex: "1 1 170px", minWidth: 0 },
  unitStatFields: { display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", flex: "1 1 280px", minWidth: 0, gap: "8px" },
  statValue: { margin: 0, color: "#fff", fontWeight: 600 },
  unitImage: { display: "block", width: "100%", height: "auto", maxHeight: "360px", objectFit: "contain", background: "#191919", borderTop: "1px solid #444" },
  weaponsTableScroll: { overflowX: "auto", borderTop: "1px solid #444" },
  weaponsTable: { width: "100%", borderCollapse: "collapse", fontSize: "0.875rem" },
  weaponCell: { padding: "7px 9px", textAlign: "left", verticalAlign: "top" },
  weaponEditor: { padding: "10px", borderTop: "1px solid #444" },
  cardEditorForm: { display: "grid", gap: "10px", marginTop: "12px" },
  weaponEntryScroll: { overflowX: "auto", padding: "2px 2px 4px" },
  weaponEntryRow: {
    display: "grid",
    gridTemplateColumns: "100px minmax(125px, 2fr) 56px 56px 62px minmax(130px, 3fr) auto",
    alignItems: "end",
    gap: "6px",
    minWidth: "680px"
  },
  weaponField: { minWidth: 0, height: "36px", padding: "6px", boxSizing: "border-box" },
  weaponSave: { height: "36px", padding: "6px 10px", whiteSpace: "nowrap" },
  rulesSection: { display: "grid", gap: "8px", borderTop: "1px solid #444", padding: "10px" },
  rulesHeading: { margin: 0, fontSize: "0.9rem" },
  ruleSectionHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: "8px" },
  ruleIcon: { display: "inline-grid", placeItems: "center", minWidth: "32px", minHeight: "30px", padding: "2px 6px", fontSize: "1rem" },
  ruleText: { margin: 0, color: "#eee", fontSize: "0.875rem", lineHeight: 1.5, whiteSpace: "pre-wrap", overflowWrap: "anywhere" },
  action: { border: "1px solid #555", borderRadius: "4px", overflow: "hidden" },
  actionHeader: { display: "flex", gap: "10px", justifyContent: "space-between", alignItems: "baseline", padding: "5px 9px", background: profileHeaderBackground, fontSize: "0.85rem" },
  actionName: { overflowWrap: "anywhere", minWidth: 0, textTransform: "uppercase" },
  actionCost: { whiteSpace: "nowrap" },
  actionBody: { display: "grid", gap: "6px", padding: "8px 9px" },
  actionLine: { display: "grid", gridTemplateColumns: "12px minmax(0, 1fr)", gap: "5px", alignItems: "baseline" },
  ruleEditor: { marginTop: "2px" },
  ruleFields: { display: "flex", alignItems: "end", flexWrap: "wrap", gap: "8px" },
  effectFields: { display: "grid", gap: "8px" },
  effectEditor: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) auto", alignItems: "end", gap: "8px" },
  apField: { width: "80px" },
  rowEdit: { padding: "4px 8px", fontSize: "0.8rem", whiteSpace: "nowrap" },
  orderControls: { display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px" }
};
var ruleTextarea = { ...styles5.field, resize: "none" };
var teamColorLabel = (color) => `${color[0].toUpperCase()}${color.slice(1)}`;
var teamName = (team) => team.displayName || `${teamColorLabel(team.name)} Team`;
var teamOptionLabel = (team) => team.displayName ? `${team.displayName} (${teamColorLabel(team.name)})` : teamName(team);
var teamThemes = {
  red: ["#ff8080", "#472628"],
  blue: ["#83baff", "#22374f"],
  green: ["#92dc98", "#233e2d"],
  yellow: ["#f3d35b", "#473c22"],
  purple: ["#cea2ff", "#38284e"],
  white: ["#f5f5f5", "#41444a"],
  black: ["#b8c0cb", "#12151a"]
};
var locationFields = [["bases", "Base Location"], ["camps", "Camp Location"], ["positions", "Team Location"]];
var balanceFields = [
  ["supplyPoints", "Supply Points", 10],
  ["campaignPoints", "Campaign Points", Number.MAX_SAFE_INTEGER],
  ["credits", "Credits", Number.MAX_SAFE_INTEGER]
];
var weaponColumns = ["Type", "Name", "ATK", "HIT", "DMG", "WR"];
function updateTeam(team, category, data, method = "POST") {
  return fetchJson(`/expedition/teams/${team}/${category}`, {
    method,
    body: JSON.stringify(data)
  });
}
function UnitImage({ team, unit, editing, onSave }) {
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  const action = unit.image ? "Replace image" : "Upload image";
  async function uploadImage(event) {
    event.preventDefault();
    if (saving) return;
    const form = event.currentTarget;
    const file = form.elements.namedItem("image").files[0];
    setSaving(true);
    setFeedback(null);
    try {
      const image = await prepareUnitImage(file);
      const { response, payload } = await updateTeam(team.name, "unit-image", { unitId: unit.id, image });
      if (!response.ok) throw new Error(payload.message || "Unable to save the unit image.");
      onSave(payload.image);
      form.reset();
      setFeedback({ message: "Unit image saved." });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6(Fragment3, { children: [
    unit.image && /* @__PURE__ */ jsx6("img", { src: unit.image, alt: `${unit.name} unit image`, loading: "lazy", style: styles5.unitImage }),
    team.canUploadUnitImages && /* @__PURE__ */ jsxs6("details", { style: styles5.weaponEditor, hidden: !editing, children: [
      /* @__PURE__ */ jsx6("summary", { style: { width: "fit-content", cursor: "pointer" }, "aria-label": `${action} for ${unit.name}`, children: action }),
      /* @__PURE__ */ jsxs6("form", { style: styles5.cardEditorForm, onSubmit: uploadImage, children: [
        /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
          "Image file",
          /* @__PURE__ */ jsx6("input", { name: "image", type: "file", accept: unitImageTypes.join(","), required: true, disabled: saving, style: styles5.field })
        ] }),
        /* @__PURE__ */ jsx6("div", { children: /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving, style: styles5.button, children: saving ? "Saving image\u2026" : "Save image" }) }),
        feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message })
      ] })
    ] })
  ] });
}
function WeaponEditor({ teamName: teamName2, unitId, entry, onSave, onCancel }) {
  const [type, setType] = useState4(entry?.type ?? "ranged");
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  async function saveWeapon(event) {
    event.preventDefault();
    if (saving) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const weapon = {
      type,
      name: data.get("name"),
      dmg: data.get("dmg"),
      wr: data.get("wr"),
      atk: form.elements.namedItem("atk").valueAsNumber,
      hit: form.elements.namedItem("hit").valueAsNumber
    };
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await updateTeam(teamName2, "weapons", {
        unitId,
        weapon,
        ...entry ? { entryId: entry.id } : {}
      }, entry ? "PATCH" : "POST");
      if (!response.ok) throw new Error(payload.message || "Unable to save the weapon.");
      onSave(payload.weapon);
      if (!entry) form.reset();
      setFeedback({ message: payload.message || "Weapon saved." });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6("form", { style: styles5.cardEditorForm, onSubmit: saveWeapon, "aria-label": entry ? `Edit ${entry.name}` : void 0, children: [
    /* @__PURE__ */ jsx6("div", { style: styles5.weaponEntryScroll, children: /* @__PURE__ */ jsxs6("div", { style: styles5.weaponEntryRow, children: [
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "Type",
        /* @__PURE__ */ jsx6("select", { name: "weaponType", value: type, onChange: (event) => setType(event.target.value), disabled: saving, style: { ...styles5.field, ...styles5.weaponField }, children: Object.entries(weaponTypes).map(([key, label]) => /* @__PURE__ */ jsx6("option", { value: key, children: label }, key)) })
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "Name",
        /* @__PURE__ */ jsx6("input", { name: "name", defaultValue: entry?.name, maxLength: weaponLimits.name, required: true, disabled: saving, style: { ...styles5.field, ...styles5.weaponField } })
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "ATK",
        /* @__PURE__ */ jsx6("input", { name: "atk", defaultValue: entry?.atk, type: "number", min: "0", max: Number.MAX_SAFE_INTEGER, step: "1", required: true, disabled: saving, style: { ...styles5.field, ...styles5.weaponField } })
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "HIT",
        /* @__PURE__ */ jsx6("input", { name: "hit", defaultValue: entry?.hit, type: "number", min: "1", max: Number.MAX_SAFE_INTEGER, step: "1", required: true, disabled: saving, style: { ...styles5.field, ...styles5.weaponField } })
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "DMG",
        /* @__PURE__ */ jsx6("input", { name: "dmg", defaultValue: entry?.dmg, placeholder: "3/4", maxLength: weaponLimits.dmg, required: true, disabled: saving, style: { ...styles5.field, ...styles5.weaponField } })
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "WR",
        /* @__PURE__ */ jsx6("input", { name: "wr", defaultValue: entry?.wr, "aria-label": "WR (optional)", placeholder: "-", maxLength: weaponLimits.wr, disabled: saving, style: { ...styles5.field, ...styles5.weaponField } })
      ] }),
      /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving, style: { ...styles5.button, ...styles5.weaponSave }, children: "Save weapon" })
    ] }) }),
    onCancel && /* @__PURE__ */ jsx6("div", { children: /* @__PURE__ */ jsx6("button", { type: "button", onClick: onCancel, disabled: saving, style: styles5.rowEdit, children: "Cancel" }) }),
    feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message })
  ] });
}
function UnitOrderControls({ collection, entries, index, ordering }) {
  const entry = entries[index];
  return /* @__PURE__ */ jsx6("span", { style: styles5.orderControls, children: [[-1, "up", "\u2191"], [1, "down", "\u2193"]].map(([direction, label, arrow]) => /* @__PURE__ */ jsx6(
    "button",
    {
      type: "button",
      "aria-label": `Move ${entry.name} ${label}`,
      title: `Move ${label}`,
      disabled: unitMoveTarget(collection, entries, index, direction) === -1,
      "aria-disabled": ordering.busy || void 0,
      onClick: () => {
        if (!ordering.busy) ordering.move(collection, entry.id, direction);
      },
      style: styles5.rowEdit,
      children: /* @__PURE__ */ jsx6("span", { "aria-hidden": "true", children: arrow })
    },
    direction
  )) });
}
function UnitWeapons({ team, unit, editing, onSave, ordering }) {
  const [editingId, setEditingId] = useState4(null);
  const weapons = orderedUnitEntries("weapons", unit.weapons);
  const entry = weapons.find((weapon) => weapon.id === editingId);
  return /* @__PURE__ */ jsxs6(Fragment3, { children: [
    weapons.length > 0 && /* @__PURE__ */ jsx6("div", { style: styles5.weaponsTableScroll, children: /* @__PURE__ */ jsxs6("table", { "aria-label": `${unit.name} weapons`, style: styles5.weaponsTable, children: [
      /* @__PURE__ */ jsx6("thead", { style: { background: "#303030" }, children: /* @__PURE__ */ jsxs6("tr", { children: [
        weaponColumns.map((label) => /* @__PURE__ */ jsx6("th", { scope: "col", style: styles5.weaponCell, children: label }, label)),
        editing && /* @__PURE__ */ jsx6("th", { scope: "col", style: styles5.weaponCell, children: "Controls" })
      ] }) }),
      /* @__PURE__ */ jsx6("tbody", { children: weapons.map((weapon, index) => /* @__PURE__ */ jsxs6("tr", { style: { background: index % 2 ? "#2d2d2d" : "#252525" }, children: [
        /* @__PURE__ */ jsx6("td", { style: styles5.weaponCell, children: weaponTypes[weapon.type] }),
        /* @__PURE__ */ jsx6("th", { scope: "row", style: { ...styles5.weaponCell, overflowWrap: "anywhere" }, children: weapon.name }),
        /* @__PURE__ */ jsx6("td", { style: styles5.weaponCell, children: weapon.atk }),
        /* @__PURE__ */ jsxs6("td", { style: styles5.weaponCell, children: [
          weapon.hit,
          "+"
        ] }),
        /* @__PURE__ */ jsx6("td", { style: styles5.weaponCell, children: weapon.dmg }),
        /* @__PURE__ */ jsx6("td", { style: { ...styles5.weaponCell, width: "42%", overflowWrap: "anywhere" }, children: weapon.wr || "-" }),
        editing && /* @__PURE__ */ jsx6("td", { style: styles5.weaponCell, children: /* @__PURE__ */ jsxs6("div", { style: styles5.orderControls, children: [
          /* @__PURE__ */ jsx6("button", { type: "button", "aria-label": `Edit weapon ${weapon.name}`, onClick: () => setEditingId(weapon.id), style: styles5.rowEdit, children: "Edit" }),
          /* @__PURE__ */ jsx6(UnitOrderControls, { collection: "weapons", entries: weapons, index, ordering })
        ] }) })
      ] }, weapon.id)) })
    ] }) }),
    entry && /* @__PURE__ */ jsx6("div", { style: styles5.weaponEditor, hidden: !editing, children: /* @__PURE__ */ jsx6(
      WeaponEditor,
      {
        teamName: team.name,
        unitId: unit.id,
        entry,
        onCancel: () => setEditingId(null),
        onSave: (weapon) => {
          onSave(weapon);
          setEditingId(null);
        }
      },
      entry.id
    ) }),
    team.canAddEntries && /* @__PURE__ */ jsxs6("details", { style: styles5.weaponEditor, hidden: !editing, children: [
      /* @__PURE__ */ jsx6("summary", { style: { width: "fit-content", cursor: "pointer" }, "aria-label": `Add weapon to ${unit.name}`, children: "Add weapon" }),
      /* @__PURE__ */ jsx6(WeaponEditor, { teamName: team.name, unitId: unit.id, onSave })
    ] })
  ] });
}
function RuleIcon({ label, symbol, ...props }) {
  return /* @__PURE__ */ jsx6("button", { type: "button", "aria-label": label, title: label, style: { ...styles5.button, ...styles5.ruleIcon }, ...props, children: /* @__PURE__ */ jsx6("span", { "aria-hidden": "true", children: symbol }) });
}
function RuleEditor({ teamName: teamName2, unitId, collection, kind, editing, entry, onSave }) {
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  const isAction = kind === "action";
  const [effects, setEffects] = useState4(() => {
    const savedEffects = getActionEffects(entry);
    return savedEffects.length ? savedEffects : [""];
  });
  async function saveRule(event) {
    event.preventDefault();
    if (saving) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const name = data.get("name");
    const rule = isAction ? { name, effects, ap: form.elements.namedItem("ap").valueAsNumber, restriction: data.get("restriction") } : { name, description: data.get("description") };
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await updateTeam(teamName2, collection, {
        unitId,
        [kind]: rule,
        ...entry ? { entryId: entry.id } : {}
      }, entry ? "PATCH" : "POST");
      if (!response.ok) throw new Error(payload.message || `Unable to save the ${kind}.`);
      onSave(payload[kind]);
      if (isAction) setEffects(entry ? getActionEffects(payload.action) : [""]);
      if (!entry) form.reset();
      setFeedback({ message: payload.message || "Saved." });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsx6("div", { style: styles5.ruleEditor, hidden: !editing, children: /* @__PURE__ */ jsxs6("form", { style: styles5.cardEditorForm, onSubmit: saveRule, children: [
    /* @__PURE__ */ jsxs6("div", { style: styles5.ruleFields, children: [
      /* @__PURE__ */ jsxs6("label", { style: { ...styles5.label, ...styles5.unitNameField }, children: [
        "Name",
        /* @__PURE__ */ jsx6("input", { name: "name", defaultValue: entry?.name, maxLength: unitRuleLimits.name, required: true, disabled: saving, style: styles5.field })
      ] }),
      isAction && /* @__PURE__ */ jsxs6("label", { style: { ...styles5.label, ...styles5.apField }, children: [
        "AP",
        /* @__PURE__ */ jsx6("input", { name: "ap", defaultValue: entry?.ap, type: "number", min: "0", max: Number.MAX_SAFE_INTEGER, step: "1", required: true, disabled: saving, style: styles5.field })
      ] })
    ] }),
    isAction ? /* @__PURE__ */ jsxs6(Fragment3, { children: [
      /* @__PURE__ */ jsxs6("div", { style: styles5.effectFields, children: [
        effects.map((effect, index) => /* @__PURE__ */ jsxs6("div", { style: styles5.effectEditor, children: [
          /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
            "Effect ",
            index + 1,
            /* @__PURE__ */ jsx6(
              "textarea",
              {
                value: effect,
                onChange: (event) => {
                  const value = event.target.value;
                  setEffects((current) => current.map((text, position) => position === index ? value : text));
                },
                rows: 3,
                maxLength: unitRuleLimits.text,
                required: true,
                disabled: saving,
                style: ruleTextarea
              }
            )
          ] }),
          effects.length > 1 && /* @__PURE__ */ jsx6(
            RuleIcon,
            {
              label: `Remove effect ${index + 1}`,
              symbol: "\u2212",
              disabled: saving,
              onClick: () => setEffects((current) => current.filter((_, position) => position !== index))
            }
          )
        ] }, index)),
        /* @__PURE__ */ jsx6("div", { children: /* @__PURE__ */ jsx6(RuleIcon, { label: "Add effect", symbol: "+", disabled: saving, onClick: () => setEffects((current) => [...current, ""]) }) })
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "Restriction (optional)",
        /* @__PURE__ */ jsx6("textarea", { name: "restriction", defaultValue: entry?.restriction, rows: 2, maxLength: unitRuleLimits.text, disabled: saving, style: ruleTextarea })
      ] })
    ] }) : /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
      "Description",
      /* @__PURE__ */ jsx6("textarea", { name: "description", defaultValue: entry?.description, rows: 3, maxLength: unitRuleLimits.text, required: true, disabled: saving, style: ruleTextarea })
    ] }),
    /* @__PURE__ */ jsx6("div", { children: /* @__PURE__ */ jsxs6("button", { type: "submit", disabled: saving, style: styles5.button, children: [
      "Save ",
      kind
    ] }) }),
    feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message })
  ] }) });
}
function UnitRules({ team, unit, editing, onSave, onRemove, ordering }) {
  const [openEditors, setOpenEditors] = useState4({});
  const [removing, setRemoving] = useState4(false);
  const [removeError, setRemoveError] = useState4("");
  const toggleEditor = (collection, entryId) => setOpenEditors((current) => ({
    ...current,
    [collection]: current[collection] === entryId ? void 0 : entryId
  }));
  const ruleEditor = (collection, kind, entry) => openEditors[collection] === (entry?.id ?? null) && /* @__PURE__ */ jsx6(
    RuleEditor,
    {
      teamName: team.name,
      unitId: unit.id,
      collection,
      kind,
      editing,
      entry,
      onSave: (rule) => onSave(collection, rule, Boolean(entry))
    },
    entry?.id ?? kind
  );
  async function removeRule(collection, entry) {
    if (removing || !window.confirm(`Remove \u201C${entry.name}\u201D from ${unit.name}?`)) return;
    setRemoving(true);
    setRemoveError("");
    try {
      const { response, payload } = await updateTeam(team.name, collection, { unitId: unit.id, entryId: entry.id }, "DELETE");
      if (!response.ok) throw new Error(payload.message || "Unable to remove this entry.");
      onRemove(collection, entry.id);
      setOpenEditors((current) => current[collection] === entry.id ? { ...current, [collection]: void 0 } : current);
    } catch (error) {
      setRemoveError(error.message);
    } finally {
      setRemoving(false);
    }
  }
  function sectionHeading(collection, title, kind) {
    return /* @__PURE__ */ jsxs6("div", { style: styles5.ruleSectionHeader, children: [
      /* @__PURE__ */ jsx6("h3", { style: styles5.rulesHeading, children: title }),
      editing && /* @__PURE__ */ jsx6(
        RuleIcon,
        {
          label: `Add ${kind}`,
          symbol: "+",
          "aria-expanded": openEditors[collection] === null,
          onClick: () => toggleEditor(collection, null)
        }
      )
    ] });
  }
  function entryControls(collection, kind, index) {
    const entries = unit[collection];
    const entry = entries[index];
    return /* @__PURE__ */ jsxs6("div", { style: styles5.orderControls, children: [
      /* @__PURE__ */ jsx6(
        RuleIcon,
        {
          label: `Edit ${kind} ${entry.name}`,
          symbol: "\u270E",
          "aria-expanded": openEditors[collection] === entry.id,
          onClick: () => toggleEditor(collection, entry.id)
        }
      ),
      /* @__PURE__ */ jsx6(
        RuleIcon,
        {
          label: `Remove ${kind} ${entry.name}`,
          symbol: "\u2212",
          disabled: removing,
          onClick: () => removeRule(collection, entry)
        }
      ),
      /* @__PURE__ */ jsx6(UnitOrderControls, { collection, entries, index, ordering })
    ] });
  }
  return /* @__PURE__ */ jsxs6(Fragment3, { children: [
    /* @__PURE__ */ jsxs6("section", { "aria-label": "Abilities", style: editing || unit.abilities?.length ? styles5.rulesSection : { display: "none" }, children: [
      sectionHeading("abilities", "Abilities", "ability"),
      ruleEditor("abilities", "ability"),
      unit.abilities?.map((ability, index) => /* @__PURE__ */ jsxs6("div", { children: [
        /* @__PURE__ */ jsxs6("p", { style: styles5.ruleText, children: [
          /* @__PURE__ */ jsxs6("strong", { children: [
            ability.name,
            ":"
          ] }),
          " ",
          ability.description
        ] }),
        editing && entryControls("abilities", "ability", index),
        ruleEditor("abilities", "ability", ability)
      ] }, ability.id))
    ] }),
    /* @__PURE__ */ jsxs6("section", { "aria-label": "Actions", style: editing || unit.actions?.length ? styles5.rulesSection : { display: "none" }, children: [
      sectionHeading("actions", "Actions", "action"),
      ruleEditor("actions", "action"),
      unit.actions?.map((action, index) => /* @__PURE__ */ jsxs6("article", { style: styles5.action, children: [
        /* @__PURE__ */ jsxs6("div", { style: styles5.actionHeader, children: [
          /* @__PURE__ */ jsx6("strong", { style: styles5.actionName, children: action.name }),
          /* @__PURE__ */ jsxs6("strong", { style: styles5.actionCost, children: [
            action.ap,
            " AP"
          ] })
        ] }),
        /* @__PURE__ */ jsxs6("div", { style: styles5.actionBody, children: [
          getActionEffects(action).map((effect, index2) => /* @__PURE__ */ jsxs6("div", { style: styles5.actionLine, children: [
            /* @__PURE__ */ jsx6("span", { "aria-hidden": "true", style: { color: "#84be95" }, children: "\u25B8" }),
            /* @__PURE__ */ jsx6("p", { style: styles5.ruleText, children: effect })
          ] }, index2)),
          action.restriction && /* @__PURE__ */ jsxs6("div", { style: styles5.actionLine, children: [
            /* @__PURE__ */ jsx6("span", { "aria-hidden": "true", style: { color: "#e48b7f" }, children: "\u25C6" }),
            /* @__PURE__ */ jsxs6("p", { style: styles5.ruleText, children: [
              /* @__PURE__ */ jsx6("strong", { children: "Restriction:" }),
              " ",
              action.restriction
            ] })
          ] }),
          editing && entryControls("actions", "action", index),
          ruleEditor("actions", "action", action)
        ] })
      ] }, action.id))
    ] }),
    editing && removeError && /* @__PURE__ */ jsx6("p", { role: "alert", style: { ...styles5.error, padding: "10px" }, children: removeError })
  ] });
}
function UnitProfileEditor({ teamName: teamName2, unit, editing, onSave }) {
  const [name, setName] = useState4(unit?.name ?? "");
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  async function saveProfile(event) {
    event.preventDefault();
    if (saving || !name.trim()) return;
    const form = event.currentTarget;
    const stats = Object.fromEntries(unitStatFields.map(({ key }) => [
      key,
      form.elements.namedItem(key).valueAsNumber
    ]).filter(([, value]) => !Number.isNaN(value)));
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await updateTeam(teamName2, "units", {
        name,
        stats,
        ...unit ? { unitId: unit.id } : {}
      }, unit ? "PATCH" : "POST");
      if (!response.ok) throw new Error(payload.message || "Unable to save the unit.");
      onSave(payload.entry);
      if (!unit) form.reset();
      setName(unit ? payload.entry.name : "");
      setFeedback({ message: unit ? "Unit saved." : `${payload.entry.name} added.` });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6("form", { onSubmit: saveProfile, style: editing ? styles5.form : { display: "none" }, hidden: !editing, children: [
    /* @__PURE__ */ jsxs6("div", { style: styles5.unitFields, children: [
      /* @__PURE__ */ jsxs6("label", { style: { ...styles5.label, ...styles5.unitNameField }, children: [
        "Unit name",
        /* @__PURE__ */ jsx6("input", { value: name, onChange: (event) => setName(event.target.value), maxLength: 100, required: true, disabled: saving, style: styles5.field })
      ] }),
      /* @__PURE__ */ jsx6("div", { style: styles5.unitStatFields, children: unitStatFields.map(({ key, label, min }) => /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        label,
        /* @__PURE__ */ jsx6(
          "input",
          {
            name: key,
            type: "number",
            min,
            max: Number.MAX_SAFE_INTEGER,
            step: "1",
            defaultValue: unit?.stats?.[key],
            "aria-label": key === "move" ? "Move (inches)" : void 0,
            required: !unit || unit.stats?.[key] != null,
            disabled: saving,
            style: styles5.field
          }
        )
      ] }, key)) })
    ] }),
    /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving || !name.trim(), style: styles5.button, children: unit ? "Save unit" : "Add unit" }),
    feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message })
  ] });
}
function UnitCard({ team, unit, editing, onUpdate, onSaveEntry }) {
  const [expanded, setExpanded] = useState4(true);
  const [reordering, setReordering] = useState4(false);
  const [orderError, setOrderError] = useState4("");
  const detailsId = useId();
  const nameId = `${detailsId}-name`;
  const statsId = `${detailsId}-stats`;
  async function moveEntry(collection, entryId, direction) {
    setReordering(true);
    setOrderError("");
    try {
      const { response, payload } = await updateTeam(team.name, "unit-order", { unitId: unit.id, collection, entryId, direction });
      if (!response.ok) throw new Error(payload.message || "Unable to save the new order.");
      const positions = new Map(payload.order.map((id, index) => [id, index]));
      const position = (entry) => positions.get(entry.id) ?? positions.size;
      onUpdate((current) => ({
        ...current,
        [collection]: [...current[collection] ?? []].sort((left, right) => position(left) - position(right))
      }));
    } catch (error) {
      setOrderError(error.message);
    } finally {
      setReordering(false);
    }
  }
  const ordering = { busy: reordering, move: moveEntry };
  return /* @__PURE__ */ jsxs6("li", { style: styles5.unitCard, children: [
    /* @__PURE__ */ jsxs6(
      "button",
      {
        type: "button",
        "aria-expanded": expanded,
        "aria-controls": detailsId,
        "aria-labelledby": nameId,
        "aria-describedby": expanded ? statsId : void 0,
        onClick: () => setExpanded((current) => !current),
        style: styles5.unitHeader,
        children: [
          /* @__PURE__ */ jsxs6("span", { style: styles5.unitName, children: [
            /* @__PURE__ */ jsx6("span", { "aria-hidden": "true", style: styles5.unitDisclosure, children: expanded ? "\u25BE" : "\u25B8" }),
            /* @__PURE__ */ jsx6("strong", { id: nameId, children: unit.name })
          ] }),
          expanded && /* @__PURE__ */ jsx6("span", { id: statsId, style: styles5.unitProfile, children: unitStatFields.map(({ key, label, suffix }) => /* @__PURE__ */ jsxs6("span", { style: styles5.statCell, children: [
            /* @__PURE__ */ jsx6("span", { style: styles5.statLabel, children: label }),
            /* @__PURE__ */ jsx6("span", { style: styles5.statValue, children: unit.stats?.[key] == null ? "\u2014" : `${unit.stats[key]}${suffix}` })
          ] }, key)) })
        ]
      }
    ),
    /* @__PURE__ */ jsxs6("div", { id: detailsId, hidden: !expanded, children: [
      /* @__PURE__ */ jsx6(UnitImage, { team, unit, editing, onSave: (image) => onUpdate((current) => ({ ...current, image })) }),
      team.canAddEntries && /* @__PURE__ */ jsxs6("details", { style: styles5.weaponEditor, hidden: !editing, children: [
        /* @__PURE__ */ jsx6("summary", { style: { width: "fit-content", cursor: "pointer" }, "aria-label": `Edit unit ${unit.name}`, children: "Edit unit profile" }),
        /* @__PURE__ */ jsx6(
          UnitProfileEditor,
          {
            teamName: team.name,
            unit,
            editing,
            onSave: (profile) => onUpdate((current) => ({ ...current, name: profile.name, stats: profile.stats }))
          }
        )
      ] }),
      /* @__PURE__ */ jsx6(UnitWeapons, { team, unit, editing, onSave: (weapon) => onSaveEntry("weapons", weapon), ordering }),
      /* @__PURE__ */ jsx6(
        UnitRules,
        {
          team,
          unit,
          editing,
          onSave: onSaveEntry,
          ordering,
          onRemove: (collection, entryId) => onUpdate((current) => ({
            ...current,
            [collection]: (current[collection] ?? []).filter((entry) => entry.id !== entryId)
          }))
        }
      ),
      editing && orderError && /* @__PURE__ */ jsx6("p", { role: "alert", style: { ...styles5.error, padding: "10px" }, children: orderError })
    ] })
  ] });
}
function TeamUnits({ team, editing, onChange }) {
  function updateUnit(unitId, update) {
    onChange((current) => ({ units: current.units.map((unit) => unit.id === unitId ? update(unit) : unit) }));
  }
  function saveUnitEntry(unitId, collection, entry, replaceOnly) {
    updateUnit(unitId, (unit) => {
      const entries = unit[collection] ?? [];
      if (entries.some((item2) => item2.id === entry.id)) {
        return { ...unit, [collection]: entries.map((item2) => item2.id === entry.id ? entry : item2) };
      }
      return replaceOnly ? unit : { ...unit, [collection]: [...entries, entry] };
    });
  }
  return /* @__PURE__ */ jsxs6("section", { id: "expedition-units", style: styles5.card, "aria-labelledby": "expedition-units-heading", children: [
    /* @__PURE__ */ jsx6("h2", { id: "expedition-units-heading", style: styles5.heading, children: "Units" }),
    team.units.length ? /* @__PURE__ */ jsx6("ul", { style: styles5.rosterList, role: "list", children: team.units.map((entry) => /* @__PURE__ */ jsx6(
      UnitCard,
      {
        team,
        unit: entry,
        editing,
        onUpdate: (update) => updateUnit(entry.id, update),
        onSaveEntry: (collection, rule, replaceOnly) => saveUnitEntry(entry.id, collection, rule, replaceOnly)
      },
      entry.id
    )) }) : /* @__PURE__ */ jsx6("p", { style: styles5.note, children: "No units added yet." }),
    team.canAddEntries && /* @__PURE__ */ jsx6(
      UnitProfileEditor,
      {
        teamName: team.name,
        editing,
        onSave: (unit) => onChange((current) => ({ units: [...current.units, unit] }))
      }
    )
  ] });
}
function CollapsibleTeamSection({ id, title, linkTo, linkLabel, children }) {
  const [expanded, setExpanded] = useState4(true);
  const headingId = `${id}-heading`;
  const bodyId = `${id}-body`;
  return /* @__PURE__ */ jsxs6("section", { id, style: styles5.card, "aria-labelledby": headingId, children: [
    /* @__PURE__ */ jsxs6("div", { style: { ...styles5.ruleSectionHeader, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsx6("h2", { id: headingId, style: styles5.heading, children: /* @__PURE__ */ jsxs6(
        "button",
        {
          type: "button",
          style: styles5.sectionToggle,
          "aria-expanded": expanded,
          "aria-controls": bodyId,
          onClick: () => setExpanded((current) => !current),
          children: [
            /* @__PURE__ */ jsx6("span", { "aria-hidden": "true", style: styles5.unitDisclosure, children: expanded ? "\u25BE" : "\u25B8" }),
            title
          ]
        }
      ) }),
      /* @__PURE__ */ jsx6(Link3, { to: linkTo, style: styles5.link, children: linkLabel })
    ] }),
    /* @__PURE__ */ jsx6("div", { id: bodyId, hidden: !expanded, style: expanded ? styles5.sectionBody : void 0, children })
  ] });
}
function FactionEquipmentSlot({ team, slot, equipment, editing, onSave }) {
  const saved = equipment ?? { name: "", description: "" };
  const [draft, setDraft] = useState4(null);
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  const { name, description, action = "" } = draft ?? saved;
  const changed = name !== saved.name || description !== saved.description || action !== (saved.action ?? "");
  async function saveEquipment(event) {
    event.preventDefault();
    if (saving || !changed) return;
    setSaving(true);
    setFeedback(null);
    const next = name.trim() || description.trim() || action.trim() ? { name, description, action } : null;
    try {
      const { response, payload } = await updateTeam(team, "faction-equipment", {
        slot,
        equipment: next,
        expectedEquipment: equipment
      });
      if (response.status === 409) {
        onSave(payload.equipment);
        setFeedback({ error: true, conflict: true, message: payload.message });
        return;
      }
      if (!response.ok) throw new Error(payload.message || "Unable to save faction equipment.");
      onSave(payload.equipment);
      setDraft(null);
      setFeedback({ message: payload.message });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6("li", { style: { ...styles5.rosterEntry, ...styles5.sectionBody }, children: [
    /* @__PURE__ */ jsxs6("h4", { style: styles5.rulesHeading, children: [
      "Slot ",
      slot
    ] }),
    editing ? /* @__PURE__ */ jsxs6("form", { onSubmit: saveEquipment, style: styles5.loreForm, children: [
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "Name",
        /* @__PURE__ */ jsx6(
          "input",
          {
            "aria-label": `Faction equipment slot ${slot} name`,
            value: name,
            maxLength: factionEquipmentLimits.name,
            onChange: (event) => setDraft({ name: event.target.value, description, action }),
            disabled: saving,
            style: styles5.field
          }
        )
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "Ability",
        /* @__PURE__ */ jsx6(
          "textarea",
          {
            "aria-label": `Faction equipment slot ${slot} ability`,
            value: description,
            rows: 3,
            maxLength: factionEquipmentLimits.description,
            onChange: (event) => setDraft({ name, description: event.target.value, action }),
            disabled: saving,
            style: { ...styles5.field, resize: "vertical" }
          }
        )
      ] }),
      /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
        "Action (optional)",
        /* @__PURE__ */ jsx6(
          "textarea",
          {
            "aria-label": `Faction equipment slot ${slot} action`,
            value: action,
            rows: 2,
            maxLength: factionEquipmentLimits.description,
            onChange: (event) => setDraft({ name, description, action: event.target.value }),
            disabled: saving,
            style: { ...styles5.field, resize: "vertical" }
          }
        )
      ] }),
      /* @__PURE__ */ jsxs6("div", { style: styles5.balanceActions, children: [
        /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving || !changed || !name.trim() && Boolean(description.trim() || action.trim()), style: styles5.button, children: "Save slot" }),
        (name || description || action) && /* @__PURE__ */ jsx6("button", { type: "button", disabled: saving, onClick: () => setDraft({ name: "", description: "", action: "" }), style: styles5.button, children: "Clear slot" })
      ] })
    ] }) : equipment ? /* @__PURE__ */ jsxs6("div", { children: [
      /* @__PURE__ */ jsx6("strong", { children: equipment.name }),
      /* @__PURE__ */ jsx6(EquipmentRules, { equipment, showEmptyAbility: true })
    ] }) : /* @__PURE__ */ jsx6("p", { style: styles5.note, children: "Empty slot" }),
    feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message }),
    editing && feedback?.conflict && /* @__PURE__ */ jsxs6("div", { children: [
      /* @__PURE__ */ jsx6("strong", { children: "Currently saved" }),
      /* @__PURE__ */ jsx6("p", { style: styles5.ruleText, children: equipment?.name || "Empty slot" }),
      equipment && /* @__PURE__ */ jsx6(EquipmentRules, { equipment })
    ] })
  ] });
}
function UniversalEquipmentEntry({ item: item2, editing, onSave }) {
  const [draft, setDraft] = useState4(null);
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  const { description = "", action = "" } = draft ?? item2;
  async function save(event) {
    event.preventDefault();
    if (saving || !draft) return;
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await fetchJson("/expedition/universal-equipment", {
        method: "PATCH",
        body: JSON.stringify({
          id: item2.id,
          description,
          action,
          expectedDescription: item2.description,
          expectedAction: item2.action ?? ""
        })
      });
      if (response.status === 409) {
        onSave(payload.equipment);
        setFeedback({ error: true, conflict: true, message: payload.message });
        return;
      }
      if (!response.ok) throw new Error(payload.message || "Unable to save universal equipment.");
      onSave(payload.equipment);
      setDraft(null);
      setFeedback({ message: payload.message });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6("details", { style: styles5.rosterEntry, children: [
    /* @__PURE__ */ jsx6("summary", { style: { cursor: "pointer" }, children: item2.name }),
    /* @__PURE__ */ jsxs6("div", { style: { ...styles5.sectionBody, paddingTop: "8px" }, children: [
      editing ? /* @__PURE__ */ jsxs6("form", { onSubmit: save, style: styles5.loreForm, children: [
        /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
          "Ability",
          /* @__PURE__ */ jsx6(
            "textarea",
            {
              "aria-label": `${item2.name} ability`,
              style: styles5.field,
              rows: 3,
              maxLength: factionEquipmentLimits.description,
              value: description,
              disabled: saving,
              onChange: (event) => setDraft({ description: event.target.value, action })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
          "Action (optional)",
          /* @__PURE__ */ jsx6(
            "textarea",
            {
              "aria-label": `${item2.name} action`,
              style: styles5.field,
              rows: 2,
              maxLength: factionEquipmentLimits.description,
              value: action,
              disabled: saving,
              onChange: (event) => setDraft({ description, action: event.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving || !draft, style: { ...styles5.button, justifySelf: "start" }, children: "Save rules" })
      ] }) : /* @__PURE__ */ jsx6(EquipmentRules, { equipment: item2, showEmptyAbility: true }),
      feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message }),
      editing && feedback?.conflict && /* @__PURE__ */ jsx6(EquipmentRules, { equipment: item2, showEmptyAbility: true })
    ] })
  ] });
}
function TeamEquipment({ team, universalEquipment: universalEquipment2, editing, onChange, onUniversalSave }) {
  const [name, setName] = useState4("");
  const [description, setDescription] = useState4("");
  const [action, setAction] = useState4("");
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  const items = team.items ?? [];
  async function addEquipment(event) {
    event.preventDefault();
    const equipmentName = name.trim();
    if (saving || !editing || !team.canAddEquipment || !equipmentName) return;
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await updateTeam(team.name, "items", { name: equipmentName, description, action });
      if (!response.ok) throw new Error(payload.message || "Unable to add equipment.");
      const item2 = payload.entry;
      onChange((current) => {
        const entries = current.items ?? [];
        return { items: entries.some((entry) => entry.id === item2.id) ? entries : [...entries, item2] };
      });
      setName("");
      setDescription("");
      setAction("");
      setFeedback({ message: `${item2.name} added.` });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6(
    CollapsibleTeamSection,
    {
      id: "expedition-equipment",
      title: "Equipment",
      linkTo: "/projects/ExpeditionShop",
      linkLabel: "Visit Storefront",
      children: [
        /* @__PURE__ */ jsxs6("section", { style: styles5.sectionBody, "aria-labelledby": "expedition-universal-equipment-heading", children: [
          /* @__PURE__ */ jsx6("h3", { id: "expedition-universal-equipment-heading", style: styles5.heading, children: "Universal Equipment" }),
          /* @__PURE__ */ jsx6("p", { style: styles5.note, children: "Available to every team \xB7 Unlimited use" }),
          /* @__PURE__ */ jsx6("div", { style: styles5.teamOverview, children: universalEquipment2.map((item2) => /* @__PURE__ */ jsx6(
            UniversalEquipmentEntry,
            {
              item: item2,
              editing: editing && team.canAddEquipment,
              onSave: onUniversalSave
            },
            item2.id
          )) })
        ] }),
        /* @__PURE__ */ jsxs6("section", { style: styles5.sectionBody, "aria-labelledby": "expedition-faction-equipment-heading", children: [
          /* @__PURE__ */ jsx6("h3", { id: "expedition-faction-equipment-heading", style: styles5.heading, children: "Faction Equipment" }),
          /* @__PURE__ */ jsx6("p", { style: styles5.note, children: "Unlimited use" }),
          /* @__PURE__ */ jsx6("ol", { style: { ...styles5.rosterList, ...styles5.teamOverview }, role: "list", children: factionEquipmentSlots(team.factionEquipment).map((equipment, index) => /* @__PURE__ */ jsx6(
            FactionEquipmentSlot,
            {
              team: team.name,
              slot: index + 1,
              equipment,
              editing,
              onSave: (updated) => onChange((current) => ({
                factionEquipment: factionEquipmentSlots(current.factionEquipment).map((entry, position) => position === index ? updated : entry)
              }))
            },
            index
          )) })
        ] }),
        /* @__PURE__ */ jsx6("h3", { style: styles5.heading, children: "Purchased Equipment" }),
        items.length ? /* @__PURE__ */ jsx6("ul", { style: styles5.rosterList, role: "list", children: items.map((item2) => /* @__PURE__ */ jsxs6("li", { style: styles5.rosterEntry, children: [
          /* @__PURE__ */ jsxs6("span", { children: [
            item2.name,
            item2.quantity > 1 ? ` \xD7 ${item2.quantity}` : ""
          ] }),
          /* @__PURE__ */ jsx6(EquipmentRules, { equipment: item2, showEmptyAbility: true })
        ] }, item2.id)) }) : /* @__PURE__ */ jsx6("p", { style: styles5.note, children: "No purchased equipment yet." }),
        editing && team.canAddEquipment && /* @__PURE__ */ jsxs6("form", { onSubmit: addEquipment, style: styles5.loreForm, children: [
          /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
            "Equipment name",
            /* @__PURE__ */ jsx6(
              "input",
              {
                value: name,
                onChange: (event) => setName(event.target.value),
                maxLength: 100,
                required: true,
                disabled: saving,
                style: styles5.field
              }
            )
          ] }),
          /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
            "Ability",
            /* @__PURE__ */ jsx6(
              "textarea",
              {
                value: description,
                onChange: (event) => setDescription(event.target.value),
                rows: 3,
                maxLength: factionEquipmentLimits.description,
                disabled: saving,
                style: styles5.field
              }
            )
          ] }),
          /* @__PURE__ */ jsxs6("label", { style: styles5.label, children: [
            "Action (optional)",
            /* @__PURE__ */ jsx6(
              "textarea",
              {
                value: action,
                onChange: (event) => setAction(event.target.value),
                rows: 2,
                maxLength: factionEquipmentLimits.description,
                disabled: saving,
                style: styles5.field
              }
            )
          ] }),
          /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving || !name.trim(), style: { ...styles5.button, justifySelf: "start" }, children: "Add equipment" })
        ] }),
        feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message })
      ]
    }
  );
}
function ActiveBounties() {
  const [bounties, setBounties] = useState4(null);
  const [error, setError] = useState4("");
  useEffect4(() => {
    const controller = new AbortController();
    const { signal } = controller;
    loadBounties(signal).then(({ bounties: bounties2 }) => {
      if (!signal.aborted) setBounties(Array.isArray(bounties2) ? bounties2 : []);
    }).catch((error2) => {
      if (!signal.aborted) setError(error2.message);
    });
    return () => controller.abort();
  }, []);
  const active = bounties?.flatMap((bounty) => {
    const { progress, progressMax, isOpen, isClaimed } = getBountyProgress(bounty);
    if (!isOpen || isClaimed || bounty.canAccess === false || !progress || !progressMax) return [];
    return [{ id: bounty.id, name: bounty.name || "Untitled Bounty", progress, progressMax }];
  });
  return /* @__PURE__ */ jsxs6(
    CollapsibleTeamSection,
    {
      id: "expedition-active-bounties",
      title: "Active Bounties",
      linkTo: "/projects/ExpeditionBounties",
      linkLabel: "Visit Bounty Board",
      children: [
        error && /* @__PURE__ */ jsx6("p", { role: "alert", style: styles5.error, children: error }),
        !error && !active && /* @__PURE__ */ jsx6("p", { role: "status", style: styles5.note, children: "Loading bounty progress\u2026" }),
        active?.length === 0 && /* @__PURE__ */ jsx6("p", { style: styles5.note, children: "You have no active bounties with recorded progress." }),
        active?.length > 0 && /* @__PURE__ */ jsx6("ul", { style: styles5.rosterList, role: "list", children: active.map(({ id, name, progress, progressMax }) => /* @__PURE__ */ jsxs6("li", { style: styles5.rosterEntry, children: [
          /* @__PURE__ */ jsxs6("div", { style: styles5.ruleSectionHeader, children: [
            /* @__PURE__ */ jsx6("strong", { children: name }),
            /* @__PURE__ */ jsxs6("span", { children: [
              progress,
              " / ",
              progressMax
            ] })
          ] }),
          /* @__PURE__ */ jsx6(
            "progress",
            {
              value: progress,
              max: progressMax,
              "aria-label": `Your progress on ${name}`,
              style: { width: "100%", height: "8px", accentColor: "var(--team-accent)" }
            }
          )
        ] }, id)) })
      ]
    }
  );
}
function TeamPoints({ team, onChange }) {
  const [values, setValues] = useState4(team.points);
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  async function savePoints(event) {
    event.preventDefault();
    if (saving) return;
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await updateTeam(team.name, "points", {
        points: Object.fromEntries(balanceFields.map(([key]) => [key, Number(values[key] ?? 0)])),
        expectedPoints: team.points
      });
      if (payload.points) {
        onChange(() => ({ points: payload.points }));
        setValues(payload.points);
      }
      if (!response.ok) throw new Error(payload.message || "Unable to save team points.");
      setFeedback({ message: "Team points saved." });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6("section", { style: styles5.card, "aria-labelledby": "expedition-team-balances", children: [
    /* @__PURE__ */ jsx6("h2", { id: "expedition-team-balances", style: styles5.heading, children: "Point Balances" }),
    team.canEditPoints ? /* @__PURE__ */ jsxs6("form", { onSubmit: savePoints, style: styles5.form, children: [
      balanceFields.map(([key, label, max]) => /* @__PURE__ */ jsxs6("label", { style: { ...styles5.label, flex: "1 1 105px", minWidth: 0 }, children: [
        label,
        /* @__PURE__ */ jsx6(
          "input",
          {
            name: key,
            type: "number",
            min: "0",
            max,
            step: "1",
            required: true,
            value: values[key] ?? 0,
            onChange: (event) => setValues({ ...values, [key]: event.target.value }),
            disabled: saving,
            style: styles5.field
          }
        )
      ] }, key)),
      /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving, style: styles5.button, children: "Save points" })
    ] }) : /* @__PURE__ */ jsx6("dl", { style: styles5.balances, children: balanceFields.map(([key, label]) => /* @__PURE__ */ jsxs6("div", { children: [
      /* @__PURE__ */ jsx6("dt", { children: label }),
      /* @__PURE__ */ jsx6("dd", { style: styles5.balance, children: team.points[key] ?? 0 })
    ] }, key)) }),
    /* @__PURE__ */ jsxs6("div", { style: styles5.balanceActions, children: [
      /* @__PURE__ */ jsx6(
        "button",
        {
          type: "button",
          disabled: true,
          title: "Battle reporting is coming later",
          style: { ...styles5.button, opacity: 0.6, cursor: "not-allowed" },
          children: "Report Battle"
        }
      ),
      /* @__PURE__ */ jsx6(Link3, { to: "/projects/ExpeditionBounties", style: { ...styles5.button, textDecoration: "none" }, children: "Check Bounties" })
    ] }),
    feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message })
  ] });
}
function TeamLocations({ locations }) {
  return /* @__PURE__ */ jsxs6("section", { style: styles5.card, "aria-labelledby": "expedition-team-locations", children: [
    /* @__PURE__ */ jsx6("h2", { id: "expedition-team-locations", style: styles5.heading, children: "Locations" }),
    /* @__PURE__ */ jsx6("dl", { style: styles5.locationList, children: locationFields.map(([key, label]) => {
      const tiles = locations?.[key] ?? [];
      return /* @__PURE__ */ jsxs6("div", { style: styles5.locationRow, children: [
        /* @__PURE__ */ jsx6("dt", { children: label }),
        /* @__PURE__ */ jsx6("dd", { style: styles5.locationValue, children: tiles.length ? tiles.map((id) => `Tile ${id}`).join(", ") : "\u2014" })
      ] }, key);
    }) }),
    /* @__PURE__ */ jsx6(Link3, { to: "/projects/ExpeditionMap", style: { ...styles5.button, ...styles5.mapLink }, children: "View Map" })
  ] });
}
function TeamTitle({ team, editing, onSave }) {
  const [name, setName] = useState4(() => teamName(team));
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  async function saveName(event) {
    event.preventDefault();
    if (saving || !name.trim()) return;
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await updateTeam(team.name, "name", { name });
      if (!response.ok) throw new Error(payload.message || "Unable to save the team name.");
      onSave(payload.displayName);
      setName(payload.displayName);
      setFeedback({ message: "Team name saved." });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6(Fragment3, { children: [
    /* @__PURE__ */ jsx6("h1", { style: styles5.title, children: teamName(team) }),
    /* @__PURE__ */ jsx6("p", { style: styles5.teamColor, children: teamColorLabel(team.name) }),
    editing && /* @__PURE__ */ jsxs6("form", { onSubmit: saveName, style: styles5.teamNameForm, children: [
      /* @__PURE__ */ jsx6(
        "input",
        {
          "aria-label": "Team name",
          value: name,
          onChange: (event) => setName(event.target.value),
          maxLength: 100,
          required: true,
          disabled: saving,
          style: { ...styles5.field, flex: "1 1 160px", minWidth: 0 }
        }
      ),
      /* @__PURE__ */ jsx6("button", { type: "submit", disabled: saving || !name.trim(), style: styles5.button, children: "Save name" }),
      feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: { ...feedback.error ? styles5.error : styles5.note, flexBasis: "100%" }, children: feedback.message })
    ] })
  ] });
}
function TeamLore({ team, editing, onSave }) {
  const lore = team.lore ?? "";
  const [draft, setDraft] = useState4(null);
  const [saving, setSaving] = useState4(false);
  const [feedback, setFeedback] = useState4(null);
  async function saveLore(event) {
    event.preventDefault();
    if (saving || draft === null || draft === lore) return;
    setSaving(true);
    setFeedback(null);
    try {
      const { response, payload } = await updateTeam(team.name, "lore", { lore: draft, expectedLore: lore });
      if (response.status === 409 && typeof payload.lore === "string") {
        onSave(payload.lore);
        setFeedback({ error: true, conflict: true, message: payload.message });
        return;
      }
      if (!response.ok) throw new Error(payload.message || "Unable to save team lore.");
      onSave(payload.lore);
      setDraft(null);
      setFeedback({ message: "Lore saved." });
    } catch (error) {
      setFeedback({ error: true, message: error.message });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs6("section", { id: "expedition-team-lore", style: styles5.card, "aria-labelledby": "expedition-team-lore-heading", children: [
    /* @__PURE__ */ jsx6("h2", { id: "expedition-team-lore-heading", style: styles5.heading, children: "Lore" }),
    editing ? /* @__PURE__ */ jsxs6("form", { onSubmit: saveLore, style: styles5.loreForm, children: [
      /* @__PURE__ */ jsx6(
        "textarea",
        {
          "aria-label": "Team lore",
          rows: 5,
          value: draft ?? lore,
          disabled: saving,
          onChange: (event) => setDraft(event.target.value),
          style: { ...styles5.field, boxSizing: "border-box", resize: "vertical" }
        }
      ),
      /* @__PURE__ */ jsx6(
        "button",
        {
          type: "submit",
          disabled: saving || draft === null || draft === lore,
          style: { ...styles5.button, justifySelf: "start" },
          children: "Save lore"
        }
      )
    ] }) : /* @__PURE__ */ jsx6("p", { style: lore ? styles5.ruleText : styles5.note, children: lore || "No team lore has been written yet." }),
    feedback && /* @__PURE__ */ jsx6("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles5.error : styles5.note, children: feedback.message }),
    editing && feedback?.conflict && /* @__PURE__ */ jsxs6("div", { children: [
      /* @__PURE__ */ jsx6("strong", { children: "Currently saved lore" }),
      /* @__PURE__ */ jsx6("p", { style: styles5.ruleText, children: lore || "No team lore has been written yet." })
    ] })
  ] });
}
function ExpeditionTeams() {
  const { hash } = useLocation2();
  const [searchParams, setSearchParams] = useSearchParams3();
  const [teams2, setTeams] = useState4(null);
  const [assignedTeam, setAssignedTeam] = useState4("");
  const [universalEquipment2, setUniversalEquipment] = useState4(universalEquipment);
  const [editingTeam, setEditingTeam] = useState4(null);
  const [loadError, setLoadError] = useState4("");
  const [reload, setReload] = useState4(0);
  useEffect4(() => {
    const event = getAuthEventName();
    const refresh = () => setReload((value) => value + 1);
    window.addEventListener(event, refresh);
    return () => window.removeEventListener(event, refresh);
  }, []);
  useEffect4(() => {
    let ignore = false;
    setTeams(null);
    setEditingTeam(null);
    setLoadError("");
    async function loadTeams() {
      try {
        const { response, payload } = await fetchJson("/expedition/teams", { method: "GET" });
        if (!response.ok || !Array.isArray(payload.teams)) throw new Error(payload.message || "Unable to load Expedition teams.");
        if (ignore) return;
        const ownTeam = payload.teams.find((entry) => entry.name === payload.assignedTeam)?.name || "";
        setAssignedTeam(ownTeam);
        setUniversalEquipment(payload.universalEquipment ?? universalEquipment);
        setTeams(payload.teams);
      } catch (error) {
        if (!ignore) setLoadError(error.message);
      }
    }
    loadTeams();
    return () => {
      ignore = true;
    };
  }, [reload]);
  const requestedTeam = searchParams.get("team");
  const team = requestedTeam === null ? teams2?.find((entry) => entry.name === assignedTeam) ?? teams2?.[0] : teams2?.find((entry) => entry.name === requestedTeam.trim().toLowerCase());
  const selectedTeam = team?.name;
  useEffect4(() => {
    setEditingTeam(null);
  }, [selectedTeam]);
  if (requestedTeam === null && selectedTeam) {
    const next = new URLSearchParams(searchParams);
    next.set("team", selectedTeam);
    return /* @__PURE__ */ jsx6(Navigate2, { to: { search: `?${next}`, hash }, replace: true });
  }
  const [accent, tint] = teamThemes[team?.name] ?? ["#dedede", "#292929"];
  const canEditRoster = Boolean(team?.canAddEntries);
  const editing = canEditRoster && editingTeam === selectedTeam;
  const updateSelectedTeam = (update) => {
    setTeams((current) => current?.map((entry) => entry.name === selectedTeam ? { ...entry, ...update(entry) } : entry) ?? null);
  };
  return /* @__PURE__ */ jsx6("main", { style: { ...styles5.page, "--team-accent": accent, "--team-tint": tint }, children: /* @__PURE__ */ jsxs6("div", { style: styles5.layout, children: [
    /* @__PURE__ */ jsxs6("div", { style: styles5.header, children: [
      /* @__PURE__ */ jsxs6("div", { style: { flex: "1 1 210px", minWidth: 0 }, children: [
        /* @__PURE__ */ jsx6(Link3, { to: "/projects/Expedition", style: styles5.link, children: "\u2190 Expedition" }),
        team ? /* @__PURE__ */ jsx6(
          TeamTitle,
          {
            team,
            editing,
            onSave: (displayName) => updateSelectedTeam(() => ({ displayName }))
          },
          team.name
        ) : /* @__PURE__ */ jsx6("h1", { style: styles5.title, children: "Teams" })
      ] }),
      /* @__PURE__ */ jsxs6("div", { style: styles5.headerControls, children: [
        teams2?.length > 0 && (teams2.length > 1 || !team) && /* @__PURE__ */ jsxs6("label", { style: { ...styles5.label, minWidth: 0, maxWidth: "280px" }, children: [
          "Team",
          /* @__PURE__ */ jsxs6("select", { value: selectedTeam ?? "", onChange: (event) => {
            const next = new URLSearchParams(searchParams);
            next.set("team", event.target.value);
            setSearchParams(next);
          }, style: styles5.field, children: [
            !team && /* @__PURE__ */ jsx6("option", { value: "", disabled: true, children: "Choose a team" }),
            teams2.map((entry) => /* @__PURE__ */ jsxs6("option", { value: entry.name, children: [
              teamOptionLabel(entry),
              entry.name === assignedTeam ? " (your team)" : ""
            ] }, entry.name))
          ] })
        ] }),
        canEditRoster && /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            "aria-label": "Edit roster",
            "aria-pressed": editing,
            "aria-controls": "expedition-team-lore expedition-units expedition-equipment",
            title: editing ? "Done editing roster" : "Edit roster",
            onClick: () => setEditingTeam((current) => current === selectedTeam ? null : selectedTeam),
            style: { ...styles5.button, ...styles5.pencil, ...editing ? { background: "var(--team-tint)", border: "1px solid var(--team-accent)" } : {} },
            children: /* @__PURE__ */ jsx6("span", { "aria-hidden": "true", children: "\u270E" })
          }
        )
      ] })
    ] }),
    loadError ? /* @__PURE__ */ jsxs6("div", { style: styles5.card, children: [
      /* @__PURE__ */ jsx6("p", { role: "alert", style: styles5.error, children: loadError }),
      /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setReload((value) => value + 1), style: { ...styles5.button, justifySelf: "start" }, children: "Retry" })
    ] }) : !teams2 ? /* @__PURE__ */ jsx6("p", { role: "status", style: styles5.note, children: "Loading Expedition teams\u2026" }) : !team ? /* @__PURE__ */ jsx6("p", { style: styles5.note, children: teams2.length ? "That team is unavailable. Choose a team to continue." : "No Expedition teams are available." }) : /* @__PURE__ */ jsxs6(Fragment3, { children: [
      /* @__PURE__ */ jsxs6("div", { style: styles5.layout, children: [
        /* @__PURE__ */ jsxs6("div", { style: styles5.teamOverview, children: [
          /* @__PURE__ */ jsx6(TeamPoints, { team, onChange: updateSelectedTeam }),
          /* @__PURE__ */ jsx6(TeamLocations, { locations: team.locations })
        ] }),
        /* @__PURE__ */ jsx6(TeamLore, { team, editing, onSave: (lore) => updateSelectedTeam(() => ({ lore })) }),
        /* @__PURE__ */ jsx6(TeamUnits, { team, editing, onChange: updateSelectedTeam }),
        /* @__PURE__ */ jsx6(
          TeamEquipment,
          {
            team,
            universalEquipment: universalEquipment2,
            editing,
            onChange: updateSelectedTeam,
            onUniversalSave: (updated) => setUniversalEquipment((current) => current.map((item2) => item2.id === updated.id ? updated : item2))
          }
        )
      ] }, team.name),
      /* @__PURE__ */ jsx6(ActiveBounties, {}, reload)
    ] })
  ] }) });
}

// Expedition/ExpeditionBattles.jsx
import { useEffect as useEffect5, useRef as useRef3, useState as useState5 } from "react";
import { Link as Link4, useSearchParams as useSearchParams4 } from "react-router-dom";
import { Fragment as Fragment4, jsx as jsx7, jsxs as jsxs7 } from "react/jsx-runtime";
var { battleFields, battleGroups, readSettings: readSettings2 } = globalThis.ExpeditionPointRewards;
var battlePath = "/projects/ExpeditionBattles";
var emptyBattleChoices = { battleType: "", battleSide: "", battleOpponent: "", battleOpponents: [], battleLocation: "", battleOutcome: "", scores: {} };
var statusLabels = { pending: "Pending review", accepted: "Approved", denied: "Denied", canceled: "Canceled" };
var battleSortOptions = {
  date: { ascending: "oldest", descending: "newest" },
  name: { ascending: "name-asc", descending: "name-desc" }
};
var teamLabel2 = (team) => team === "outside-player" ? "Outside Player" : team ? `${team[0].toUpperCase()}${team.slice(1)} Team` : "Unknown team";
var battleTypeLabel = (record) => battleTypes[record.changeSet.battleType] || "Battle";
var battleName = (record) => typeof record.changeSet.battleName === "string" && record.changeSet.battleName.trim() || "Unnamed battle";
var battleDate = (record) => String(record.changeSet.battleDate || record.createdAt || "");
var tileTeams = (tile) => [.../* @__PURE__ */ new Set([tile?.marker, tile?.secondaryMarker])].filter((team) => Object.hasOwn(teamMarkerColors, team));
var navButton = { ...styles3.button, display: "inline-flex", justifyContent: "center", minWidth: "110px", textDecoration: "none", fontWeight: 600 };
var activeNavButton = { ...navButton, background: "#555", border: "1px solid #aaa" };
var pairedFields = { ...styles3.fields, alignItems: "start" };
async function request(path, body) {
  const options = body ? { method: "POST", body: JSON.stringify(body) } : { method: "GET" };
  const { response, payload } = await fetchJson(`/expedition${path}`, options);
  if (!response.ok) throw new Error(payload.message || "Unable to load or save Expedition battles.");
  return payload;
}
function useBattleEquipment(team, editId) {
  const [state, setState] = useState5(null);
  const [reload, setReload] = useState5(0);
  const query = new URLSearchParams(team ? { team } : {});
  if (editId) query.set("edit", editId);
  const path = team ? `/battle-equipment?${query}` : "";
  useEffect5(() => {
    if (!path) return;
    let ignore = false;
    setState(null);
    request(path).then(
      (payload) => {
        if (!ignore) setState({ path, items: payload.equipment });
      },
      (error) => {
        if (!ignore) setState({ path, error: error.message });
      }
    );
    return () => {
      ignore = true;
    };
  }, [path, reload]);
  const current = state?.path === path ? state : null;
  return {
    items: current?.items ?? [],
    ready: !path || Boolean(current?.items),
    error: current?.error,
    retry: () => setReload((value) => value + 1)
  };
}
function BattleEquipmentPicker({ inventory, selected, onChange, disabled }) {
  const total = equipmentCount(selected);
  const unavailable = selected.some((entry) => !inventory.items.some((item2) => item2.id === entry.id && item2.available >= entry.quantity));
  function choose(id, quantity) {
    const rest = selected.filter((item2) => item2.id !== id);
    onChange(quantity ? [...rest, { id, quantity }] : rest);
  }
  return /* @__PURE__ */ jsxs7("fieldset", { disabled, style: { ...styles3.card, margin: 0 }, children: [
    /* @__PURE__ */ jsx7("legend", { children: "Equipment used" }),
    /* @__PURE__ */ jsxs7("div", { style: { ...styles3.row, justifyContent: "space-between" }, children: [
      /* @__PURE__ */ jsxs7("p", { style: styles3.note, children: [
        total,
        " of ",
        battleEquipmentLimit,
        " selected"
      ] }),
      inventory.ready && /* @__PURE__ */ jsx7("button", { type: "button", style: styles3.button, onClick: inventory.retry, children: "Refresh equipment" })
    ] }),
    inventory.error ? /* @__PURE__ */ jsxs7("div", { style: styles3.row, children: [
      /* @__PURE__ */ jsx7("p", { role: "alert", style: styles3.error, children: inventory.error }),
      /* @__PURE__ */ jsx7("button", { type: "button", style: styles3.button, onClick: inventory.retry, children: "Retry equipment" })
    ] }) : !inventory.ready ? /* @__PURE__ */ jsx7("p", { role: "status", style: styles3.note, children: "Loading equipment\u2026" }) : /* @__PURE__ */ jsxs7(Fragment4, { children: [
      [
        ["universal", "Universal Equipment", "Unlimited use"],
        ["faction", "Faction Equipment", "Unlimited use"],
        ["purchased", "Purchased Equipment", "Single use"]
      ].map(([kind, title, rule]) => {
        const items = inventory.items.filter((item2) => item2.kind === kind);
        return /* @__PURE__ */ jsxs7("div", { style: styles3.stack, children: [
          /* @__PURE__ */ jsxs7("strong", { children: [
            title,
            " \xB7 ",
            rule
          ] }),
          items.length === 0 && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "None available." }),
          items.map((item2) => {
            const quantity = selected.find((entry) => entry.id === item2.id)?.quantity ?? 0;
            const max = Math.min(item2.available, battleEquipmentLimit - total + quantity);
            return /* @__PURE__ */ jsxs7("div", { style: { display: "grid", gap: "5px" }, children: [
              kind !== "purchased" ? /* @__PURE__ */ jsxs7("label", { style: { ...styles3.row, gap: "6px" }, children: [
                /* @__PURE__ */ jsx7(
                  "input",
                  {
                    type: "checkbox",
                    checked: quantity > 0,
                    disabled: !quantity && max <= 0,
                    onChange: (event) => choose(item2.id, event.target.checked ? 1 : 0)
                  }
                ),
                item2.name
              ] }) : /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
                item2.name,
                " \xB7 ",
                item2.available,
                " available",
                /* @__PURE__ */ jsx7(
                  "select",
                  {
                    style: styles3.field,
                    value: quantity,
                    disabled: max === 0,
                    onChange: (event) => choose(item2.id, Number(event.target.value)),
                    children: Array.from({ length: Math.max(quantity, max) + 1 }, (_, amount) => /* @__PURE__ */ jsx7("option", { value: amount, disabled: amount > max, children: amount }, amount))
                  }
                )
              ] }),
              (item2.description || item2.action) && /* @__PURE__ */ jsxs7("details", { children: [
                /* @__PURE__ */ jsx7("summary", { style: { cursor: "pointer" }, "aria-label": `${item2.name} rules`, children: "Rules" }),
                /* @__PURE__ */ jsx7(EquipmentRules, { equipment: item2, showEmptyAbility: true })
              ] })
            ] }, item2.id);
          })
        ] }, kind);
      }),
      unavailable && /* @__PURE__ */ jsxs7("div", { style: styles3.row, children: [
        /* @__PURE__ */ jsx7("p", { style: styles3.error, children: "Some selected equipment is unavailable." }),
        /* @__PURE__ */ jsx7("button", { type: "button", style: styles3.button, onClick: () => onChange([]), children: "Clear selection" })
      ] })
    ] })
  ] });
}
function SelectField({ label, options, value, onChange, disabled = false, placeholder = `Select ${label.toLowerCase()}`, markers = [] }) {
  return /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
    /* @__PURE__ */ jsxs7("span", { style: styles3.labelRow, children: [
      label,
      markers.map((team) => /* @__PURE__ */ jsx7(
        "span",
        {
          title: teamLabel2(team),
          "aria-hidden": "true",
          style: { ...styles3.teamMarker, backgroundColor: teamMarkerColors[team] }
        },
        team
      ))
    ] }),
    /* @__PURE__ */ jsxs7("select", { value, onChange: (event) => onChange(event.target.value), disabled, required: true, style: styles3.field, children: [
      /* @__PURE__ */ jsx7("option", { value: "", children: placeholder }),
      options.map(([key, name]) => /* @__PURE__ */ jsx7("option", { value: key, children: name }, key))
    ] })
  ] });
}
function CheckGroup({ title, choices, selected, limit, onChange, disabled = false, hint }) {
  return /* @__PURE__ */ jsxs7("fieldset", { disabled, style: { ...styles3.card, margin: 0 }, children: [
    /* @__PURE__ */ jsx7("legend", { children: title }),
    hint && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: hint }),
    /* @__PURE__ */ jsx7("div", { style: styles3.row, children: choices.map((team) => /* @__PURE__ */ jsxs7("label", { style: { ...styles3.row, gap: "5px" }, children: [
      /* @__PURE__ */ jsx7(
        "input",
        {
          type: "checkbox",
          checked: selected.includes(team),
          disabled: !selected.includes(team) && selected.length >= limit,
          onChange: (event) => onChange(event.target.checked ? [...selected, team] : selected.filter((value) => value !== team))
        }
      ),
      teamLabel2(team)
    ] }, team)) })
  ] });
}
function JointOutcomeField({ value, onChange, disabled }) {
  return /* @__PURE__ */ jsxs7("fieldset", { disabled, style: { ...styles3.card, margin: 0 }, children: [
    /* @__PURE__ */ jsx7("legend", { children: "Outcome" }),
    /* @__PURE__ */ jsx7("div", { style: styles3.row, children: [["joint-win", "Joint victory"], ["joint-loss", "Joint defeat"], ["draw", "Draw"]].map(([option, label]) => /* @__PURE__ */ jsxs7("label", { style: { ...styles3.row, gap: "5px" }, children: [
      /* @__PURE__ */ jsx7(
        "input",
        {
          type: "radio",
          name: "battle-winner",
          value: option,
          checked: value === option,
          required: true,
          onChange: () => onChange(option)
        }
      ),
      label
    ] }, option)) })
  ] });
}
function BattleRewardTable({ rows, overrides, onOverride }) {
  return /* @__PURE__ */ jsxs7("table", { "aria-label": "Projected rewards", style: { width: "100%", tableLayout: "fixed", textAlign: "left", borderSpacing: "6px", overflowWrap: "anywhere" }, children: [
    /* @__PURE__ */ jsx7("thead", { children: /* @__PURE__ */ jsxs7("tr", { children: [
      /* @__PURE__ */ jsx7("th", { scope: "col", children: "Participant" }),
      Object.entries(battleRewardFields).map(([key, { label }]) => /* @__PURE__ */ jsx7("th", { scope: "col", children: label }, key))
    ] }) }),
    /* @__PURE__ */ jsx7("tbody", { children: rows.map((row) => /* @__PURE__ */ jsxs7("tr", { children: [
      /* @__PURE__ */ jsx7("th", { scope: "row", children: teamLabel2(row.team) }),
      Object.entries(battleRewardFields).map(([key, { label, max }]) => /* @__PURE__ */ jsxs7("td", { children: [
        row.cappedRewards?.[key] == null ? row[key] : row[key] === 0 ? "0 (At Cap)" : /* @__PURE__ */ jsxs7(Fragment4, { children: [
          row.cappedRewards[key],
          " earned",
          /* @__PURE__ */ jsxs7("small", { style: { display: "block", color: "#ddd" }, children: [
            row[key],
            " can be added (balance cap)"
          ] })
        ] }),
        onOverride && /* @__PURE__ */ jsx7(
          "input",
          {
            "aria-label": `Override ${teamLabel2(row.team)} ${label}`,
            type: "number",
            min: "0",
            max,
            step: "1",
            placeholder: "Default",
            style: styles3.field,
            value: overrides[row.team]?.[key] ?? "",
            onChange: (event) => onOverride(row.team, key, event.target.value)
          }
        )
      ] }, key))
    ] }, row.team)) })
  ] });
}
function BattleForm({ data, record, onSave, onClose }) {
  const { access, map } = data;
  const recordedBattle = record?.changeSet;
  const approved = record?.status === "accepted";
  const recordedLocation = approved ? recordedBattle.battleLocation : void 0;
  const [draft, setDraft] = useState5(() => ({
    ...emptyBattleChoices,
    requesterTeam: access.team || "",
    ...recordedBattle,
    battleOpponents: battleTeamList(recordedBattle?.battleOpponents),
    battleOutcome: recordedBattle?.battleType === "joint-op" ? recordedBattle.battleOutcome === "draw" ? "draw" : battleOutcome(recordedBattle).winners.length ? "joint-win" : "joint-loss" : "",
    scores: recordedBattle?.battleScores ?? {},
    battleName: recordedBattle?.battleName || "",
    battleDate: recordedBattle?.battleDate || "",
    lore: recordedBattle?.lore || "",
    comment: recordedBattle?.comment || ""
  }));
  const [error, setError] = useState5("");
  const [busy, setBusy] = useState5(false);
  const [overrides, setOverrides] = useState5(() => record?.rewardOverrides ?? {});
  const [overrideEnabled, setOverrideEnabled] = useState5(() => Object.keys(overrides).length > 0);
  const canChooseEquipment = !approved && (!record || record.own);
  const [equipment, setEquipment] = useState5(() => record?.equipmentUsed?.find((use) => use.source === "reporter")?.items.map(({ id, quantity }) => ({ id, quantity })) ?? []);
  const inventory = useBattleEquipment(canChooseEquipment ? draft.requesterTeam : "", record?.id);
  const multiplayer = draft.battleType === "multiplayer-op";
  const compound = draft.battleType === "compound-op";
  const joint = draft.battleType === "joint-op";
  const opponents = [...access.teams.filter((team) => joint || team !== draft.requesterTeam), ...joint ? [] : ["outside-player"]];
  const hasOpponents = multiplayer ? draft.battleOpponents.length >= 2 : Boolean(draft.battleOpponent);
  const participants = battleParticipants(draft);
  const scores = Object.fromEntries(participants.map((team) => [team, draft.scores[team] ?? ""]));
  const useRecordedOutcome = !joint && recordedBattle && !recordedBattle.battleScores && recordedBattle.battleType === draft.battleType && recordedBattle.requesterTeam === draft.requesterTeam && (recordedBattle.battleSide || "") === draft.battleSide && battleParticipants(recordedBattle).join(",") === participants.join(",") && Object.values(scores).every((score) => score === "");
  const legacyOutcome = useRecordedOutcome ? Object.fromEntries(Object.entries({
    battleResult: recordedBattle.battleResult,
    battleOutcome: recordedBattle.battleOutcome,
    battleWinner: recordedBattle.battleWinner,
    battleWinners: recordedBattle.battleWinners,
    battleTiedTeams: recordedBattle.battleTiedTeams
  }).filter(([, value]) => value !== void 0)) : null;
  const outcome = joint ? { battleOutcome: draft.battleOutcome } : legacyOutcome ?? { battleScores: scores };
  const contest = {
    battleType: draft.battleType,
    battleSide: draft.battleSide,
    battleLocation: draft.battleLocation,
    requesterTeam: draft.requesterTeam,
    battleOpponent: multiplayer ? draft.battleOpponents[0] : draft.battleOpponent,
    battleOpponents: draft.battleOpponents,
    ...outcome
  };
  const rewardOverrides = overrideEnabled ? Object.fromEntries(Object.entries(overrides).filter(([team]) => participants.includes(team))) : {};
  const validOverrides = validRewardOverrides(contest, access.teams, rewardOverrides);
  const payoutReady = draft.requesterTeam && hasOpponents && (joint ? draft.battleOutcome : useRecordedOutcome || validBattleScores(contest));
  const rewardRows = payoutReady ? projectedBattlePayouts(contest, map.pointRewards, access.teams, map.teamStats, validOverrides ? rewardOverrides : {}) : [];
  const canChooseTile = draft.battleType && draft.requesterTeam && hasOpponents && (!compound || draft.battleSide);
  const locations = canChooseTile ? battleLocationOptions(draft, map.tiles) : [];
  if (recordedLocation && !locations.some((tile) => tile.id === recordedLocation)) {
    locations.push(map.tiles?.find((tile) => tile.id === recordedLocation) ?? { id: recordedLocation });
  }
  const locationOptions = locations.map((tile) => {
    const parts = [`Tile ${tile.id}`];
    if (tile.locationNumber) parts.push(`Location ${tile.locationNumber}`);
    const teams2 = tileTeams(tile);
    if (teams2.length) parts.push(teams2.map(teamLabel2).join(", "));
    return [tile.id, parts.join(" \xB7 ")];
  });
  const selectedTile = locations.find((tile) => tile.id === draft.battleLocation);
  const set = (patch) => setDraft((current) => ({ ...current, ...patch }));
  function changeReward(team, field, value) {
    setOverrides((current) => {
      const next = { ...current };
      const amounts = { ...next[team] };
      if (value === "") delete amounts[field];
      else amounts[field] = Number(value);
      if (Object.keys(amounts).length) next[team] = amounts;
      else delete next[team];
      return next;
    });
  }
  async function submit(event) {
    event.preventDefault();
    if (!inventory.ready) return;
    const { battleName: battleName2, battleDate: battleDate2, lore, comment } = draft;
    const changeSet = {
      requestType: "battle",
      changes: [],
      battleName: battleName2.trim(),
      battleDate: battleDate2,
      lore: lore.trim(),
      comment: comment.trim(),
      ...contest
    };
    const invalid = validateBattle(changeSet, access.teams, map.tiles, { recordedLocation });
    if (invalid) {
      setError(invalid);
      return;
    }
    if (!approved && !validOverrides) {
      setError("Enter valid whole-number reward amounts for each participating team.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await onSave(changeSet, record, canChooseEquipment ? equipment : void 0, approved ? void 0 : rewardOverrides);
    } catch (error2) {
      setError(error2.message);
    } finally {
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxs7("form", { style: styles3.card, onSubmit: submit, children: [
    /* @__PURE__ */ jsx7("h2", { style: styles3.subheading, children: record ? "Edit battle report" : "Log a battle" }),
    !record && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Either side can submit. The report publishes when the other Expedition participants confirm it or an Admin approves it." }),
    approved && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Rewards and equipment usage are recorded at approval." }),
    !approved && record?.review?.confirmedTeams.length > 0 && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Saving changes resets the player confirmations." }),
    /* @__PURE__ */ jsxs7("fieldset", { disabled: busy, style: { ...styles3.stack, border: 0, margin: 0, padding: 0, minWidth: 0 }, children: [
      /* @__PURE__ */ jsxs7("div", { style: styles3.stack, children: [
        access.canReview && /* @__PURE__ */ jsx7(
          SelectField,
          {
            label: "Reporting team",
            options: access.teams.map((team) => [team, teamLabel2(team)]),
            value: draft.requesterTeam,
            onChange: (requesterTeam) => {
              setEquipment([]);
              setOverrides({});
              set({ requesterTeam, battleOpponent: "", battleOpponents: [], battleLocation: "", battleOutcome: "", scores: {} });
            }
          }
        ),
        /* @__PURE__ */ jsxs7("div", { style: pairedFields, children: [
          /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
            "Name Battle",
            /* @__PURE__ */ jsx7("input", { type: "text", value: draft.battleName, onChange: (event) => set({ battleName: event.target.value }), style: styles3.field })
          ] }),
          /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
            "Battle date",
            /* @__PURE__ */ jsx7(
              "input",
              {
                type: "date",
                value: draft.battleDate,
                onChange: (event) => set({ battleDate: event.target.value }),
                style: { ...styles3.field, colorScheme: "dark" }
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs7("div", { style: pairedFields, children: [
          /* @__PURE__ */ jsx7(
            SelectField,
            {
              label: "Battle type",
              options: Object.entries(battleTypes),
              value: draft.battleType,
              onChange: (battleType) => {
                setOverrides({});
                set({ ...emptyBattleChoices, battleType });
              }
            }
          ),
          multiplayer ? /* @__PURE__ */ jsx7(
            CheckGroup,
            {
              title: "Opponents (2\u20133)",
              choices: opponents,
              selected: draft.battleOpponents,
              limit: 3,
              disabled: !draft.requesterTeam,
              hint: !draft.requesterTeam ? "Select the reporting team." : void 0,
              onChange: (battleOpponents) => set({ battleOpponents, battleLocation: "" })
            }
          ) : /* @__PURE__ */ jsx7(
            SelectField,
            {
              label: joint ? "Teammate" : "Opponent",
              options: opponents.map((team) => [team, teamLabel2(team)]),
              disabled: !draft.battleType || !draft.requesterTeam,
              value: draft.battleOpponent,
              onChange: (battleOpponent) => set({ battleOpponent, battleLocation: "" })
            }
          )
        ] }),
        compound && /* @__PURE__ */ jsx7(
          SelectField,
          {
            label: "Reporting team\u2019s role",
            options: [["attacker", "Attacker"], ["defender", "Defender"]],
            value: draft.battleSide,
            onChange: (battleSide) => set({ battleSide, battleLocation: "" })
          }
        ),
        /* @__PURE__ */ jsxs7("div", { style: pairedFields, children: [
          /* @__PURE__ */ jsx7(
            SelectField,
            {
              label: "Battle tile",
              options: locationOptions,
              markers: tileTeams(selectedTile),
              disabled: !locations.length,
              placeholder: locations.length ? void 0 : canChooseTile ? "No eligible tiles" : "Select participants and any required role first",
              value: draft.battleLocation,
              onChange: (battleLocation) => set({ battleLocation })
            }
          ),
          joint ? /* @__PURE__ */ jsx7(
            JointOutcomeField,
            {
              value: draft.battleOutcome,
              disabled: !draft.requesterTeam || !hasOpponents,
              onChange: (battleOutcome2) => set({ battleOutcome: battleOutcome2 })
            }
          ) : /* @__PURE__ */ jsxs7("fieldset", { disabled: !draft.battleType || !draft.requesterTeam || !hasOpponents, style: { ...styles3.card, margin: 0 }, children: [
            /* @__PURE__ */ jsx7("legend", { children: "Scores" }),
            participants.map((team) => /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
              teamLabel2(team),
              " score",
              /* @__PURE__ */ jsx7(
                "input",
                {
                  type: "number",
                  min: "0",
                  max: Number.MAX_SAFE_INTEGER,
                  step: "1",
                  required: !useRecordedOutcome,
                  value: scores[team],
                  style: styles3.field,
                  onChange: (event) => set({ scores: { ...draft.scores, [team]: event.target.value === "" ? "" : Number(event.target.value) } })
                }
              )
            ] }, team)),
            useRecordedOutcome && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Leave scores blank to keep the recorded outcome." })
          ] })
        ] })
      ] }),
      canChooseEquipment && draft.requesterTeam && /* @__PURE__ */ jsx7(BattleEquipmentPicker, { inventory, selected: equipment, onChange: setEquipment }),
      /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
        "Lore",
        /* @__PURE__ */ jsx7("textarea", { value: draft.lore, onChange: (event) => set({ lore: event.target.value }), rows: 4, style: styles3.field })
      ] }),
      /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
        "Notes",
        /* @__PURE__ */ jsx7("textarea", { value: draft.comment, onChange: (event) => set({ comment: event.target.value }), rows: 3, style: styles3.field })
      ] }),
      !approved && /* @__PURE__ */ jsxs7("fieldset", { style: { ...styles3.card, margin: 0 }, children: [
        /* @__PURE__ */ jsx7("legend", { children: "Projected rewards" }),
        rewardRows.length > 0 ? /* @__PURE__ */ jsxs7(Fragment4, { children: [
          /* @__PURE__ */ jsxs7("label", { style: styles3.row, children: [
            /* @__PURE__ */ jsx7("input", { type: "checkbox", checked: overrideEnabled, onChange: (event) => {
              setOverrideEnabled(event.target.checked);
              if (!event.target.checked) setOverrides({});
            } }),
            "Override rewards"
          ] }),
          /* @__PURE__ */ jsx7(BattleRewardTable, { rows: rewardRows, overrides: rewardOverrides, onOverride: overrideEnabled ? changeReward : void 0 }),
          overrideEnabled && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Manual reward amounts require Expedition Admin approval." })
        ] }) : /* @__PURE__ */ jsx7("p", { style: styles3.note, children: joint ? "Choose the Joint Op outcome to calculate rewards." : "Enter all participant scores to calculate rewards." })
      ] }),
      /* @__PURE__ */ jsxs7("div", { style: styles3.row, children: [
        /* @__PURE__ */ jsx7("button", { type: "submit", disabled: !inventory.ready, style: styles3.button, children: record ? "Save battle report" : "Submit for review" }),
        /* @__PURE__ */ jsx7("button", { type: "button", onClick: onClose, style: styles3.button, children: "Close" })
      ] })
    ] }),
    error && /* @__PURE__ */ jsx7("p", { role: "alert", style: styles3.error, children: error })
  ] });
}
function BattleSettings({ initial }) {
  const [values, setValues] = useState5(() => readSettings2(initial));
  const [busy, setBusy] = useState5(false);
  const [feedback, setFeedback] = useState5(null);
  async function save(event) {
    event.preventDefault();
    setBusy(true);
    setFeedback(null);
    try {
      const pointRewards = Object.fromEntries(battleFields.map(([key]) => [key, Number(values[key])]));
      const response = await request("/battle-settings", { pointRewards });
      setValues(readSettings2(response.pointRewards));
      setFeedback({ text: "Battle settings saved." });
    } catch (error) {
      setFeedback({ text: error.message, error: true });
    } finally {
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxs7("form", { style: styles3.card, onSubmit: save, children: [
    /* @__PURE__ */ jsx7("h2", { style: styles3.subheading, children: "Battle Point Rewards" }),
    /* @__PURE__ */ jsx7("fieldset", { disabled: busy, style: { ...styles3.stack, border: 0, padding: 0, margin: 0, minWidth: 0 }, children: battleGroups.map(([title, rows]) => /* @__PURE__ */ jsxs7("fieldset", { style: { ...styles3.card, margin: 0 }, children: [
      /* @__PURE__ */ jsx7("legend", { children: title }),
      /* @__PURE__ */ jsxs7("table", { style: { width: "100%", tableLayout: "fixed", textAlign: "left", borderSpacing: "6px" }, children: [
        /* @__PURE__ */ jsx7("thead", { children: /* @__PURE__ */ jsxs7("tr", { children: [
          /* @__PURE__ */ jsx7("th", { scope: "col", children: "Outcome" }),
          /* @__PURE__ */ jsx7("th", { scope: "col", children: "Campaign Points" }),
          /* @__PURE__ */ jsx7("th", { scope: "col", children: "Supply Points" })
        ] }) }),
        /* @__PURE__ */ jsx7("tbody", { children: rows.map(({ label, fields }) => /* @__PURE__ */ jsxs7("tr", { children: [
          /* @__PURE__ */ jsx7("th", { scope: "row", children: label }),
          fields.map(([key, points, , max]) => /* @__PURE__ */ jsx7("td", { children: /* @__PURE__ */ jsx7(
            "input",
            {
              "aria-label": `${title} ${label} ${points}`,
              type: "number",
              min: "0",
              max: max ?? Number.MAX_SAFE_INTEGER,
              step: "1",
              required: true,
              value: values[key],
              onChange: (event) => setValues({ ...values, [key]: event.target.value }),
              style: styles3.field
            }
          ) }, key))
        ] }, label)) })
      ] })
    ] }, title)) }),
    /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Compound Op rewards are pending." }),
    /* @__PURE__ */ jsx7("div", { children: /* @__PURE__ */ jsx7("button", { type: "submit", disabled: busy, style: styles3.button, children: "Save battle settings" }) }),
    feedback && /* @__PURE__ */ jsx7("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles3.error : styles3.note, children: feedback.text })
  ] });
}
function BattleRecord({ record, access, reviewing, onReview, onEdit }) {
  const battle = record.changeSet;
  const battleDetails = `${battleTypeLabel(record)} \xB7 ${battle.battleLocation ? `Tile ${battle.battleLocation}` : "Tile unrecorded"}`;
  const { winners, result, tied } = battleOutcome(battle);
  const outcomeLabel = tied?.length ? `Draw \xB7 ${tied.map(teamLabel2).join(", ")} tied for first` : winners.length ? `${winners.map(teamLabel2).join(", ")} won${result ? ` (${result})` : ""}` : result;
  const pending = record.status === "pending";
  const own = record.own;
  const review = record.review;
  const [equipment, setEquipment] = useState5([]);
  const inventory = useBattleEquipment(review?.canConfirm ? access.team : "");
  const equipmentUsed = record.equipmentUsed?.filter((use) => use.items.length) ?? [];
  const awaiting = review?.requiredTeams.filter((team) => !review.confirmedTeams.includes(team)) ?? [];
  const date = (value) => new Date(value).toLocaleString();
  return /* @__PURE__ */ jsxs7("article", { style: styles3.card, children: [
    /* @__PURE__ */ jsxs7("div", { style: { ...styles3.row, justifyContent: "space-between" }, children: [
      /* @__PURE__ */ jsx7("h3", { style: { ...styles3.subheading, overflowWrap: "anywhere" }, children: battle.battleName || battleDetails }),
      /* @__PURE__ */ jsx7("strong", { children: statusLabels[record.status] || record.status })
    ] }),
    battle.battleName && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: battleDetails }),
    /* @__PURE__ */ jsxs7("dl", { style: styles3.details, children: [
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { style: { display: "inline" }, children: "Logged in round " }),
        /* @__PURE__ */ jsx7("dd", { style: { display: "inline", margin: 0 }, children: battleSubmissionRound(battle) ?? "Unrecorded" })
      ] }),
      battle.battleDate && /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { style: { display: "inline" }, children: "Battle date " }),
        /* @__PURE__ */ jsx7("dd", { style: { display: "inline", margin: 0 }, children: /* @__PURE__ */ jsx7("time", { dateTime: battle.battleDate, children: new Date(battle.battleDate).toLocaleDateString(void 0, { dateStyle: "medium", timeZone: "UTC" }) }) })
      ] }),
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { style: { display: "inline" }, children: "Teams " }),
        /* @__PURE__ */ jsx7("dd", { style: { display: "inline", margin: 0 }, children: battleParticipants(battle).map(teamLabel2).join(", ") })
      ] }),
      battle.battleScores && /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { style: { display: "inline" }, children: "Scores " }),
        /* @__PURE__ */ jsx7("dd", { style: { display: "inline", margin: 0 }, children: battleParticipants(battle).map((team) => `${teamLabel2(team)} ${battle.battleScores[team]}`).join(" \xB7 ") })
      ] }),
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { style: { display: "inline" }, children: "Outcome " }),
        /* @__PURE__ */ jsx7("dd", { style: { display: "inline", margin: 0 }, children: outcomeLabel })
      ] }),
      battle.battleSide && /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { style: { display: "inline" }, children: "Reporting role " }),
        /* @__PURE__ */ jsxs7("dd", { style: { display: "inline", margin: 0 }, children: [
          teamLabel2(battle.requesterTeam),
          " (",
          battle.battleSide,
          ")"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs7("p", { style: styles3.note, children: [
      "Logged by ",
      record.requesterUsername || "Unknown",
      record.createdAt ? ` \xB7 ${date(record.createdAt)}` : ""
    ] }),
    record.reviewedAt && /* @__PURE__ */ jsxs7("p", { style: styles3.note, children: [
      statusLabels[record.status],
      " ",
      date(record.reviewedAt),
      record.approvalMethod === "participants" ? " by participant confirmation" : record.reviewedByUsername ? ` by ${record.reviewedByUsername}` : ""
    ] }),
    battle.lore && /* @__PURE__ */ jsxs7("div", { children: [
      /* @__PURE__ */ jsx7("strong", { children: "Lore" }),
      /* @__PURE__ */ jsx7("p", { style: styles3.prose, children: battle.lore })
    ] }),
    battle.comment && /* @__PURE__ */ jsx7("p", { style: styles3.prose, children: battle.comment }),
    equipmentUsed.length > 0 && /* @__PURE__ */ jsxs7("div", { style: styles3.stack, children: [
      /* @__PURE__ */ jsx7("strong", { children: "Equipment used" }),
      equipmentUsed.map(({ source, team, player, items }) => /* @__PURE__ */ jsxs7("p", { style: styles3.note, children: [
        player,
        " (",
        teamLabel2(team),
        ") \xB7 ",
        items.map((item2) => `${item2.name}${item2.quantity > 1 ? ` \xD7 ${item2.quantity}` : ""}`).join(", ")
      ] }, `${source}:${team}`))
    ] }),
    record.awardedPoints?.length > 0 && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: record.awardedPoints.map(({ team, amount, field }) => `${teamLabel2(team)} +${amount} ${battleRewardFields[field].label}`).join(" \xB7 ") }),
    pending && /* @__PURE__ */ jsxs7("div", { style: styles3.stack, children: [
      record.projectedRewards?.length > 0 && /* @__PURE__ */ jsx7(BattleRewardTable, { rows: record.projectedRewards }),
      review?.requiresAdminApproval && /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Reward overrides require Expedition Admin approval." }),
      review?.confirmedTeams.length > 0 && /* @__PURE__ */ jsxs7("p", { style: styles3.note, children: [
        "Confirmed by ",
        review.confirmedTeams.map(teamLabel2).join(", ")
      ] }),
      /* @__PURE__ */ jsx7("p", { style: styles3.note, children: awaiting.length ? `Waiting for ${awaiting.map(teamLabel2).join(", ")} to confirm.` : "No participant confirmations required." })
    ] }),
    review?.canConfirm && /* @__PURE__ */ jsx7(BattleEquipmentPicker, { inventory, selected: equipment, onChange: setEquipment, disabled: reviewing }),
    (review?.canEdit || pending && (own || access.canReview || review?.canConfirm)) && /* @__PURE__ */ jsxs7("div", { style: styles3.row, children: [
      review?.canConfirm && /* @__PURE__ */ jsx7(
        "button",
        {
          type: "button",
          disabled: reviewing || !inventory.ready,
          onClick: () => onReview("confirm", equipment),
          style: styles3.button,
          children: "Confirm report"
        }
      ),
      review?.canEdit && /* @__PURE__ */ jsx7("button", { type: "button", disabled: reviewing, onClick: onEdit, style: styles3.button, children: "Edit" }),
      pending && access.canReview && /* @__PURE__ */ jsxs7(Fragment4, { children: [
        /* @__PURE__ */ jsx7(
          "button",
          {
            type: "button",
            disabled: reviewing || !review?.canApprove,
            onClick: () => onReview("accept"),
            title: "Approve without waiting for participant confirmations",
            style: styles3.button,
            children: "Approve as Admin"
          }
        ),
        /* @__PURE__ */ jsx7("button", { type: "button", disabled: reviewing, onClick: () => onReview("deny"), style: styles3.button, children: "Deny" })
      ] }),
      pending && own && /* @__PURE__ */ jsx7("button", { type: "button", disabled: reviewing, onClick: () => onReview("cancel-own"), style: styles3.button, children: "Cancel report" })
    ] })
  ] });
}
function entryColors(battle, participants) {
  const { winners, result, tied } = battleOutcome(battle);
  const leaders = tied?.length ? tied : result === "Draw" ? participants : winners;
  const colors = leaders.map((team) => teamMarkerColors[team] ?? "#888");
  if (colors.length <= 1) return colors[0] || "#666";
  const stops = colors.map((color, index) => `${color} ${100 * index / colors.length}% ${100 * (index + 1) / colors.length}%`);
  return `linear-gradient(to right, ${stops.join(", ")})`;
}
function battleQuery(query, changes) {
  const next = new URLSearchParams(query);
  for (const [key, value] of Object.entries(changes)) {
    next.delete(key);
    const values = Array.isArray(value) ? value : [value];
    values.filter(Boolean).forEach((item2) => next.append(key, item2));
  }
  return next;
}
function BattleFilterGroup({ title, choices, selected, onChange }) {
  return /* @__PURE__ */ jsxs7("fieldset", { style: { ...styles3.stack, margin: 0, padding: "8px", border: "1px solid #666", borderRadius: "5px" }, children: [
    /* @__PURE__ */ jsx7("legend", { children: title }),
    choices.map(([key, label]) => /* @__PURE__ */ jsxs7("label", { style: { ...styles3.row, gap: "6px" }, children: [
      /* @__PURE__ */ jsx7(
        "input",
        {
          type: "checkbox",
          checked: selected.includes(key),
          onChange: (event) => onChange(event.target.checked ? [...selected, key] : selected.filter((value) => value !== key))
        }
      ),
      label
    ] }, key))
  ] });
}
function BattleLog({ pending, records, teams: teams2, query, updateQuery, selectedId, onSelect, onRefresh }) {
  const filterDialog = useRef3(null);
  const search = query.get("q") || "";
  const sortValue = query.get("sort");
  const sortBy = Object.values(battleSortOptions.name).includes(sortValue) ? "name" : "date";
  const direction = sortValue === battleSortOptions[sortBy].ascending ? "ascending" : "descending";
  const nextDirection = direction === "ascending" ? "descending" : "ascending";
  const nextSortBy = sortBy === "name" ? "date" : "name";
  const directionLabel = `Sort order is ${direction}. Switch to ${nextDirection}.`;
  const sortByLabel = `Sorting by ${sortBy}. Switch to ${nextSortBy}.`;
  const types2 = Object.entries(battleTypes);
  const entries = records.map((record) => ({ record, participants: battleParticipants(record.changeSet) }));
  const playerChoices = [.../* @__PURE__ */ new Set([...teams2, ...entries.flatMap((entry) => entry.participants)])].map((team) => [team, teamLabel2(team)]);
  const typeFilters = query.getAll("type").filter((type) => Object.hasOwn(battleTypes, type));
  const playerFilters = query.getAll("player").filter((player) => playerChoices.some(([key]) => player === key));
  const filterCount = typeFilters.length + playerFilters.length;
  const filterLabel = filterCount ? `Filter battles (${filterCount} active)` : "Filter battles";
  const refreshLabel = pending ? "Refresh pending reviews" : "Refresh battle log";
  const searchTerms = search.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const visible = entries.filter(({ record, participants }) => {
    if (typeFilters.length && !typeFilters.includes(record.changeSet.battleType)) return false;
    if (playerFilters.length && !participants.some((team) => playerFilters.includes(team))) return false;
    const searchable = [battleName(record), battleTypeLabel(record), ...participants.map(teamLabel2), record.requesterUsername].join(" ").toLowerCase();
    return searchTerms.every((term) => searchable.includes(term));
  });
  visible.sort(({ record: first }, { record: second }) => {
    const byName = battleName(first).localeCompare(battleName(second), void 0, { sensitivity: "base", numeric: true });
    const byDate = battleDate(first).localeCompare(battleDate(second));
    const order = direction === "ascending" ? 1 : -1;
    return sortBy === "name" ? order * byName || -byDate : order * byDate || byName;
  });
  return /* @__PURE__ */ jsxs7("aside", { "aria-label": pending ? "Pending reviews" : "Battle log", style: { ...styles3.card, ...styles3.sidebar }, children: [
    /* @__PURE__ */ jsx7("h2", { style: styles3.subheading, children: pending ? "Pending Reviews" : "Battle Log" }),
    /* @__PURE__ */ jsxs7("label", { style: styles3.label, children: [
      "Search battles",
      /* @__PURE__ */ jsx7("input", { type: "search", value: search, onChange: (event) => updateQuery({ q: event.target.value }), style: styles3.field })
    ] }),
    /* @__PURE__ */ jsxs7("div", { role: "group", "aria-label": "Battle log controls", style: { ...styles3.row, flexWrap: "nowrap", gap: "8px" }, children: [
      /* @__PURE__ */ jsx7(
        "button",
        {
          type: "button",
          style: sortButton,
          "aria-label": directionLabel,
          title: directionLabel,
          onClick: () => updateQuery({ sort: battleSortOptions[sortBy][nextDirection] }),
          children: /* @__PURE__ */ jsx7("span", { "aria-hidden": "true", children: direction === "ascending" ? "\u2191" : "\u2193" })
        }
      ),
      /* @__PURE__ */ jsx7(
        "button",
        {
          type: "button",
          style: sortButton,
          "aria-label": sortByLabel,
          title: sortByLabel,
          onClick: () => updateQuery({ sort: battleSortOptions[nextSortBy][direction] }),
          children: sortBy === "name" ? /* @__PURE__ */ jsx7("span", { "aria-hidden": "true", children: "A" }) : /* @__PURE__ */ jsx7("span", { "aria-hidden": "true", style: clockFace, children: /* @__PURE__ */ jsx7("span", { style: clockHands }) })
        }
      ),
      /* @__PURE__ */ jsxs7(
        "button",
        {
          type: "button",
          "aria-haspopup": "dialog",
          "aria-controls": "battle-filters",
          "aria-label": filterLabel,
          title: filterLabel,
          style: { ...sortButton, position: "relative" },
          onClick: () => filterDialog.current.showModal(),
          children: [
            /* @__PURE__ */ jsx7("span", { "aria-hidden": "true", style: filterIcon }),
            filterCount > 0 && /* @__PURE__ */ jsx7("span", { "aria-hidden": "true", style: filterBadge, children: filterCount })
          ]
        }
      ),
      /* @__PURE__ */ jsx7("button", { type: "button", style: sortButton, "aria-label": refreshLabel, title: refreshLabel, onClick: onRefresh, children: /* @__PURE__ */ jsx7("span", { "aria-hidden": "true", children: "\u21BB" }) })
    ] }),
    /* @__PURE__ */ jsx7("dialog", { id: "battle-filters", ref: filterDialog, "aria-labelledby": "battle-filters-title", style: styles3.filterDialog, children: /* @__PURE__ */ jsxs7("div", { style: styles3.stack, children: [
      /* @__PURE__ */ jsx7("h2", { id: "battle-filters-title", style: styles3.subheading, children: "Filter battles" }),
      /* @__PURE__ */ jsxs7("div", { style: pairedFields, children: [
        /* @__PURE__ */ jsx7(BattleFilterGroup, { title: "Battle types", choices: types2, selected: typeFilters, onChange: (type) => updateQuery({ type }) }),
        /* @__PURE__ */ jsx7(BattleFilterGroup, { title: "Participants", choices: playerChoices, selected: playerFilters, onChange: (player) => updateQuery({ player }) })
      ] }),
      /* @__PURE__ */ jsxs7("div", { style: { ...styles3.row, justifyContent: "flex-end" }, children: [
        /* @__PURE__ */ jsx7(
          "button",
          {
            type: "button",
            style: styles3.button,
            disabled: filterCount === 0,
            onClick: () => updateQuery({ type: [], player: [] }),
            children: "Clear filters"
          }
        ),
        /* @__PURE__ */ jsx7("button", { type: "button", style: styles3.button, onClick: () => filterDialog.current.close(), children: "Done" })
      ] })
    ] }) }),
    visible.length ? /* @__PURE__ */ jsx7("nav", { "aria-label": "Battle reports", style: styles3.reportList, children: /* @__PURE__ */ jsx7("ul", { style: styles3.entries, children: visible.map(({ record, participants }) => {
      const next = battleQuery(query, { battle: record.id });
      const color = entryColors(record.changeSet, participants);
      const selected = record.id === selectedId;
      return /* @__PURE__ */ jsx7("li", { children: /* @__PURE__ */ jsxs7(
        Link4,
        {
          to: { pathname: battlePath, search: `?${next}` },
          onClick: onSelect,
          "aria-current": selected ? "true" : void 0,
          style: {
            ...styles3.entry,
            borderColor: selected ? "#eee" : "#666",
            background: `linear-gradient(#161616cc, #161616cc), ${color}`
          },
          children: [
            /* @__PURE__ */ jsx7("span", { "aria-hidden": "true", style: { height: "4px", borderRadius: "3px", background: color, boxShadow: "0 0 0 1px #ffffff40" } }),
            /* @__PURE__ */ jsx7("strong", { children: battleName(record) }),
            /* @__PURE__ */ jsx7("span", { children: battleTypeLabel(record) }),
            /* @__PURE__ */ jsx7("span", { style: styles3.note, children: participants.map(teamLabel2).join(", ") })
          ]
        }
      ) }, record.id);
    }) }) }) : /* @__PURE__ */ jsx7("p", { role: "status", style: styles3.note, children: entries.length ? "No battles match your search and filters." : pending ? "No reports awaiting review." : "No approved battles yet." })
  ] });
}
var loadBattles = async () => {
  const [access, map] = await Promise.all([request("/battles"), request("/map")]);
  return { access, map };
};
function ExpeditionBattles(props) {
  if (expeditionBattlesEnabled) return /* @__PURE__ */ jsx7(BattlePage, { ...props });
  return /* @__PURE__ */ jsx7("main", { style: styles3.page, children: /* @__PURE__ */ jsxs7("div", { style: styles3.layout, children: [
    /* @__PURE__ */ jsx7(Link4, { to: "/projects/Expedition", style: styles3.link, children: "\u2190 Expedition" }),
    /* @__PURE__ */ jsx7("h1", { style: styles3.heading, children: "Battles" }),
    /* @__PURE__ */ jsx7("p", { style: styles3.note, children: battlesUnavailableMessage })
  ] }) });
}
function BattlePage({ settings = false }) {
  const [query, setQuery] = useSearchParams4();
  const [data, setData] = useState5(null);
  const [editor, setEditor] = useState5(null);
  const [feedback, setFeedback] = useState5(null);
  const [reviewing, setReviewing] = useState5(false);
  const [loadError, setLoadError] = useState5("");
  const [reload, setReload] = useState5(0);
  const pendingView = query.get("view") === "review";
  const selectedId = query.get("battle");
  const records = pendingView ? data?.access.pendingBattles : data?.access.battles;
  const selectedBattle = records?.find((record) => record.id === selectedId);
  const activeEditor = editor?.selectedId === selectedId ? editor : null;
  const queryString = query.toString();
  const search = queryString ? `?${queryString}` : "";
  function updateQuery(changes, replace = true) {
    setQuery((current) => battleQuery(current, changes), { replace });
  }
  useEffect5(() => {
    const event = getAuthEventName();
    const refresh = () => setReload((value) => value + 1);
    window.addEventListener(event, refresh);
    return () => window.removeEventListener(event, refresh);
  }, []);
  useEffect5(() => {
    let canceled = false;
    setLoadError("");
    setData(null);
    setEditor(null);
    setFeedback(null);
    loadBattles().then(
      (result) => {
        if (!canceled) setData(result);
      },
      (error) => {
        if (!canceled) setLoadError(error.message);
      }
    );
    return () => {
      canceled = true;
    };
  }, [reload, settings]);
  function updateRecord(record) {
    const updatedRecords = (records2, status) => {
      const remaining = records2.filter((item2) => item2.id !== record.id);
      return record.status === status ? [record, ...remaining] : remaining;
    };
    setData((current) => current && {
      ...current,
      access: {
        ...current.access,
        battles: updatedRecords(current.access.battles, "accepted"),
        pendingBattles: updatedRecords(current.access.pendingBattles, "pending")
      }
    });
  }
  async function saveBattle(changeSet, record, equipment, rewardOverrides) {
    const response = await request(record ? "/map-requests/update" : "/map-requests", {
      changeSet,
      equipment,
      rewardOverrides,
      ...record ? { requestId: record.id, expectedRevision: record.revision } : {}
    });
    updateRecord(response.request);
    const needsReview = response.request.status === "pending";
    if (pendingView !== needsReview || response.request.id !== selectedId) {
      updateQuery({ view: needsReview ? "review" : "", battle: response.request.id }, false);
    }
    setEditor(null);
    setFeedback({ text: record ? "Battle report updated." : needsReview ? "Battle report submitted for review." : "Battle added to the log." });
  }
  async function review(action, record, equipment) {
    setReviewing(true);
    setFeedback(null);
    try {
      const response = await request(`/map-requests/${action}`, { requestId: record.id, expectedRevision: record.revision, equipment });
      updateRecord(response.request);
      if (response.request.status === "accepted") updateQuery({ view: "", battle: record.id });
      else if (action !== "confirm") updateQuery({ battle: "" });
      setFeedback({ text: {
        accept: "Battle approved and added to the log.",
        confirm: response.request.status === "accepted" ? "All participants confirmed. Battle added to the log." : response.message,
        deny: "Battle denied.",
        "cancel-own": "Battle report canceled."
      }[action] });
    } catch (error) {
      setFeedback({ text: error.message, error: true });
    } finally {
      setReviewing(false);
    }
  }
  return /* @__PURE__ */ jsx7("main", { style: styles3.page, children: /* @__PURE__ */ jsxs7("div", { style: { ...styles3.layout, maxWidth: settings ? styles3.layout.maxWidth : "1200px" }, children: [
    /* @__PURE__ */ jsxs7("header", { style: { ...styles3.row, justifyContent: "space-between" }, children: [
      /* @__PURE__ */ jsx7(Link4, { to: "/projects/Expedition", style: styles3.link, children: "\u2190 Expedition" }),
      data?.access.canReview && /* @__PURE__ */ jsx7(Link4, { to: { pathname: `${battlePath}/settings`, search }, "aria-current": settings ? "page" : void 0, style: settings ? activeNavButton : navButton, children: "Settings" })
    ] }),
    /* @__PURE__ */ jsx7("h1", { style: styles3.heading, children: "Battles" }),
    settings ? /* @__PURE__ */ jsx7("div", { children: /* @__PURE__ */ jsx7(Link4, { to: { pathname: battlePath, search }, style: navButton, children: "\u2190 Battles" }) }) : data && (data.access.canLog || data.access.pendingBattles.length > 0) && /* @__PURE__ */ jsxs7("nav", { "aria-label": "Battle views", style: styles3.row, children: [
      /* @__PURE__ */ jsx7(
        Link4,
        {
          to: { pathname: battlePath, search: `?${battleQuery(query, { view: "", battle: "" })}` },
          style: pendingView ? navButton : activeNavButton,
          "aria-current": pendingView ? void 0 : "page",
          children: "Battle Log"
        }
      ),
      /* @__PURE__ */ jsxs7(
        Link4,
        {
          to: { pathname: battlePath, search: `?${battleQuery(query, { view: "review", battle: "" })}` },
          style: pendingView ? activeNavButton : navButton,
          "aria-current": pendingView ? "page" : void 0,
          children: [
            "Pending Reviews (",
            data.access.pendingBattles.length,
            ")"
          ]
        }
      )
    ] }),
    loadError ? /* @__PURE__ */ jsxs7("div", { style: styles3.card, children: [
      /* @__PURE__ */ jsx7("p", { role: "alert", style: styles3.error, children: loadError }),
      /* @__PURE__ */ jsx7("div", { children: /* @__PURE__ */ jsx7("button", { type: "button", onClick: () => setReload((value) => value + 1), style: styles3.button, children: "Retry" }) })
    ] }) : !data ? /* @__PURE__ */ jsx7("p", { role: "status", style: styles3.note, children: "Loading battles\u2026" }) : settings ? data.access.canReview ? /* @__PURE__ */ jsx7(BattleSettings, { initial: data.map.pointRewards }) : /* @__PURE__ */ jsx7("p", { style: styles3.note, children: "Battle settings are available to Expedition admins and owners." }) : /* @__PURE__ */ jsxs7("div", { style: styles3.log, children: [
      /* @__PURE__ */ jsx7(
        BattleLog,
        {
          pending: pendingView,
          records,
          teams: data.access.teams,
          query,
          updateQuery,
          selectedId,
          onSelect: () => {
            setEditor(null);
            setFeedback(null);
          },
          onRefresh: () => setReload((value) => value + 1)
        }
      ),
      /* @__PURE__ */ jsxs7("section", { "aria-label": "Battle report", style: { ...styles3.stack, ...styles3.report }, children: [
        data.access.canLog && /* @__PURE__ */ jsx7("div", { children: /* @__PURE__ */ jsx7(
          "button",
          {
            type: "button",
            onClick: () => {
              setFeedback(null);
              setEditor({ selectedId, record: null });
            },
            style: styles3.button,
            children: "Log a battle"
          }
        ) }),
        feedback && /* @__PURE__ */ jsx7("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles3.error : styles3.note, children: feedback.text }),
        activeEditor ? /* @__PURE__ */ jsx7(
          BattleForm,
          {
            data,
            record: activeEditor.record,
            onSave: saveBattle,
            onClose: () => setEditor(null)
          },
          activeEditor.record?.id || "new"
        ) : selectedBattle ? /* @__PURE__ */ jsx7(
          BattleRecord,
          {
            record: selectedBattle,
            access: data.access,
            reviewing,
            onEdit: () => setEditor({ selectedId, record: selectedBattle }),
            onReview: (action, equipment) => review(action, selectedBattle, equipment)
          },
          `${selectedBattle.id}:${selectedBattle.revision}`
        ) : /* @__PURE__ */ jsx7("p", { style: { ...styles3.card, margin: 0 }, children: selectedId ? "This battle report is unavailable." : "Select a battle to view its report." })
      ] })
    ] })
  ] }) });
}

// Expedition/ExpeditionLore.jsx
import { useEffect as useEffect6, useRef as useRef4, useState as useState6 } from "react";
import { Link as Link5, useSearchParams as useSearchParams5 } from "react-router-dom";
import { Fragment as Fragment5, jsx as jsx8, jsxs as jsxs8 } from "react/jsx-runtime";
var lorePath = "/projects/ExpeditionLore";
var teamLabel3 = (team) => `${team[0].toUpperCase()}${team.slice(1)} Team`;
var groupLabel = (post) => post.teamName || teamLabel3(post.team);
var tileLabel = (tile) => `Tile ${tile.id}${tile.locationNumber ? ` \xB7 Location ${tile.locationNumber}` : ""}`;
async function requestLore(options) {
  const { response, payload } = await fetchJson("/expedition/lore", options);
  if (!response.ok) throw new Error(payload.message || "Unable to load or save Expedition lore.");
  return payload;
}
function LoreLog({ posts, query, updateQuery, onSelect, onRefresh }) {
  const dialog = useRef4(null);
  const search = query.get("q") || "";
  const byName = query.get("sort") === "name";
  const ascending = query.get("order") === "asc";
  const team = query.get("team") || "";
  const round = query.get("round") || "";
  const filterCount = Number(Boolean(team)) + Number(Boolean(round));
  const rounds = [...new Set(posts.map((post) => post.round))].sort((first, second) => second - first);
  const teams2 = new Map(posts.map((post) => [post.team, groupLabel(post)]));
  const terms = search.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const visible = posts.filter((post) => {
    const searchable = [post.title, post.text, groupLabel(post), teamLabel3(post.team), post.author].join(" ").toLowerCase();
    return (!team || post.team === team) && (!round || String(post.round) === round) && terms.every((term) => searchable.includes(term));
  }).sort((first, second) => {
    const byTitle = first.title.localeCompare(second.title, void 0, { sensitivity: "base", numeric: true });
    const byRound = first.round - second.round || first.createdAt.localeCompare(second.createdAt);
    return (ascending ? 1 : -1) * (byName ? byTitle || byRound : byRound || byTitle);
  });
  const directionLabel = `Switch to ${ascending ? "descending" : "ascending"} order`;
  const sortLabel = `Sort by ${byName ? "round" : "title"}`;
  const filterLabel = filterCount ? `Filter lore (${filterCount} active)` : "Filter lore";
  return /* @__PURE__ */ jsxs8("aside", { "aria-label": "Lore log", style: { ...styles3.card, ...styles3.sidebar }, children: [
    /* @__PURE__ */ jsx8("h2", { style: styles3.subheading, children: "Lore Log" }),
    /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
      "Search lore",
      /* @__PURE__ */ jsx8("input", { type: "search", value: search, onChange: (event) => updateQuery({ q: event.target.value }), style: styles3.field })
    ] }),
    /* @__PURE__ */ jsxs8("div", { role: "group", "aria-label": "Lore log controls", style: { ...styles3.row, flexWrap: "nowrap", gap: "8px" }, children: [
      /* @__PURE__ */ jsx8(
        "button",
        {
          type: "button",
          style: sortButton,
          "aria-label": directionLabel,
          title: directionLabel,
          onClick: () => updateQuery({ order: ascending ? "" : "asc" }),
          children: /* @__PURE__ */ jsx8("span", { "aria-hidden": "true", children: ascending ? "\u2191" : "\u2193" })
        }
      ),
      /* @__PURE__ */ jsx8(
        "button",
        {
          type: "button",
          style: sortButton,
          "aria-label": sortLabel,
          title: sortLabel,
          onClick: () => updateQuery({ sort: byName ? "" : "name" }),
          children: byName ? /* @__PURE__ */ jsx8("span", { "aria-hidden": "true", children: "A" }) : /* @__PURE__ */ jsx8("span", { "aria-hidden": "true", style: clockFace, children: /* @__PURE__ */ jsx8("span", { style: clockHands }) })
        }
      ),
      /* @__PURE__ */ jsxs8(
        "button",
        {
          type: "button",
          style: { ...sortButton, position: "relative" },
          "aria-haspopup": "dialog",
          "aria-controls": "lore-filters",
          "aria-label": filterLabel,
          title: filterLabel,
          onClick: () => dialog.current.showModal(),
          children: [
            /* @__PURE__ */ jsx8("span", { "aria-hidden": "true", style: filterIcon }),
            filterCount > 0 && /* @__PURE__ */ jsx8("span", { "aria-hidden": "true", style: filterBadge, children: filterCount })
          ]
        }
      ),
      /* @__PURE__ */ jsx8("button", { type: "button", style: sortButton, "aria-label": "Refresh lore log", title: "Refresh lore log", onClick: onRefresh, children: /* @__PURE__ */ jsx8("span", { "aria-hidden": "true", children: "\u21BB" }) })
    ] }),
    /* @__PURE__ */ jsx8("dialog", { ref: dialog, id: "lore-filters", style: styles3.filterDialog, "aria-labelledby": "lore-filter-title", children: /* @__PURE__ */ jsxs8("div", { style: styles3.stack, children: [
      /* @__PURE__ */ jsx8("h2", { id: "lore-filter-title", style: styles3.subheading, children: "Filter lore" }),
      /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
        "Team",
        /* @__PURE__ */ jsxs8("select", { style: styles3.field, value: team, onChange: (event) => updateQuery({ team: event.target.value }), children: [
          /* @__PURE__ */ jsx8("option", { value: "", children: "All teams" }),
          [...teams2].map(([key, label]) => /* @__PURE__ */ jsx8("option", { value: key, children: label }, key))
        ] })
      ] }),
      /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
        "Round",
        /* @__PURE__ */ jsxs8("select", { style: styles3.field, value: round, onChange: (event) => updateQuery({ round: event.target.value }), children: [
          /* @__PURE__ */ jsx8("option", { value: "", children: "All rounds" }),
          rounds.map((value) => /* @__PURE__ */ jsxs8("option", { value, children: [
            "Round ",
            value
          ] }, value))
        ] })
      ] }),
      /* @__PURE__ */ jsxs8("div", { style: { ...styles3.row, justifyContent: "flex-end" }, children: [
        /* @__PURE__ */ jsx8("button", { type: "button", style: styles3.button, disabled: !filterCount, onClick: () => updateQuery({ team: "", round: "" }), children: "Clear filters" }),
        /* @__PURE__ */ jsx8("button", { type: "button", style: styles3.button, onClick: () => dialog.current.close(), children: "Done" })
      ] })
    ] }) }),
    visible.length > 0 ? /* @__PURE__ */ jsx8("nav", { "aria-label": "Lore posts", style: styles3.reportList, children: /* @__PURE__ */ jsx8("ul", { style: styles3.entries, children: visible.map((post) => {
      const next = new URLSearchParams(query);
      next.set("post", post.id);
      const selected = query.get("post") === post.id;
      const color = teamMarkerColors[post.team] ?? "#888";
      return /* @__PURE__ */ jsx8("li", { children: /* @__PURE__ */ jsxs8(
        Link5,
        {
          to: `${lorePath}?${next}`,
          onClick: onSelect,
          "aria-current": selected ? "true" : void 0,
          style: {
            ...styles3.entry,
            borderColor: selected ? "#eee" : "#666",
            background: `linear-gradient(#161616cc, #161616cc), ${color}`
          },
          children: [
            /* @__PURE__ */ jsx8("span", { "aria-hidden": "true", style: { height: "4px", borderRadius: "3px", background: color, boxShadow: "0 0 0 1px #ffffff40" } }),
            /* @__PURE__ */ jsx8("strong", { children: post.title }),
            /* @__PURE__ */ jsxs8("span", { style: styles3.note, children: [
              "Round ",
              post.round,
              " \xB7 ",
              groupLabel(post)
            ] })
          ]
        }
      ) }, post.id);
    }) }) }) : /* @__PURE__ */ jsx8("p", { style: styles3.note, children: posts.length ? "No lore matches your search or filters." : "No lore has been posted yet." })
  ] });
}
function LoreForm({ data, onSave, onCancel }) {
  const [saving, setSaving] = useState6(false);
  const [error, setError] = useState6("");
  const [manualRound, setManualRound] = useState6(String(data.round));
  const [manualTile, setManualTile] = useState6("");
  const [battleId, setBattleId] = useState6("");
  const battle = data.battles.find((entry) => entry.id === battleId);
  const linkedRound = battle?.round;
  const linkedTile = battle?.tileId;
  async function submit(event) {
    event.preventDefault();
    const draft = Object.fromEntries(new FormData(event.currentTarget).entries());
    setSaving(true);
    setError("");
    try {
      await onSave({ ...draft, round: Number(draft.round) });
    } catch (failure) {
      setError(failure.message);
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs8("form", { style: styles3.card, onSubmit: submit, children: [
    /* @__PURE__ */ jsx8("h2", { style: styles3.subheading, children: "Write lore" }),
    /* @__PURE__ */ jsxs8("div", { style: styles3.fields, children: [
      /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
        "Title",
        /* @__PURE__ */ jsx8("input", { style: styles3.field, name: "title", maxLength: 120, required: true, disabled: saving })
      ] }),
      /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
        "Round",
        /* @__PURE__ */ jsx8(
          "input",
          {
            style: styles3.field,
            name: "round",
            type: "number",
            min: 1,
            max: Math.max(data.round, linkedRound ?? 0),
            value: linkedRound ?? manualRound,
            readOnly: linkedRound != null,
            onChange: (event) => setManualRound(event.target.value),
            required: true,
            disabled: saving
          }
        ),
        linkedRound != null && /* @__PURE__ */ jsx8("span", { style: styles3.note, children: "Uses the linked battle\u2019s round." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs8("div", { style: styles3.fields, children: [
      /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
        "Map tile (optional)",
        /* @__PURE__ */ jsx8(
          "input",
          {
            type: "text",
            style: styles3.field,
            name: "tileId",
            placeholder: "e.g. 9-20",
            disabled: saving,
            value: linkedTile ?? manualTile,
            readOnly: linkedTile != null,
            onChange: (event) => setManualTile(event.target.value)
          }
        ),
        linkedTile != null && /* @__PURE__ */ jsx8("span", { style: styles3.note, children: "Uses the linked battle\u2019s tile." })
      ] }),
      /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
        "Battle (optional)",
        /* @__PURE__ */ jsxs8(
          "select",
          {
            style: styles3.field,
            name: "battleId",
            value: battleId,
            onChange: (event) => setBattleId(event.target.value),
            disabled: saving || !data.battles.length,
            children: [
              /* @__PURE__ */ jsx8("option", { value: "", children: data.battles.length ? "No battle" : "No eligible battles" }),
              data.battles.map((battle2) => /* @__PURE__ */ jsx8("option", { value: battle2.id, children: [battle2.name, battle2.type, battle2.round != null && `Round ${battle2.round}`, battle2.date].filter(Boolean).join(" \xB7 ") }, battle2.id))
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs8("label", { style: styles3.label, children: [
      "Lore",
      /* @__PURE__ */ jsx8("textarea", { style: { ...styles3.field, resize: "vertical" }, name: "text", rows: 8, maxLength: 12e3, required: true, disabled: saving })
    ] }),
    error && /* @__PURE__ */ jsx8("p", { role: "alert", style: styles3.error, children: error }),
    /* @__PURE__ */ jsxs8("div", { style: styles3.row, children: [
      /* @__PURE__ */ jsx8("button", { type: "submit", style: styles3.button, disabled: saving, children: saving ? "Publishing\u2026" : "Publish lore" }),
      /* @__PURE__ */ jsx8("button", { type: "button", style: styles3.button, disabled: saving, onClick: onCancel, children: "Cancel" })
    ] })
  ] });
}
function LorePost({ post, tiles }) {
  const tile = tiles.find((entry) => entry.id === post.tileId);
  return /* @__PURE__ */ jsxs8("article", { style: styles3.card, children: [
    /* @__PURE__ */ jsx8("h2", { style: { ...styles3.subheading, overflowWrap: "anywhere" }, children: post.title }),
    /* @__PURE__ */ jsxs8("p", { style: styles3.note, children: [
      "Round ",
      post.round,
      " \xB7 ",
      groupLabel(post),
      " \xB7 Posted by ",
      post.author
    ] }),
    (post.tileId || post.hasBattle) && /* @__PURE__ */ jsxs8("div", { style: styles3.row, children: [
      tile ? /* @__PURE__ */ jsx8(Link5, { to: `/projects/ExpeditionMap?${new URLSearchParams({ tile: tile.id })}`, style: styles3.link, children: tileLabel(tile) }) : post.tileId && /* @__PURE__ */ jsxs8("span", { style: styles3.note, children: [
        "Tile ",
        post.tileId,
        " (unavailable)"
      ] }),
      post.battle ? /* @__PURE__ */ jsx8(Link5, { to: `/projects/ExpeditionBattles?${new URLSearchParams({ battle: post.battle.id })}`, style: styles3.link, children: post.battle.name }) : post.hasBattle && /* @__PURE__ */ jsx8("span", { style: styles3.note, children: "Linked battle unavailable" })
    ] }),
    /* @__PURE__ */ jsx8("p", { style: styles3.prose, children: post.text })
  ] });
}
function ExpeditionLore() {
  const [query, setQuery] = useSearchParams5();
  const [data, setData] = useState6(null);
  const [loadError, setLoadError] = useState6("");
  const [reload, setReload] = useState6(0);
  const [editor, setEditor] = useState6(null);
  const selectedId = query.get("post");
  const selected = data?.posts.find((post) => post.id === selectedId);
  const refresh = () => setReload((value) => value + 1);
  useEffect6(() => {
    const event = getAuthEventName();
    window.addEventListener(event, refresh);
    return () => window.removeEventListener(event, refresh);
  }, []);
  useEffect6(() => {
    const controller = new AbortController();
    setData(null);
    setLoadError("");
    setEditor(null);
    requestLore({ method: "GET", signal: controller.signal }).then(
      (payload) => {
        if (!controller.signal.aborted) setData(payload);
      },
      (failure) => {
        if (!controller.signal.aborted) setLoadError(failure.message);
      }
    );
    return () => controller.abort();
  }, [reload]);
  function updateQuery(changes, replace = true) {
    setQuery((current) => {
      const next = new URLSearchParams(current);
      for (const [key, value] of Object.entries(changes)) {
        if (value) next.set(key, value);
        else next.delete(key);
      }
      return next;
    }, { replace });
  }
  async function save(draft) {
    const { post } = await requestLore({ method: "POST", body: JSON.stringify(draft) });
    setData((current) => current && { ...current, posts: [post, ...current.posts] });
    setEditor(null);
    updateQuery({ post: post.id, q: "", round: "", team: "" }, false);
  }
  return /* @__PURE__ */ jsx8("main", { style: styles3.page, children: /* @__PURE__ */ jsxs8("div", { style: { ...styles3.layout, maxWidth: "1200px" }, children: [
    /* @__PURE__ */ jsx8("header", { style: styles3.row, children: /* @__PURE__ */ jsx8(Link5, { to: "/projects/Expedition", style: styles3.link, children: "\u2190 Expedition" }) }),
    /* @__PURE__ */ jsx8("h1", { style: styles3.heading, children: "Lore" }),
    loadError ? /* @__PURE__ */ jsxs8("div", { style: styles3.card, children: [
      /* @__PURE__ */ jsx8("p", { role: "alert", style: styles3.error, children: loadError }),
      /* @__PURE__ */ jsx8("div", { children: /* @__PURE__ */ jsx8("button", { type: "button", style: styles3.button, onClick: refresh, children: "Retry" }) })
    ] }) : !data ? /* @__PURE__ */ jsx8("p", { role: "status", style: styles3.note, children: "Loading lore\u2026" }) : /* @__PURE__ */ jsxs8("div", { style: styles3.log, children: [
      /* @__PURE__ */ jsx8(LoreLog, { posts: data.posts, query, updateQuery, onSelect: () => setEditor(null), onRefresh: refresh }),
      /* @__PURE__ */ jsx8("section", { "aria-label": "Lore post", style: { ...styles3.stack, ...styles3.report }, children: data.canPost && editor?.selectedId === selectedId ? /* @__PURE__ */ jsx8(LoreForm, { data, onSave: save, onCancel: () => setEditor(null) }) : /* @__PURE__ */ jsxs8(Fragment5, { children: [
        data.canPost && /* @__PURE__ */ jsx8("div", { children: /* @__PURE__ */ jsx8("button", { type: "button", style: styles3.button, onClick: () => setEditor({ selectedId }), children: "Write lore" }) }),
        selected ? /* @__PURE__ */ jsx8(LorePost, { post: selected, tiles: data.tiles }) : /* @__PURE__ */ jsx8("p", { style: { ...styles3.card, ...styles3.note }, children: selectedId ? "This lore post is unavailable." : "Select a lore post to read it." })
      ] }) })
    ] })
  ] }) });
}

// Expedition/ExpeditionShop.jsx
import { useEffect as useEffect7, useState as useState7 } from "react";
import { Link as Link6 } from "react-router-dom";
import { jsx as jsx9, jsxs as jsxs9 } from "react/jsx-runtime";
var styles6 = {
  page: { minHeight: "100%", padding: "clamp(16px, 4vw, 40px)", background: "#1e1e1e", color: "#fff", fontFamily: "system-ui, sans-serif" },
  layout: { display: "grid", gap: "18px", width: "100%", maxWidth: "900px", margin: "0 auto" },
  link: { color: "#eee", textUnderlineOffset: "4px", justifySelf: "start" },
  title: { margin: 0, color: "inherit", font: "700 1.8rem system-ui, sans-serif" },
  heading: { margin: 0, fontSize: "1.1rem" },
  stack: { display: "grid", gap: "12px" },
  card: { display: "grid", gap: "12px", minWidth: 0, padding: "16px", background: "#272727", border: "1px solid #4a4a4a", borderRadius: "8px", overflowWrap: "anywhere" },
  row: { display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "10px" },
  formFields: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(200px, 100%), 1fr))", gap: "12px" },
  fieldset: { display: "grid", gap: "12px", minWidth: 0, margin: 0, padding: 0, border: 0 },
  label: { display: "grid", gap: "5px", alignContent: "start", fontSize: "0.875rem" },
  checkbox: { display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem" },
  field: { width: "100%", minWidth: 0, boxSizing: "border-box", color: "#fff", background: "#191919", border: "1px solid #666", borderRadius: "6px", font: "inherit", padding: "8px 10px" },
  button: { color: "#fff", background: "#353535", border: "1px solid #666", borderRadius: "6px", font: "inherit", padding: "8px 12px", justifySelf: "start" },
  note: { color: "#ddd", margin: 0 },
  error: { color: "#ffb5a7", margin: 0 }
};
async function shopRequest(path, method, body, signal) {
  const { response, payload } = await fetchJson(`/expedition/shop${path}`, {
    method,
    ...body && { body: JSON.stringify(body) },
    signal
  });
  if (!response.ok) {
    const error = new Error(payload?.message || "Unable to complete the shop request.");
    if (Array.isArray(payload?.items)) error.catalog = payload;
    throw error;
  }
  return payload;
}
function ShopListingForm({ busy, onCreate }) {
  function submit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const fields = new FormData(form);
    onCreate({
      name: fields.get("name").trim(),
      description: fields.get("description").trim(),
      action: fields.get("action").trim(),
      cost: form.elements.namedItem("cost").valueAsNumber
    }, () => form.reset());
  }
  return /* @__PURE__ */ jsxs9("form", { "aria-labelledby": "expedition-shop-add", onSubmit: submit, style: styles6.card, children: [
    /* @__PURE__ */ jsx9("h3", { id: "expedition-shop-add", style: styles6.heading, children: "Add Equipment" }),
    /* @__PURE__ */ jsxs9("fieldset", { disabled: busy, style: styles6.fieldset, children: [
      /* @__PURE__ */ jsxs9("div", { style: styles6.formFields, children: [
        /* @__PURE__ */ jsxs9("label", { style: styles6.label, children: [
          "Name",
          /* @__PURE__ */ jsx9("input", { name: "name", maxLength: 100, required: true, style: styles6.field })
        ] }),
        /* @__PURE__ */ jsxs9("label", { style: styles6.label, children: [
          "Cost in credits",
          /* @__PURE__ */ jsx9("input", { name: "cost", type: "number", min: "0", max: Number.MAX_SAFE_INTEGER, step: "1", required: true, style: styles6.field })
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("label", { style: styles6.label, children: [
        "Ability",
        /* @__PURE__ */ jsx9("textarea", { name: "description", rows: 3, maxLength: 2e3, required: true, style: styles6.field })
      ] }),
      /* @__PURE__ */ jsxs9("label", { style: styles6.label, children: [
        "Action (optional)",
        /* @__PURE__ */ jsx9("textarea", { name: "action", rows: 2, maxLength: factionEquipmentLimits.description, style: styles6.field })
      ] }),
      /* @__PURE__ */ jsx9("button", { type: "submit", style: styles6.button, children: "Add to Backrooms" })
    ] })
  ] });
}
function StockLimit({ label, name, initial }) {
  const [unlimited, setUnlimited] = useState7(initial === null);
  return /* @__PURE__ */ jsxs9("div", { style: styles6.stack, children: [
    /* @__PURE__ */ jsxs9("label", { style: styles6.label, children: [
      label,
      /* @__PURE__ */ jsx9(
        "input",
        {
          name,
          type: "number",
          min: "1",
          max: Number.MAX_SAFE_INTEGER,
          step: "1",
          defaultValue: Math.max(1, initial ?? 1),
          disabled: unlimited,
          required: true,
          style: styles6.field
        }
      )
    ] }),
    /* @__PURE__ */ jsxs9("label", { style: styles6.checkbox, children: [
      /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: unlimited, onChange: (event) => setUnlimited(event.target.checked) }),
      " Unlimited ",
      label.toLowerCase()
    ] })
  ] });
}
function StockForm({ item: item2, busy, onStock, onCancel }) {
  function submit(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const limit = (name) => data.has(name) ? Number(data.get(name)) : null;
    onStock({ perUser: limit("perUser"), total: limit("total") });
  }
  return /* @__PURE__ */ jsx9("form", { onSubmit: submit, style: styles6.card, "aria-label": `Stock ${item2.name}`, children: /* @__PURE__ */ jsxs9("fieldset", { disabled: busy, style: styles6.fieldset, children: [
    /* @__PURE__ */ jsxs9("div", { style: styles6.formFields, children: [
      /* @__PURE__ */ jsx9(StockLimit, { label: "Amount per user", name: "perUser", initial: item2.perUser }),
      /* @__PURE__ */ jsx9(StockLimit, { label: "Total amount", name: "total", initial: item2.remaining })
    ] }),
    /* @__PURE__ */ jsx9("p", { style: styles6.note, children: "Amount per user limits how many copies each player can buy. Total amount sets the stock currently available." }),
    /* @__PURE__ */ jsxs9("div", { style: styles6.row, children: [
      /* @__PURE__ */ jsx9("button", { type: "submit", style: styles6.button, children: "Save stock" }),
      /* @__PURE__ */ jsx9("button", { type: "button", style: styles6.button, onClick: onCancel, children: "Cancel" })
    ] })
  ] }) });
}
function ShopListing({ item: item2, children }) {
  return /* @__PURE__ */ jsxs9("article", { style: styles6.card, children: [
    /* @__PURE__ */ jsxs9("div", { style: styles6.row, children: [
      /* @__PURE__ */ jsx9("h3", { style: styles6.heading, children: item2.name }),
      /* @__PURE__ */ jsxs9("strong", { children: [
        item2.cost.toLocaleString(),
        " ",
        item2.cost === 1 ? "credit" : "credits"
      ] })
    ] }),
    /* @__PURE__ */ jsx9(EquipmentRules, { equipment: item2, showEmptyAbility: true }),
    children
  ] });
}
function PurchaseForm({ item: item2, credits, busy, onPurchase }) {
  const cap = item2.perUser === null ? Infinity : item2.perUser - item2.owned;
  const affordable = item2.cost === 0 ? Infinity : Math.floor(credits / item2.cost);
  const max = Math.min(Number.MAX_SAFE_INTEGER, item2.remaining ?? Infinity, cap, affordable);
  if (item2.remaining === 0) return null;
  if (cap <= 0) return /* @__PURE__ */ jsx9("p", { style: styles6.note, children: "You\u2019ve reached the purchase limit for this item." });
  if (affordable === 0) return /* @__PURE__ */ jsx9("p", { style: styles6.note, children: "Your team does not have enough credits." });
  function submit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const quantity = form.elements.namedItem("quantity")?.valueAsNumber ?? 1;
    onPurchase(quantity, () => form.reset());
  }
  return /* @__PURE__ */ jsxs9("form", { onSubmit: submit, style: { ...styles6.row, justifyContent: "start", alignItems: "end" }, children: [
    max > 1 && /* @__PURE__ */ jsxs9("label", { style: styles6.label, children: [
      "Quantity",
      /* @__PURE__ */ jsx9(
        "input",
        {
          name: "quantity",
          type: "number",
          min: "1",
          max,
          step: "1",
          defaultValue: "1",
          required: true,
          disabled: busy,
          style: { ...styles6.field, width: "105px" }
        }
      )
    ] }),
    /* @__PURE__ */ jsx9("button", { type: "submit", disabled: busy, style: styles6.button, "aria-label": `Buy ${item2.name}`, children: "Buy" })
  ] });
}
function ExpeditionShop() {
  const [authRevision, setAuthRevision] = useState7(0);
  useEffect7(() => {
    const event = getAuthEventName();
    const refresh = () => setAuthRevision((value) => value + 1);
    window.addEventListener(event, refresh);
    return () => window.removeEventListener(event, refresh);
  }, []);
  return /* @__PURE__ */ jsx9(ShopPage, {}, authRevision);
}
function ShopPage() {
  const [catalog, setCatalog] = useState7(null);
  const [loadError, setLoadError] = useState7("");
  const [reload, setReload] = useState7(0);
  const [busy, setBusy] = useState7(false);
  const [feedback, setFeedback] = useState7(null);
  const [search, setSearch] = useState7("");
  const [stockId, setStockId] = useState7(null);
  useEffect7(() => {
    const controller = new AbortController();
    const { signal } = controller;
    shopRequest("", "GET", void 0, signal).then((payload) => {
      if (!Array.isArray(payload?.items)) throw new Error("Unable to load the shop.");
      if (!signal.aborted) setCatalog(payload);
    }).catch((error) => {
      if (!signal.aborted) setLoadError(error.message);
    });
    return () => controller.abort();
  }, [reload]);
  async function saveListing(path, method, body, onSaved) {
    if (busy) return;
    setBusy(true);
    setFeedback(null);
    try {
      const result = await shopRequest(path, method, body);
      setCatalog(result);
      onSaved?.();
      setFeedback({ message: result.message });
    } catch (error) {
      if (error.catalog) setCatalog(error.catalog);
      setFeedback({ error: true, message: error.message });
    } finally {
      setBusy(false);
    }
  }
  const storefront = catalog?.items.filter((item2) => item2.visible) ?? [];
  const query = search.trim().toLowerCase();
  const backrooms = catalog?.items.filter((item2) => [item2.name, item2.description, item2.action].some((value) => value?.toLowerCase().includes(query))) ?? [];
  function removeFromStorefront(item2) {
    if (window.confirm(`Remove "${item2.name}" from Storefront? It will remain in Backrooms.`)) {
      saveListing("", "PATCH", { id: item2.id, visible: false });
    }
  }
  return /* @__PURE__ */ jsx9("main", { style: styles6.page, children: /* @__PURE__ */ jsxs9("div", { style: styles6.layout, children: [
    /* @__PURE__ */ jsx9(Link6, { to: "/projects/Expedition", style: styles6.link, children: "\u2190 Back to Expedition" }),
    /* @__PURE__ */ jsx9("h1", { style: styles6.title, children: "Expedition Shop" }),
    loadError && /* @__PURE__ */ jsxs9("div", { style: styles6.card, children: [
      /* @__PURE__ */ jsx9("p", { role: "alert", style: styles6.error, children: loadError }),
      /* @__PURE__ */ jsx9("button", { type: "button", style: styles6.button, onClick: () => {
        setLoadError("");
        setReload((value) => value + 1);
      }, children: "Retry" })
    ] }),
    !loadError && !catalog && /* @__PURE__ */ jsx9("p", { role: "status", style: styles6.note, children: "Loading the shop\u2026" }),
    feedback && /* @__PURE__ */ jsx9("p", { role: feedback.error ? "alert" : "status", style: feedback.error ? styles6.error : styles6.note, children: feedback.message }),
    catalog && /* @__PURE__ */ jsxs9("section", { "aria-labelledby": "expedition-storefront", style: styles6.stack, children: [
      /* @__PURE__ */ jsxs9("div", { style: styles6.row, children: [
        /* @__PURE__ */ jsx9("h2", { id: "expedition-storefront", style: styles6.heading, children: "Storefront" }),
        catalog.canPurchase && /* @__PURE__ */ jsxs9("span", { style: styles6.note, children: [
          catalog.credits.toLocaleString(),
          " team credits \xB7 ",
          /* @__PURE__ */ jsx9(Link6, { to: "/projects/ExpeditionTeams", style: styles6.link, children: "Team Equipment" })
        ] })
      ] }),
      storefront.length === 0 && /* @__PURE__ */ jsx9("p", { style: styles6.note, children: "No equipment is stocked in Storefront." }),
      storefront.map((item2) => /* @__PURE__ */ jsxs9(ShopListing, { item: item2, children: [
        /* @__PURE__ */ jsxs9("p", { style: styles6.note, children: [
          item2.remaining === 0 ? "Sold out" : item2.remaining === null ? "Unlimited stock" : `${item2.remaining.toLocaleString()} in stock`,
          " \xB7 ",
          item2.perUser === null ? "Unlimited per user" : `${item2.perUser.toLocaleString()} per user`
        ] }),
        catalog.canPurchase && /* @__PURE__ */ jsx9(
          PurchaseForm,
          {
            item: item2,
            credits: catalog.credits,
            busy,
            onPurchase: (quantity, onSaved) => saveListing("/purchase", "POST", { id: item2.id, quantity }, onSaved)
          }
        ),
        catalog.canManage && /* @__PURE__ */ jsx9(
          "button",
          {
            type: "button",
            style: styles6.button,
            disabled: busy,
            "aria-label": `Remove ${item2.name} from Storefront`,
            onClick: () => removeFromStorefront(item2),
            children: "Remove from Storefront"
          }
        )
      ] }, item2.id))
    ] }),
    catalog?.canManage && /* @__PURE__ */ jsxs9("section", { "aria-labelledby": "expedition-backrooms", style: styles6.stack, children: [
      /* @__PURE__ */ jsx9("h2", { id: "expedition-backrooms", style: styles6.heading, children: "Backrooms" }),
      /* @__PURE__ */ jsxs9("label", { style: styles6.label, children: [
        "Search Backrooms",
        /* @__PURE__ */ jsx9("input", { type: "search", value: search, onChange: (event) => setSearch(event.target.value), style: styles6.field })
      ] }),
      backrooms.length === 0 && /* @__PURE__ */ jsx9("p", { style: styles6.note, children: query ? "No matching equipment." : "No equipment in Backrooms yet." }),
      backrooms.map((item2) => /* @__PURE__ */ jsxs9(ShopListing, { item: item2, children: [
        /* @__PURE__ */ jsxs9("div", { style: styles6.row, children: [
          /* @__PURE__ */ jsx9("span", { style: styles6.note, children: item2.visible ? "On Storefront" : "In Backrooms only" }),
          /* @__PURE__ */ jsx9(
            "button",
            {
              type: "button",
              style: styles6.button,
              disabled: busy,
              "aria-label": `Stock ${item2.name}`,
              "aria-expanded": stockId === item2.id,
              onClick: () => setStockId((current) => current === item2.id ? null : item2.id),
              children: "Stock"
            }
          )
        ] }),
        stockId === item2.id && /* @__PURE__ */ jsx9(
          StockForm,
          {
            item: item2,
            busy,
            onCancel: () => setStockId(null),
            onStock: (stock) => saveListing("", "PATCH", { id: item2.id, stock }, () => setStockId(null))
          }
        )
      ] }, item2.id)),
      /* @__PURE__ */ jsx9(ShopListingForm, { busy, onCreate: (body, onSaved) => saveListing("", "POST", body, onSaved) })
    ] })
  ] }) });
}

// preview/GameCompendium.jsx
import { useEffect as useEffect8, useRef as useRef5, useState as useState8 } from "react";
import { Link as Link7 } from "react-router-dom";

// node_modules/compendium/src/index.js
var pageTypes = /* @__PURE__ */ new Set(["normal", "grid", "table", "classes"]);
function indexById(items, label) {
  const index = /* @__PURE__ */ new Map();
  for (const item2 of items) {
    const id = item2?.id;
    if (typeof id !== "string" || !id.trim() || id !== id.trim()) {
      throw new TypeError(`${label} must have a non-empty ID without surrounding whitespace.`);
    }
    if (index.has(id)) {
      throw new TypeError(`Duplicate ${label.toLowerCase()} ID: ${id}`);
    }
    index.set(id, item2);
  }
  return index;
}
function resolvePage(page, collections, fallbackType) {
  const type = page.type ?? fallbackType;
  if (!pageTypes.has(type)) {
    throw new TypeError(`Unknown page type for "${page.id}": ${type}`);
  }
  const entries = page.collectionId === void 0 ? /* @__PURE__ */ new Map() : collections.get(page.collectionId);
  if (!entries) {
    throw new TypeError(`Unknown collection for "${page.id}": ${page.collectionId}`);
  }
  return {
    page: { ...page, type, entries: [...entries.values()] },
    entries
  };
}
function createCompendium({ tabs, collections = [] }) {
  if (!Array.isArray(tabs)) throw new TypeError("Compendium data must contain a tabs array.");
  const collectionsById = /* @__PURE__ */ new Map();
  for (const [id, collection] of indexById(collections, "Collection")) {
    collectionsById.set(id, indexById(collection.entries, `Entry in collection "${id}"`));
  }
  const tabsById = /* @__PURE__ */ new Map();
  for (const [id, tab] of indexById(tabs, "Tab")) {
    const resolved = resolvePage(tab, collectionsById, "normal");
    const sections = /* @__PURE__ */ new Map();
    for (const [sectionId, section] of indexById(tab.sections ?? [], `Section in tab "${id}"`)) {
      sections.set(sectionId, resolvePage(section, collectionsById, resolved.page.type));
    }
    resolved.page.sections = [...sections.values()].map((section) => section.page);
    tabsById.set(id, { ...resolved, sections });
  }
  return {
    tabs: [...tabsById.values()].map((tab) => tab.page),
    resolveEntry({ tabId, sectionId, entryId }) {
      const tab = tabsById.get(tabId);
      const target = sectionId === void 0 ? tab : tab?.sections.get(sectionId);
      const entry = target?.entries.get(entryId);
      if (!entry) return null;
      return { tab: tab.page, section: sectionId === void 0 ? null : target.page, entry };
    }
  };
}

// node_modules/compendium/src/browser/favorites.js
function favoriteKey({ tabId, sectionId, entryId, block }) {
  return JSON.stringify([tabId, sectionId, entryId, block?.field, block?.index]);
}
function loadFavorites(projectId) {
  const storageKey = `compendium-preview:favorites:${projectId}`;
  let entries = [];
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey) ?? "[]");
    if (Array.isArray(stored)) {
      entries = stored.filter((item2) => typeof item2?.tabId === "string" && typeof item2.entryId === "string");
    }
  } catch {
  }
  const favorites = new Map(entries.map((item2) => [favoriteKey(item2), item2]));
  function save() {
    try {
      localStorage.setItem(storageKey, JSON.stringify([...favorites.values()]));
    } catch {
    }
  }
  return {
    get size() {
      return favorites.size;
    },
    values: () => favorites.values(),
    has: (item2) => favorites.has(favoriteKey(item2)),
    toggle(item2) {
      const key = favoriteKey(item2);
      if (!favorites.delete(key)) {
        favorites.set(key, item2);
        save();
        return true;
      }
      save();
      return false;
    }
  };
}

// node_modules/compendium/src/images.js
var imageFormats = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp"
};
function isImageName(name) {
  return typeof name === "string" && /^[a-z0-9][a-z0-9._-]{0,119}\.(?:png|jpe?g|webp)$/i.test(name);
}

// node_modules/compendium/src/browser/writer-spellcheck.js
function createSpellcheckField(textarea, checkSpelling) {
  const shell = document.createElement("div");
  shell.className = "spellcheck-field";
  const editor = document.createElement("div");
  editor.className = "spellcheck-editor";
  const mirror = document.createElement("div");
  mirror.className = "spellcheck-mirror";
  mirror.setAttribute("aria-hidden", "true");
  editor.append(textarea, mirror);
  const menu = document.createElement("div");
  menu.className = "spellcheck-menu";
  menu.setAttribute("popover", "auto");
  menu.setAttribute("role", "dialog");
  menu.setAttribute("aria-label", "Spelling suggestions");
  const status = document.createElement("p");
  status.className = "spellcheck-status";
  status.setAttribute("role", "status");
  shell.append(editor, status, menu);
  textarea.spellcheck = false;
  textarea.lang = "en-US";
  let issues = [];
  let checkedText = "";
  let timer;
  let request2;
  function sync() {
    mirror.style.left = `${textarea.clientLeft}px`;
    mirror.style.top = `${textarea.clientTop}px`;
    mirror.style.width = `${textarea.clientWidth}px`;
    mirror.style.height = `${textarea.clientHeight}px`;
    mirror.scrollTop = textarea.scrollTop;
    mirror.scrollLeft = textarea.scrollLeft;
  }
  function highlight() {
    const content = document.createDocumentFragment();
    let end = 0;
    for (const [index, issue] of issues.entries()) {
      content.append(checkedText.slice(end, issue.start));
      const mark = document.createElement("mark");
      mark.dataset.spellingIssue = index;
      mark.textContent = issue.word;
      content.append(mark);
      end = issue.end;
    }
    content.append(checkedText.slice(end), "\u200B");
    mirror.replaceChildren(content);
    sync();
  }
  function closeSuggestions() {
    if (menu.matches(":popover-open")) menu.hidePopover();
  }
  function openSuggestions(issue, x, y) {
    menu.replaceChildren();
    const heading = document.createElement("strong");
    heading.textContent = issue.word;
    menu.append(heading);
    if (issue.suggestions.length) {
      for (const suggestion of issue.suggestions) {
        const button2 = document.createElement("button");
        button2.type = "button";
        button2.textContent = suggestion;
        button2.addEventListener("click", () => {
          if (textarea.value !== checkedText) return closeSuggestions();
          textarea.setRangeText(suggestion, issue.start, issue.end, "end");
          textarea.focus();
          queueCheck();
        });
        menu.append(button2);
      }
    } else {
      const empty = document.createElement("span");
      empty.textContent = "No suggestions";
      menu.append(empty);
    }
    menu.showPopover();
    menu.style.left = `${Math.max(8, Math.min(x, window.innerWidth - menu.offsetWidth - 8))}px`;
    menu.style.top = `${Math.max(8, Math.min(y, window.innerHeight - menu.offsetHeight - 8))}px`;
    menu.querySelector("button")?.focus();
  }
  function issueAtCaret() {
    return issues.find((issue) => textarea.selectionStart <= issue.end && textarea.selectionEnd >= issue.start);
  }
  function contextMenu(event) {
    if (textarea.value !== checkedText) return;
    const mark = [...mirror.querySelectorAll("mark")].find((node) => [...node.getClientRects()].some((rect2) => event.clientX >= rect2.left && event.clientX <= rect2.right && event.clientY >= rect2.top && event.clientY <= rect2.bottom));
    const issue = mark ? issues[Number(mark.dataset.spellingIssue)] : issueAtCaret();
    if (!issue) return;
    event.preventDefault();
    const rect = textarea.getBoundingClientRect();
    openSuggestions(issue, event.clientX || rect.left, event.clientY || rect.bottom);
  }
  function queueCheck() {
    clearTimeout(timer);
    request2?.abort();
    closeSuggestions();
    issues = [];
    checkedText = textarea.value;
    highlight();
    status.textContent = "";
    const text = checkedText;
    if (!text.trim()) return;
    timer = setTimeout(async () => {
      const current = new AbortController();
      request2 = current;
      try {
        const result = await checkSpelling(text, { signal: current.signal });
        if (current.signal.aborted) return;
        textarea.spellcheck = false;
        issues = result.issues;
        highlight();
      } catch (error) {
        if (current.signal.aborted) return;
        if (error.status === 400) {
          status.textContent = error.message;
          return;
        }
        textarea.spellcheck = true;
        status.textContent = "Using browser spellcheck. The compendium dictionary is unavailable.";
      }
    }, 250);
  }
  textarea.addEventListener("input", queueCheck);
  textarea.addEventListener("scroll", sync);
  textarea.addEventListener("contextmenu", contextMenu);
  const resize = new ResizeObserver(sync);
  resize.observe(textarea);
  queueCheck();
  return {
    shell,
    dispose() {
      clearTimeout(timer);
      request2?.abort();
      resize.disconnect();
      closeSuggestions();
    }
  };
}

// node_modules/compendium/src/browser/inline-format.js
var formats = [
  { label: "Bold", symbol: "B", marker: "**", tag: "strong", shortcut: "b" },
  { label: "Italic", symbol: "I", marker: "*", tag: "em", shortcut: "i" },
  { label: "Underline", symbol: "U", marker: "++", tag: "u", shortcut: "u" },
  { label: "Strikethrough", symbol: "S", marker: "~~", tag: "s" }
];
var tags = new Map(formats.map(({ marker, tag }) => [marker, tag]));
var shortcuts = new Map(formats.filter((format) => format.shortcut).map((format) => [format.shortcut, format.marker]));
function appendInline(node, text, referenceFor) {
  const lines = text.split(/\r?\n/);
  for (const [index, line] of lines.entries()) {
    if (index) node.append("\n");
    appendLine(node, line, referenceFor);
  }
  return node;
}
function appendLine(node, text, referenceFor) {
  const stack = [{ content: node }];
  const current = () => stack.at(-1);
  let offset = 0;
  function open(marker) {
    stack.push({ marker, content: node.ownerDocument.createDocumentFragment() });
  }
  function close() {
    const { marker, content } = stack.pop();
    const formatted = node.ownerDocument.createElement(tags.get(marker));
    formatted.append(content);
    current().content.append(formatted);
  }
  for (const match of text.matchAll(/\\([*+~<>\\])|<([^<>]+)>|\*+|\++|~+/g)) {
    current().content.append(text.slice(offset, match.index));
    const [token, escaped, reference] = match;
    offset = match.index + token.length;
    if (escaped) {
      current().content.append(escaped);
      continue;
    }
    if (reference) {
      current().content.append(referenceFor(reference) ?? token);
      continue;
    }
    const canOpen = offset < text.length && !/\s/.test(text[offset]);
    const canClose = match.index > 0 && !/\s/.test(text[match.index - 1]);
    if (token[0] === "*" && token.length <= 3) {
      let remaining = token.length;
      while (remaining) {
        const marker = current().marker;
        if (canClose && marker?.startsWith("*") && marker.length <= remaining) {
          remaining -= marker.length;
          close();
        } else if (canOpen) {
          const length = Math.min(2, remaining);
          open("*".repeat(length));
          remaining -= length;
        } else {
          current().content.append("*".repeat(remaining));
          break;
        }
      }
    } else if (tags.has(token)) {
      if (canClose && current().marker === token) close();
      else if (canOpen) open(token);
      else current().content.append(token);
    } else {
      current().content.append(token);
    }
  }
  current().content.append(text.slice(offset));
  while (stack.length > 1) {
    const { marker, content } = stack.pop();
    current().content.append(marker, content);
  }
}
function surrounds(value, start, end, marker) {
  const length = marker.length;
  if (value.slice(start - length, start) !== marker || value.slice(end, end + length) !== marker) return false;
  if (marker !== "*") return true;
  const left = value.slice(0, start).match(/\*+$/)?.[0].length;
  const right = value.slice(end).match(/^\*+/)?.[0].length;
  return left !== 2 && right !== 2;
}
function toggleFormatting(textarea, marker) {
  const { value } = textarea;
  let start = textarea.selectionStart;
  let end = textarea.selectionEnd;
  const selected = value.slice(start, end);
  let replacement;
  let selectionStart;
  let selectionEnd;
  if (!selected.includes("\n") && surrounds(value, start, end, marker)) {
    start -= marker.length;
    end += marker.length;
    replacement = selected;
    selectionStart = start;
    selectionEnd = start + selected.length;
  } else if (!selected.includes("\n") && selected.length > marker.length * 2 && surrounds(selected, marker.length, selected.length - marker.length, marker)) {
    replacement = selected.slice(marker.length, -marker.length);
    selectionStart = start;
    selectionEnd = start + replacement.length;
  } else if (selected.includes("\n")) {
    replacement = selected.split("\n").map((line) => {
      const [, before, text, after] = line.match(/^([ \t]*(?:#{1,3}[ \t]+)?)(.*?)([ \t]*)$/) ?? ["", "", line, ""];
      if (!text || text.startsWith("|") || text.startsWith("![")) return line;
      if (text.length > marker.length * 2 && surrounds(text, marker.length, text.length - marker.length, marker)) {
        return before + text.slice(marker.length, -marker.length) + after;
      }
      return before + marker + text + marker + after;
    }).join("\n");
    selectionStart = start;
    selectionEnd = start + replacement.length;
  } else {
    const pattern = start === 0 || value[start - 1] === "\n" ? /^([ \t]*(?:#{1,3}[ \t]+)?)(.*?)([ \t]*)$/ : /^([ \t]*)(.*?)([ \t]*)$/;
    const [, before, text, after] = selected.match(pattern) ?? ["", "", selected, ""];
    replacement = before + marker + text + marker + after;
    selectionStart = start + before.length + marker.length;
    selectionEnd = selectionStart + text.length;
  }
  textarea.setRangeText(replacement, start, end, "end");
  textarea.focus();
  textarea.setSelectionRange(selectionStart, selectionEnd);
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
}
function createFormattingControls(textarea, field) {
  const group = textarea.ownerDocument.createElement("div");
  group.className = "formatting-controls";
  group.setAttribute("role", "group");
  group.setAttribute("aria-label", `Format ${field}`);
  for (const { label, symbol, marker, tag } of formats) {
    const button2 = textarea.ownerDocument.createElement("button");
    button2.type = "button";
    button2.title = label;
    button2.setAttribute("aria-label", label);
    const text = textarea.ownerDocument.createElement(tag);
    text.textContent = symbol;
    button2.append(text);
    button2.addEventListener("click", () => toggleFormatting(textarea, marker));
    group.append(button2);
  }
  textarea.addEventListener("keydown", (event) => {
    if (!(event.ctrlKey || event.metaKey) || event.altKey || event.shiftKey) return;
    const marker = shortcuts.get(event.key.toLowerCase());
    if (!marker) return;
    event.preventDefault();
    toggleFormatting(textarea, marker);
  });
  return group;
}

// node_modules/compendium/src/browser/writer.js
function createEntryEditor(root, writer, saveTarget) {
  const form = root.querySelector("#writer-form");
  const dialog = root.querySelector("#writer-dialog");
  const fields = root.querySelector("#writer-fields");
  const status = root.querySelector("#writer-status");
  const saveButton = form.querySelector('button[type="submit"]');
  const deleteButton = root.querySelector("#writer-delete");
  let currentEdit;
  function imageUpload(textarea, reference, field) {
    const controls = document.createElement("div");
    controls.className = "image-upload";
    const picker = document.createElement("input");
    picker.type = "file";
    picker.accept = Object.keys(imageFormats).join(",");
    picker.hidden = true;
    const button2 = document.createElement("button");
    button2.type = "button";
    button2.textContent = "Upload image";
    button2.setAttribute("aria-label", `Upload image to ${field}`);
    button2.addEventListener("click", () => {
      if (!saveButton.disabled) picker.click();
    });
    picker.addEventListener("change", async () => {
      const file = picker.files[0];
      picker.value = "";
      if (!file || saveButton.disabled) return;
      const original = textarea.value;
      const position = [textarea.selectionStart, textarea.selectionEnd];
      status.textContent = "Uploading image\u2026";
      saveButton.disabled = true;
      deleteButton.disabled = true;
      button2.disabled = true;
      try {
        const { name } = await writer.uploadImage(file, { reference });
        if (!isImageName(name)) throw new Error("The upload did not return a valid image filename.");
        const current = textarea.value;
        const [start, end] = current === original ? position : [textarea.selectionStart, textarea.selectionEnd];
        const caption = file.name.replace(/\.[^.]+$/, "").replace(/[\[\]\r\n]/g, " ").trim();
        const before = start && current[start - 1] !== "\n" ? "\n" : "";
        const after = end < current.length && current[end] !== "\n" ? "\n" : "";
        textarea.setRangeText(`${before}![${caption}](${name})${after}`, start, end, "end");
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
        textarea.focus();
        status.textContent = "";
      } catch (error) {
        status.textContent = error.message;
      } finally {
        saveButton.disabled = false;
        deleteButton.disabled = false;
        button2.disabled = false;
      }
    });
    controls.append(button2, picker);
    return controls;
  }
  function editEntry(reference, title, entry, { afterSave, afterDelete, paragraphFields = [], hideNavigationColor = false }) {
    fields.replaceChildren();
    status.textContent = "";
    root.querySelector("#writer-title").textContent = `Edit ${title}`;
    const controls = [];
    const spellchecks = [];
    for (const [key, value] of Object.entries(entry)) {
      if (key === "id" || value === null || hideNavigationColor && key === "color") continue;
      const label = document.createElement("label");
      label.textContent = key.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/^./, (letter) => letter.toUpperCase());
      const prose = key === "content" || key === "description" || paragraphFields.includes(key);
      const structured = typeof value === "object";
      const input = document.createElement(prose || structured ? "textarea" : "input");
      if (input.tagName === "TEXTAREA") input.rows = prose ? 7 : 3;
      if (typeof value === "boolean") {
        input.type = "checkbox";
        input.checked = value;
      } else {
        input.value = structured ? JSON.stringify(value, null, 2) : String(value);
      }
      if (prose && typeof value === "string") {
        input.id = `writer-field-${controls.length}`;
        label.htmlFor = input.id;
        const formatting = createFormattingControls(input, label.textContent);
        fields.append(label, formatting);
        if (writer.checkSpelling) {
          const spellcheck = createSpellcheckField(input, writer.checkSpelling);
          spellchecks.push(spellcheck);
          fields.append(spellcheck.shell);
        } else {
          fields.append(input);
        }
        if (writer.uploadImage) fields.append(imageUpload(input, reference, label.textContent));
      } else {
        if (structured) input.spellcheck = false;
        label.append(input);
        fields.append(label);
      }
      controls.push({ key, original: input.type === "checkbox" ? input.checked : input.value, value, input });
    }
    currentEdit = { reference, title, controls, spellchecks, afterSave, afterDelete };
    deleteButton.hidden = !afterDelete;
    dialog.showModal();
  }
  form.querySelector('button[type="button"]').addEventListener("click", () => {
    if (!saveButton.disabled) dialog.close();
  });
  dialog.addEventListener("cancel", (event) => {
    if (saveButton.disabled) event.preventDefault();
  });
  dialog.addEventListener("close", () => {
    if (dialog.open) return;
    for (const spellcheck of currentEdit?.spellchecks ?? []) spellcheck.dispose();
  });
  async function submitChange(operation, body, onSuccess) {
    saveButton.disabled = true;
    deleteButton.disabled = true;
    try {
      const data = await operation(body);
      dialog.close();
      onSuccess(data);
    } catch (error) {
      status.textContent = error.message;
    } finally {
      saveButton.disabled = false;
      deleteButton.disabled = false;
    }
  }
  deleteButton.addEventListener("click", () => {
    if (!currentEdit?.afterDelete || saveButton.disabled) return;
    const { title, reference, afterDelete } = currentEdit;
    if (!window.confirm(`Delete "${title}" from ${saveTarget}?`)) return;
    status.textContent = "";
    submitChange(writer.deleteAbility, reference, afterDelete);
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!currentEdit || saveButton.disabled) return;
    status.textContent = "";
    const values = /* @__PURE__ */ Object.create(null);
    try {
      for (const { key, original, value, input } of currentEdit.controls) {
        const edited = input.type === "checkbox" ? input.checked : input.value;
        if (edited === original) continue;
        if (typeof value === "number" && (!edited.trim() || !Number.isFinite(Number(edited)))) {
          throw new Error(`Enter a number for "${key}".`);
        }
        if (typeof value === "object") {
          try {
            values[key] = JSON.parse(edited);
          } catch {
            throw new Error(`Enter valid JSON for "${key}".`);
          }
        } else {
          values[key] = typeof value === "number" ? Number(edited) : edited;
        }
      }
      if (Object.keys(values).length) {
        submitChange(writer.saveEntry, { reference: currentEdit.reference, values }, currentEdit.afterSave);
      } else {
        dialog.close();
      }
    } catch (error) {
      status.textContent = error.message;
    }
  });
  return { editEntry, dispose() {
    for (const spellcheck of currentEdit?.spellchecks ?? []) spellcheck.dispose();
  } };
}

// node_modules/compendium/src/navigation.js
var types = ["normal", "grid", "table", "classes"];
function item(id, title, color, value) {
  return { id, title, color, value };
}
function listPages(pages) {
  return pages.map((page) => item(page.id, page.title, page.color, page));
}
function groupedSections(sections) {
  const groups = /* @__PURE__ */ new Map();
  for (const section of sections) {
    const group = section.navigationGroup ?? section;
    if (!groups.has(group.id)) groups.set(group.id, item(group.id, group.title, group.color, []));
    groups.get(group.id).value.push(section);
  }
  return [...groups.values()];
}
function collectionFor(data, page) {
  return data.collections?.find((collection) => collection.id === page.collectionId);
}
function setEntries(data, page, entries) {
  const collection = collectionFor(data, page);
  const users = data.tabs.flatMap((tab) => [tab, ...tab.sections ?? []]).filter((view) => view.collectionId === page.collectionId);
  if (collection && users.length === 1) {
    collection.entries = entries;
    return;
  }
  const id = `collection-${crypto.randomUUID()}`;
  page.collectionId = id;
  (data.collections ??= []).push({ id, entries });
}
function updateClassList(tab, previous, next, kind) {
  const labels = tab.classPageLabels ??= {};
  const colors = tab.classPageColors ??= {};
  const names = labels[`${kind}Labels`] ??= {};
  const accents = colors[kind] ??= {};
  for (const entry of previous) {
    delete names[entry.id];
    delete accents[entry.id];
  }
  for (const entry of next) {
    Object.defineProperty(names, entry.id, { value: entry.title, enumerable: true, configurable: true, writable: true });
    if (entry.color) {
      Object.defineProperty(accents, entry.id, { value: entry.color, enumerable: true, configurable: true, writable: true });
    }
  }
}
function discardRemovedClassAbilities(data, tab, before) {
  const after = new Set(tab.classPageStructure.groups.flatMap((group) => group.classes));
  const removed = new Set(before.filter((id) => !after.has(id)));
  const entries = collectionFor(data, tab)?.entries;
  if (removed.size && entries?.some((entry) => removed.has(entry.class))) {
    setEntries(data, tab, entries.filter((entry) => !removed.has(entry.class)));
  }
}
function classLevel(data, tab, groupId) {
  const groups = tab.classPageStructure.groups;
  const before = groups.flatMap((group2) => group2.classes);
  const labels = tab.classPageLabels;
  const colors = tab.classPageColors;
  if (groupId === void 0) {
    const items2 = groups.map((group2) => item(
      group2.key,
      labels?.groupLabels?.[group2.key] ?? group2.key,
      colors?.group?.[group2.key],
      group2
    ));
    return {
      items: items2,
      create: (id) => ({ key: id, classes: [] }),
      commit(next) {
        tab.classPageStructure.groups = next.map((entry) => entry.value);
        updateClassList(tab, items2, next, "group");
        discardRemovedClassAbilities(data, tab, before);
      }
    };
  }
  const group = groups.find((candidate) => candidate.key === groupId);
  if (!group) return null;
  const items = group.classes.map((id) => item(id, labels?.classLabels?.[id] ?? id, colors?.class?.[id], id));
  return {
    items,
    create: (id) => id,
    commit(next) {
      group.classes = next.map((entry) => entry.value);
      const remaining = new Set(tab.classPageStructure.groups.flatMap((candidate) => candidate.classes));
      updateClassList(tab, items.filter((entry) => !remaining.has(entry.id)), next, "class");
      for (const entry of next) {
        if (!entry.color && tab.classPageColors?.class) delete tab.classPageColors.class[entry.id];
      }
      discardRemovedClassAbilities(data, tab, before);
    }
  };
}
function levelFor(data, path) {
  const [tabId, subtabId] = path;
  if (!path.length) {
    return {
      items: listPages(data.tabs),
      types,
      create: (id, type) => type === "classes" ? { id, type, classPageStructure: { groups: [] } } : { id, type, sections: [] },
      commit: (next) => {
        data.tabs = next.map((entry) => ({ ...entry.value, title: entry.title, color: entry.color }));
      }
    };
  }
  const tab = data.tabs.find((candidate) => candidate.id === tabId);
  if (!tab) return null;
  if (tab.type === "classes" && tab.classPageStructure) return classLevel(data, tab, subtabId);
  const groups = groupedSections(tab.sections ?? []);
  if (path.length === 1) {
    return {
      items: groups,
      types: types.slice(0, 3),
      create: (id, type) => [{ id, type }],
      commit: (next) => {
        tab.sections = next.flatMap((entry) => entry.value.map((section2) => section2.navigationGroup ? { ...section2, navigationGroup: { id: entry.id, title: entry.title, color: entry.color } } : { ...section2, title: entry.title, color: entry.color }));
      }
    };
  }
  const sections = groups.find((group) => group.id === subtabId)?.value;
  if (sections?.length !== 1 || (sections[0].type ?? tab.type ?? "normal") !== "normal") return null;
  const section = sections[0];
  const titleKey = (entry) => Object.hasOwn(entry, "title") ? "title" : "name";
  return {
    items: (collectionFor(data, section)?.entries ?? []).map((entry) => item(entry.id, entry[titleKey(entry)] ?? entry.id, entry.color, entry)),
    create: (id) => ({ id, title: "", content: "" }),
    commit: (next) => setEntries(data, section, next.map((entry) => ({
      ...entry.value,
      [titleKey(entry.value)]: entry.title,
      color: entry.color
    })))
  };
}
function getNavigation(data, path = []) {
  const level = levelFor(data, path);
  if (!level) return null;
  return {
    types: level.types,
    items: level.items.map(({ id, title, color }) => ({
      id,
      title,
      color,
      children: path.length < 2 ? getNavigation(data, [...path, id]) : null
    }))
  };
}

// node_modules/compendium/src/browser/navigation.js
var levels = ["tab", "subtab", "category"];
function button(text, label, click) {
  const control = document.createElement("button");
  control.type = "button";
  control.textContent = text;
  control.setAttribute("aria-label", label);
  control.addEventListener("click", click);
  return control;
}
function createNavigationEditor(root, getConfiguration, onSaved, changeNavigation, saveTarget) {
  const dialog = root.querySelector("#navigation-dialog");
  const form = root.querySelector("#navigation-form");
  const name = root.querySelector("#navigation-name");
  const color = root.querySelector("#navigation-color");
  const useDefault = root.querySelector("#navigation-default-color");
  const type = root.querySelector("#navigation-type");
  const status = root.querySelector("#navigation-status");
  const announcement = root.querySelector("#writer-announcement");
  const cancel = root.querySelector("#navigation-cancel");
  const submit = root.querySelector("#navigation-save");
  let edit;
  let busy = false;
  function openForm(path, current) {
    if (busy) return;
    const level = levels[path.length];
    const capitalized = level[0].toUpperCase() + level.slice(1);
    edit = { path, id: current?.id, action: current ? "rename" : "add" };
    root.querySelector("#navigation-title").textContent = current ? `Edit ${level}` : `Add ${level}`;
    root.querySelector("#navigation-name-label").textContent = `${capitalized} name`;
    name.value = current?.title ?? "";
    color.value = current?.color || "#805b34";
    useDefault.checked = !current?.color;
    const options = current ? [] : getNavigation(getConfiguration(), path)?.types ?? [];
    type.replaceChildren(...options.map((value) => new Option(value[0].toUpperCase() + value.slice(1), value)));
    type.closest("label").hidden = !options.length;
    status.textContent = "";
    dialog.showModal();
    name.focus();
  }
  async function save(change) {
    if (busy) return;
    busy = true;
    submit.disabled = true;
    cancel.disabled = true;
    announcement.textContent = "";
    status.textContent = "";
    const before = change.action === "add" ? new Set(getNavigation(getConfiguration(), change.path).items.map((item2) => item2.id)) : null;
    try {
      const data = await changeNavigation(change);
      if (dialog.open) dialog.close();
      const added = before && getNavigation(data, change.path).items.find((item2) => !before.has(item2.id));
      onSaved(data, added && { path: change.path, id: added.id });
      const list = [...root.querySelectorAll("[data-navigation-path]")].find((node) => node.dataset.navigationPath === JSON.stringify(change.path));
      const focusId = added?.id ?? (change.action === "remove" ? void 0 : change.id);
      const focus = [...list?.querySelectorAll("[data-navigation-id]") ?? []].find((node) => node.dataset.navigationId === focusId);
      (focus ?? list?.querySelector('[aria-pressed="true"]'))?.focus();
      announcement.textContent = `Navigation saved to ${saveTarget}.`;
    } catch (error) {
      if (dialog.open) status.textContent = error.message;
      else announcement.textContent = error.message;
    } finally {
      busy = false;
      submit.disabled = false;
      cancel.disabled = false;
    }
  }
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    save({ ...edit, title: name.value, color: useDefault.checked ? "" : color.value, type: type.value });
  });
  color.addEventListener("input", () => {
    useDefault.checked = false;
  });
  cancel.addEventListener("click", () => dialog.close());
  dialog.addEventListener("cancel", (event) => {
    if (busy) event.preventDefault();
  });
  return {
    attach(list, path, controls, options, current) {
      const level = levels[path.length];
      list.dataset.navigationPath = JSON.stringify(path);
      let dragging;
      for (const [index, { control, id }] of options.entries()) {
        control.dataset.navigationId = id;
        control.classList.add("draggable-navigation");
        control.draggable = true;
        control.title = "Drag to reorder, or press Alt and an arrow key";
        control.ondragstart = (event) => {
          dragging = id;
          control.classList.add("is-dragging");
          event.dataTransfer.setData("text/plain", id);
          event.dataTransfer.effectAllowed = "move";
        };
        control.ondragend = () => {
          dragging = void 0;
          control.classList.remove("is-dragging");
          for (const option of options) option.control.classList.remove("navigation-drop-target");
        };
        control.ondragover = (event) => {
          if (!dragging || dragging === id) return;
          event.preventDefault();
          event.dataTransfer.dropEffect = "move";
          control.classList.add("navigation-drop-target");
        };
        control.ondragleave = () => control.classList.remove("navigation-drop-target");
        control.ondrop = (event) => {
          if (!dragging || dragging === id) return;
          event.preventDefault();
          save({ action: "move", path, id: dragging, targetId: id });
        };
        control.onkeydown = (event) => {
          if (!event.altKey) return;
          const direction = ["ArrowLeft", "ArrowUp"].includes(event.key) ? -1 : ["ArrowRight", "ArrowDown"].includes(event.key) ? 1 : 0;
          if (!direction) return;
          event.preventDefault();
          if (options[index + direction]) save({ action: "move", path, id, direction });
        };
      }
      const add = button("Add", `Add ${level}`, () => openForm(path));
      const editButton = button("Edit", `Edit ${level}`, () => openForm(path, current));
      const remove = button("Remove", `Remove ${level}`, () => {
        if (window.confirm(`Remove "${current.title}" and its contents from ${saveTarget}?`)) {
          save({ action: "remove", path, id: current.id });
        }
      });
      editButton.disabled = !current;
      remove.disabled = !current;
      const row = document.createElement("div");
      row.className = "navigation-actions";
      row.setAttribute("role", "group");
      row.setAttribute("aria-label", `${level} writer tools`);
      row.append(add, editButton, remove);
      controls.replaceChildren(row);
    }
  };
}

// node_modules/compendium/src/browser/search.js
var originalTabs = /* @__PURE__ */ new Set(["lore", "classes", "equipment", "conditions"]);
function searchText(values) {
  if (Array.isArray(values)) return values.map(searchText).join(" ");
  if (values && typeof values === "object") return searchText(Object.values(values));
  return String(values ?? "");
}
function equipmentTerms(entry, sectionId) {
  switch (sectionId) {
    case "weapons":
      return [entry.type, entry.damage?.type, entry.properties];
    case "armors":
    case "shields":
      return [entry.properties];
    case "generalItems":
      return [entry.description, entry.amountCharges, entry.cost];
    case "equipmentProperties":
      return [entry.description];
    default:
      return Object.values(entry);
  }
}
function searchCompendium(compendium, input) {
  const query = input.trim().toLowerCase();
  if (!query) return [];
  const results = [];
  function add(title, meta, target, terms = [], prefix = []) {
    const lowerTitle = title.toLowerCase();
    const index = searchText([...prefix, title, ...terms]).toLowerCase().indexOf(query);
    if (index < 0) return;
    const score = lowerTitle === query ? 0 : lowerTitle.startsWith(query) ? 1 : index + 2;
    results.push({ title, meta, target, score });
  }
  function addEntry(entry, view, target, meta, terms, prefix) {
    const key = view.fields?.find((field) => field.isTitle)?.key;
    const title = String(entry[key] ?? entry.title ?? entry.name ?? entry.id);
    add(title, meta, { ...target, entryId: entry.id }, terms, prefix);
  }
  for (const tab of compendium.tabs) {
    const tabTarget = { tabId: tab.id };
    const isCustom = !originalTabs.has(tab.id);
    if (isCustom) {
      const type = tab.type.charAt(0).toUpperCase() + tab.type.slice(1);
      const target = tab.type === "normal" && tab.sections.length ? { ...tabTarget, sectionId: tab.sections[0].id } : tabTarget;
      add(tab.title, `${type} Tab`, target);
    }
    const groups = tab.classPageStructure?.groups ?? [];
    if (tab.type === "classes" && groups.length) {
      const members = /* @__PURE__ */ new Map();
      for (const group of groups) {
        const groupLabel2 = tab.classPageLabels?.groupLabels?.[group.key] ?? group.key;
        for (const id of group.classes) {
          const title = tab.classPageLabels?.classLabels?.[id] ?? id;
          const target = { ...tabTarget, groupId: group.key, classId: id };
          add(title, "Class", target, [groupLabel2, id, group.key]);
          members.set(id, { title, target });
        }
      }
      for (const ability of tab.entries) {
        const member = members.get(ability.class);
        if (member) {
          addEntry(
            ability,
            tab,
            member.target,
            `${member.title} Ability`,
            [member.title, ability.class, ability.description, ability.type]
          );
        }
      }
    } else {
      for (const entry of tab.entries) {
        const terms = tab.id === "conditions" ? [entry.description] : Object.values(entry);
        addEntry(entry, tab, tabTarget, tab.id === "conditions" ? "Condition" : tab.title, terms);
      }
    }
    for (const section of tab.sections) {
      const target = { ...tabTarget, sectionId: section.id };
      if (tab.id !== "equipment") {
        add(
          section.title,
          tab.id === "lore" ? "Lore Category" : tab.title,
          target,
          [],
          isCustom ? [tab.title] : []
        );
      }
      for (const entry of section.entries) {
        if (tab.id === "equipment") {
          addEntry(entry, section, target, section.title, [section.title, ...equipmentTerms(entry, section.id)]);
        } else if (tab.id === "lore") {
          addEntry(entry, section, target, section.title, [entry.content ?? entry.description]);
        } else {
          addEntry(
            entry,
            section,
            target,
            `${tab.title} / ${section.title}`,
            section.type === "normal" ? [entry.content ?? entry.description] : Object.values(entry),
            [tab.title, section.title]
          );
        }
      }
    }
  }
  return results.sort((a, b) => a.score - b.score || a.title.localeCompare(b.title)).slice(0, 12);
}

// node_modules/compendium/src/browser/markup.js
var markup = `
<main>
    <header>
      <h1></h1>
      <div class="compendium-search">
        <label for="search">Search
          <input id="search" type="search" placeholder="Search the compendium" aria-controls="search-results" disabled>
        </label>
        <div id="search-results" role="region" aria-label="Search results" hidden></div>
      </div>
    </header>
    <div id="tab-navigation">
      <nav id="tabs" aria-label="Compendium sections"></nav>
      <div id="tab-writer-actions"></div>
    </div>
    <div id="subtabs"></div>
    <div id="content" aria-live="polite">Loading compendium\u2026</div>
    <p id="writer-announcement" role="status"></p>
  </main>
  <dialog id="writer-dialog" aria-labelledby="writer-title">
    <form id="writer-form">
      <h2 id="writer-title">Edit entry</h2>
      <p id="writer-notice"></p>
      <div id="writer-fields"></div>
      <p id="writer-status" role="alert"></p>
      <div class="entry-actions">
        <button type="button">Cancel</button>
        <button type="submit">Save</button>
        <button id="writer-delete" type="button" hidden>Delete</button>
      </div>
    </form>
  </dialog>
  <dialog id="navigation-dialog" aria-labelledby="navigation-title">
    <form id="navigation-form" class="navigation-form">
      <h2 id="navigation-title"></h2>
      <label><span id="navigation-name-label">Name</span>
        <input id="navigation-name" required maxlength="120">
      </label>
      <label>Page type <select id="navigation-type"></select></label>
      <div class="navigation-colors">
        <label>Color <input id="navigation-color" type="color"></label>
        <label>Use default color <input id="navigation-default-color" type="checkbox"></label>
      </div>
      <p id="navigation-status" role="alert"></p>
      <div class="entry-actions">
        <button id="navigation-cancel" type="button">Cancel</button>
        <button id="navigation-save" type="submit">Save</button>
      </div>
    </form>
  </dialog>
  <dialog id="style-guide" aria-labelledby="style-guide-title">
    <form id="style-guide-form">
      <h2 id="style-guide-title">Style Guide</h2>
      <div class="style-guide-row style-guide-labels" aria-hidden="true">
        <span>Preview</span><span>Font</span><span>Size (px)</span><span>Color</span>
      </div>
      <div id="style-guide-fields"></div>
      <p id="style-guide-status" role="alert"></p>
      <div class="entry-actions">
        <button id="style-guide-cancel" type="button">Cancel</button>
        <button id="style-guide-save" type="submit">Save</button>
      </div>
    </form>
  </dialog>

`;

// node_modules/compendium/src/browser/references.js
var normalize = (value) => String(value ?? "").trim().toLowerCase().replace(/\s*\/\s*/g, " / ");
function createPageReferences(compendium) {
  const names = /* @__PURE__ */ new Map();
  function add(title, path, target, location) {
    for (const key of /* @__PURE__ */ new Set([normalize(title), normalize(path.join(" / "))])) {
      if (!key) continue;
      if (!names.has(key)) names.set(key, []);
      names.get(key).push({ target, location });
    }
  }
  for (const tab of compendium.tabs) {
    const tabTarget = { tabId: tab.id };
    const tabLocation = { tab: tab.id };
    add(tab.title, [tab.title], tabTarget, tabLocation);
    const classGroups = tab.type === "classes" ? tab.classPageStructure?.groups ?? [] : [];
    const classes = /* @__PURE__ */ new Map();
    for (const group of classGroups) {
      const label = tab.classPageLabels?.groupLabels?.[group.key] ?? group.key;
      const groupTarget = { ...tabTarget, groupId: group.key };
      const groupLocation = { ...tabLocation, subtab: group.key };
      add(label, [tab.title, label], groupTarget, groupLocation);
      for (const id of group.classes) {
        const title = tab.classPageLabels?.classLabels?.[id] ?? id;
        const path = [tab.title, label, title];
        const target = { ...groupTarget, classId: id };
        const location = { ...groupLocation, entry: id };
        add(title, path, target, location);
        if (!classes.has(id)) classes.set(id, { path, target, location });
      }
    }
    for (const entry of tab.entries) {
      const parent = classes.get(entry.class);
      if (classGroups.length && !parent) continue;
      const title = titleFor(tab, entry);
      add(
        title,
        [...parent?.path ?? [tab.title], title],
        { ...parent?.target ?? tabTarget, entryId: entry.id },
        parent?.location ?? tabLocation
      );
    }
    const navigationGroups = /* @__PURE__ */ new Set();
    for (const section of tab.sections) {
      const subtab = section.navigationGroup ?? section;
      const sectionTarget = { ...tabTarget, sectionId: section.id };
      const sectionLocation = { ...tabLocation, subtab: subtab.id };
      if (!navigationGroups.has(subtab.id)) {
        add(subtab.title, [tab.title, subtab.title], sectionTarget, sectionLocation);
        navigationGroups.add(subtab.id);
      }
      if (section.title !== subtab.title) {
        add(section.title, [tab.title, subtab.title, section.title], sectionTarget, sectionLocation);
      }
      for (const entry of section.entries) {
        const title = titleFor(section, entry);
        const location = section.type === "normal" ? { ...sectionLocation, entry: entry.id } : sectionLocation;
        add(title, [tab.title, subtab.title, title], { ...sectionTarget, entryId: entry.id }, location);
      }
    }
  }
  return (name, origin = {}) => {
    const matches = names.get(normalize(name)) ?? [];
    return matches.find((match) => match.target.tabId === origin.tabId && match.target.sectionId === origin.sectionId) ?? matches.find((match) => match.target.tabId === origin.tabId) ?? matches[0];
  };
}
function titleFor(page, entry) {
  const key = page.fields?.find((field) => field.isTitle)?.key;
  return String(entry[key] ?? entry.title ?? entry.name ?? entry.id);
}

// node_modules/compendium/src/typography.js
var typographyRoles = {
  title: "Compendium title",
  pageTitle: "Page titles",
  entryTitle: "Entry and class titles",
  sectionHeading: "Section and rank headings",
  heading1: "Text heading 1 (#)",
  heading2: "Text heading 2 (##)",
  heading3: "Text heading 3 (###)"
};
var typographyFonts = {
  system: { label: "System", family: "system-ui, sans-serif" },
  georgia: { label: "Georgia", family: "Georgia, serif" },
  times: { label: "Times New Roman", family: '"Times New Roman", serif' },
  arial: { label: "Arial", family: "Arial, sans-serif" },
  verdana: { label: "Verdana", family: "Verdana, sans-serif" },
  monospace: { label: "Monospace", family: "monospace" }
};
var typographySize = { min: 10, max: 72 };
function normalizeTypography(settings = {}) {
  if (!settings || typeof settings !== "object" || Array.isArray(settings)) {
    throw new TypeError("Choose valid typography settings.");
  }
  const normalized = {};
  for (const [role, style] of Object.entries(settings)) {
    if (!Object.hasOwn(typographyRoles, role) || !style || typeof style !== "object" || Array.isArray(style)) {
      throw new TypeError("Choose a valid typography role.");
    }
    const { font, size, color } = style;
    if (font !== void 0 && (typeof font !== "string" || !Object.hasOwn(typographyFonts, font))) {
      throw new TypeError("Choose a font from the Style Guide.");
    }
    if (size !== void 0 && (!Number.isInteger(size) || size < typographySize.min || size > typographySize.max)) {
      throw new TypeError(`Choose a whole font size from ${typographySize.min} to ${typographySize.max} pixels.`);
    }
    if (color !== void 0 && (typeof color !== "string" || !/^#[\da-f]{6}$/i.test(color))) {
      throw new TypeError("Choose a valid text color.");
    }
    if (font !== void 0 || size !== void 0 || color !== void 0) {
      normalized[role] = {
        ...font === void 0 ? {} : { font },
        ...size === void 0 ? {} : { size },
        ...color === void 0 ? {} : { color: color.toLowerCase() }
      };
    }
  }
  return normalized;
}

// node_modules/compendium/src/browser/style-guide.js
function applyHeadingStyle(heading, { font, size, color } = {}) {
  heading.style.fontFamily = typographyFonts[font]?.family ?? "";
  heading.style.fontSize = size === void 0 ? "" : `${size}px`;
  heading.style.color = color ?? "";
  return heading;
}
function createStyleGuide(root, saveTypography, onSaved) {
  const dialog = root.querySelector("#style-guide");
  const form = root.querySelector("#style-guide-form");
  const fields = root.querySelector("#style-guide-fields");
  const status = root.querySelector("#style-guide-status");
  const save = root.querySelector("#style-guide-save");
  const cancel = root.querySelector("#style-guide-cancel");
  const controls = /* @__PURE__ */ new Map();
  for (const [role, label] of Object.entries(typographyRoles)) {
    let updateSample = function() {
      const px = size.valueAsNumber;
      const validSize = Number.isInteger(px) && px >= typographySize.min && px <= typographySize.max;
      applyHeadingStyle(sample, {
        font: font.value,
        size: validSize ? px : void 0,
        color: state.customColor
      });
      resetSize.disabled = size.value === "";
      resetColor.disabled = state.customColor === void 0;
    };
    const row = document.createElement("div");
    row.className = "style-guide-row";
    const sample = document.createElement("span");
    sample.textContent = label;
    sample.className = "style-guide-sample";
    const font = document.createElement("select");
    font.setAttribute("aria-label", `${label} font`);
    font.append(new Option("Default", ""));
    for (const [key, { label: fontLabel }] of Object.entries(typographyFonts)) {
      font.append(new Option(fontLabel, key));
    }
    const size = document.createElement("input");
    size.type = "number";
    size.min = typographySize.min;
    size.max = typographySize.max;
    size.step = "1";
    size.placeholder = "Default";
    size.setAttribute("aria-label", `${label} size (px)`);
    const resetSize = document.createElement("button");
    resetSize.type = "button";
    resetSize.textContent = "Reset";
    resetSize.setAttribute("aria-label", `Reset ${label} size`);
    const sizeControl = document.createElement("div");
    sizeControl.className = "style-guide-control";
    sizeControl.append(size, resetSize);
    const color = document.createElement("input");
    color.type = "color";
    color.setAttribute("aria-label", `${label} color`);
    const resetColor = document.createElement("button");
    resetColor.type = "button";
    resetColor.textContent = "Default";
    resetColor.setAttribute("aria-label", `Use default color for ${label}`);
    const colorControl = document.createElement("div");
    colorControl.className = "style-guide-control";
    colorControl.append(color, resetColor);
    const state = { font, size, color, customColor: void 0, updateSample };
    font.addEventListener("change", updateSample);
    size.addEventListener("input", updateSample);
    resetSize.addEventListener("click", () => {
      size.value = "";
      updateSample();
    });
    color.addEventListener("input", () => {
      state.customColor = color.value;
      updateSample();
    });
    resetColor.addEventListener("click", () => {
      state.customColor = void 0;
      color.value = "#28241d";
      updateSample();
    });
    row.append(sample, font, sizeControl, colorControl);
    fields.append(row);
    controls.set(role, state);
  }
  function show(settings) {
    status.textContent = "";
    for (const [role, state] of controls) {
      const { font, size, color, updateSample } = state;
      font.value = settings[role]?.font ?? "";
      size.value = settings[role]?.size ?? "";
      state.customColor = settings[role]?.color;
      color.value = state.customColor ?? "#28241d";
      updateSample();
    }
    dialog.showModal();
  }
  cancel.addEventListener("click", () => dialog.close());
  dialog.addEventListener("cancel", (event) => {
    if (save.disabled) event.preventDefault();
  });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (save.disabled) return;
    status.textContent = "";
    save.disabled = true;
    cancel.disabled = true;
    try {
      const settings = {};
      for (const [role, { font, size, customColor }] of controls) {
        settings[role] = {
          font: font.value || void 0,
          size: size.value ? size.valueAsNumber : void 0,
          color: customColor
        };
      }
      const configuration = await saveTypography(normalizeTypography(settings));
      dialog.close();
      onSaved(configuration);
    } catch (error) {
      status.textContent = error.message;
    } finally {
      save.disabled = false;
      cancel.disabled = false;
    }
  });
  return { show };
}

// node_modules/compendium/src/browser/index.js
function mountCompendium(container, configuration, {
  title = "Compendium",
  projectId = configuration.id ?? "local",
  routing = false,
  stylesheets = [],
  imageBaseUrl,
  writer = {},
  saveTarget = "this compendium"
} = {}) {
  const host2 = document.createElement("div");
  const root = host2.attachShadow({ mode: "open" });
  root.innerHTML = markup;
  const titleHeading = root.querySelector("h1");
  titleHeading.textContent = title;
  let typography = normalizeTypography(configuration.typography);
  applyHeadingStyle(titleHeading, typography.title);
  root.querySelector("#writer-notice").textContent = `Changes are saved to ${saveTarget}.`;
  for (const href of [new URL("/games/Expedition/compendium-reader.css", document.baseURI), ...stylesheets]) {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    root.insertBefore(link, root.querySelector("main"));
  }
  container.append(host2);
  const tabs = root.querySelector("#tabs");
  const subtabs = root.querySelector("#subtabs");
  const content = root.querySelector("#content");
  const search = root.querySelector("#search");
  const searchResults = root.querySelector("#search-results");
  const tabWriterActions = root.querySelector("#tab-writer-actions");
  function element(tag, text) {
    const node = document.createElement(tag);
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function styledHeading(tag, text, role) {
    return applyHeadingStyle(element(tag, text), typography[role]);
  }
  function titleFor3(key) {
    const words = key.replace(/([a-z])([A-Z])/g, "$1 $2");
    return words.charAt(0).toUpperCase() + words.slice(1);
  }
  function display(value) {
    if (value === null || value === void 0) return "";
    if (Array.isArray(value)) return value.map(display).join(", ");
    if (typeof value === "object") return Object.values(value).map(display).join(" ");
    if (typeof value === "boolean") return value ? "Yes" : "No";
    return String(value);
  }
  function columnsFor(page, entries) {
    if (page.columns?.length) return page.columns;
    const keys = new Set(entries.flatMap((entry) => Object.keys(entry)));
    keys.delete("id");
    return [...keys].map((key) => ({ key, label: titleFor3(key) }));
  }
  function renderTable(page, entries, favorite, origin) {
    const wrapper = element("div");
    wrapper.className = "table-container";
    const table = element("table");
    table.setAttribute("aria-label", page.title);
    const header = table.createTHead().insertRow();
    const columns = columnsFor(page, entries);
    for (const { key, label } of columns) {
      const cell = element("th", label ?? titleFor3(key));
      cell.scope = "col";
      header.append(cell);
    }
    const favoritesColumn = element("th", "Favorite");
    favoritesColumn.scope = "col";
    header.append(favoritesColumn);
    const body = table.createTBody();
    for (const entry of entries) {
      const row = body.insertRow();
      for (const { key } of columns) renderInline(row.insertCell(), display(entry[key]), origin);
      row.insertCell().append(favorite(entry));
    }
    wrapper.append(table);
    return wrapper;
  }
  const imageBase = imageBaseUrl ? new URL(imageBaseUrl, document.baseURI) : null;
  if (imageBase) imageBase.pathname = imageBase.pathname.replace(/\/?$/, "/");
  let findReference;
  let followReference;
  function renderInline(node, text, origin) {
    return appendInline(node, text, (name) => {
      const reference = findReference?.(name, origin);
      if (!reference) return null;
      const link = element(routing ? "a" : "button", name.trim());
      link.className = "inline-reference";
      if (routing) link.href = pageUrl(reference.location).href;
      else link.type = "button";
      link.addEventListener("click", (event) => {
        if (routing && (event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey)) return;
        event.preventDefault();
        followReference(reference.target);
      });
      return link;
    });
  }
  function renderImage(line, origin) {
    const match = line.match(/^!\[([^\]]*)\]\(([^)\s]+)\)$/);
    if (!match || !imageBase || !isImageName(match[2])) return null;
    const [, caption, name] = match;
    const figure = element("figure");
    figure.className = "compendium-image";
    const image = element("img");
    image.src = new URL(encodeURIComponent(name), imageBase).href;
    image.alt = caption;
    image.loading = "lazy";
    figure.append(image);
    if (caption) figure.append(renderInline(element("figcaption"), caption, origin));
    return figure;
  }
  function renderProse(source, parentHeading, origin, favoriteBlock) {
    const body = element("div");
    body.className = "prose";
    let paragraph = [];
    let tableRows = [];
    let blockIndex = 0;
    function addBlock(node, excerpt = node.textContent) {
      if (!favoriteBlock) {
        body.append(node);
        return;
      }
      const block = element("div");
      block.className = "favorite-block";
      block.append(node, favoriteBlock(blockIndex++, excerpt.trim().slice(0, 300)));
      body.append(block);
    }
    function flushParagraph() {
      if (!paragraph.length) return;
      addBlock(renderInline(element("p"), paragraph.join("\n"), origin));
      paragraph = [];
    }
    function flushTable() {
      if (!tableRows.length) return;
      const wrapper = element("div");
      wrapper.className = "table-container";
      const table = element("table");
      const [columns, ...rows] = tableRows;
      const header = table.createTHead().insertRow();
      for (const label of columns) {
        const cell = renderInline(element("th"), label, origin);
        cell.scope = "col";
        header.append(cell);
      }
      const body2 = table.createTBody();
      for (const values of rows) {
        if (values.every((value) => /^:?-{3,}:?$/.test(value))) continue;
        const row = body2.insertRow();
        for (const value of values) renderInline(row.insertCell(), value, origin);
      }
      wrapper.append(table);
      addBlock(wrapper, tableRows.map((values) => values.join(" | ")).join("\n"));
      tableRows = [];
    }
    for (const line of source.split(/\r?\n/)) {
      const trimmed = line.trim();
      const cells = trimmed.startsWith("|") ? trimmed.slice(1).replace(/\|$/, "").split("|").map((cell) => cell.trim()) : [];
      if (cells.length > 1) {
        flushParagraph();
        tableRows.push(cells);
        continue;
      }
      flushTable();
      const figure = renderImage(trimmed, origin);
      if (figure) {
        flushParagraph();
        addBlock(figure, trimmed);
        continue;
      }
      const title2 = trimmed.match(/^(#{1,3})[ \t]+(.+)$/);
      if (title2) {
        flushParagraph();
        const level = title2[1].length;
        const heading = renderInline(styledHeading(`h${Math.min(6, Number(parentHeading.slice(1)) + level)}`, "", `heading${level}`), title2[2], origin);
        heading.className = `prose-title prose-title-${level}`;
        addBlock(heading);
      } else if (trimmed) {
        paragraph.push(line);
      } else {
        flushParagraph();
      }
    }
    flushParagraph();
    flushTable();
    return body;
  }
  function entryTitle(page, entry) {
    const titleField = page.fields?.find((field) => field.isTitle)?.key;
    return display(entry[titleField] ?? entry.title ?? entry.name ?? entry.id);
  }
  function renderCard(page, entry, headingLevel, favorite, origin, rankedAbility = false) {
    const card = element("article");
    const titleField = page.fields?.find((field) => field.isTitle)?.key;
    const header = element("div");
    header.className = "favorite-block";
    header.append(styledHeading(headingLevel, entryTitle(page, entry), "entryTitle"), favorite(entry));
    card.append(header);
    if (rankedAbility) {
      const metadata = [
        entry.actionCost == null ? "" : `Action ${display(entry.actionCost)}`,
        entry.enduranceCost == null ? "" : `Endurance ${display(entry.enduranceCost)}`,
        display(entry.type)
      ].filter(Boolean);
      if (metadata.length) {
        const line = element("p", metadata.join(" | "));
        line.className = "ability-meta";
        card.append(line);
      }
    }
    const renderField = (value, field) => renderProse(value, headingLevel, origin, (index, excerpt) => favorite(entry, { field, index, excerpt }));
    if (typeof entry.content === "string") {
      card.append(renderField(entry.content, "content"));
    } else if (typeof entry.description === "string" && entry.description) {
      card.append(renderProse(entry.description, headingLevel, origin));
    } else if (entry.content ?? entry.description) {
      const text = element("p", display(entry.content ?? entry.description));
      text.className = "prose";
      card.append(text);
    }
    const hiddenFields = /* @__PURE__ */ new Set(["id", "name", "title", "content", "description", titleField]);
    if (rankedAbility) {
      for (const key of ["class", "rank", "actionCost", "enduranceCost", "type"]) hiddenFields.add(key);
    }
    if (page.type === "normal" && origin.sectionId !== void 0) hiddenFields.add("color");
    const fields = page.fields ?? Object.keys(entry).map((key) => ({ key }));
    const details = element("dl");
    for (const { key, label, type } of fields) {
      if (hiddenFields.has(key) || entry[key] === void 0) continue;
      const value = element("dd");
      if (type === "paragraph" && typeof entry[key] === "string") {
        value.append(renderField(entry[key], key));
      } else {
        value.textContent = display(entry[key]);
      }
      details.append(element("dt", label ?? titleFor3(key)), value);
    }
    if (details.childElementCount) card.append(details);
    return card;
  }
  function entryFavorite(page, favoriteButton, tabId, sectionId) {
    return (entry, block) => favoriteButton(
      { tabId, sectionId, entryId: entry.id, block },
      block ? block.excerpt || entryTitle(page, entry) : entryTitle(page, entry)
    );
  }
  function renderEntries(page, entries, headingLevel, favoriteButton, tabId, sectionId) {
    const favorite = entryFavorite(page, favoriteButton, tabId, sectionId);
    if (page.type === "table") return renderTable(page, entries, favorite, { tabId, sectionId });
    const list = element("div");
    list.className = page.type === "grid" || page.type === "classes" ? "cards grid" : "cards";
    for (const entry of entries) list.append(renderCard(page, entry, headingLevel, favorite, { tabId, sectionId }));
    return list;
  }
  function applyNavigationColor(button2, color) {
    if (typeof color !== "string" || !/^#[\da-f]{6}$/i.test(color)) return;
    const [red, green, blue] = color.slice(1).match(/.{2}/g).map((hex) => {
      const value = parseInt(hex, 16) / 255;
      return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
    });
    const luminance = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
    button2.style.setProperty("--navigation-color", color);
    button2.style.setProperty("--navigation-ink", luminance > 0.179 ? "#000" : "#fff");
    button2.classList.add("custom-navigation-color");
  }
  function selectOption(label, options, selection, key, update, showEmpty) {
    const selected = options.find((option) => option.id === selection[key]) ?? options[0];
    if (!options.length && !showEmpty) return void 0;
    const nav = element("nav");
    nav.className = "subtabs";
    nav.setAttribute("aria-label", label);
    let selectedButton;
    const controls = options.map((option) => {
      const button2 = element("button", option.title);
      applyNavigationColor(button2, option.color);
      button2.type = "button";
      button2.setAttribute("aria-pressed", String(option === selected));
      button2.addEventListener("click", () => {
        selection[key] = option.id;
        update(label);
      });
      nav.append(button2);
      if (option === selected) selectedButton = button2;
      return { ...option, control: button2 };
    });
    return { selected, nav, selectedButton, options: controls };
  }
  function getSectionGroups(sections) {
    const groups = /* @__PURE__ */ new Map();
    for (const section of sections) {
      const { id, title: title2, color } = section.navigationGroup ?? section;
      if (!groups.has(id)) groups.set(id, { id, title: title2, color, sections: [] });
      groups.get(id).sections.push(section);
    }
    return [...groups.values()];
  }
  function getClassGroups(page) {
    const labels = page.classPageLabels;
    return (page.classPageStructure?.groups ?? []).map((group) => ({
      id: group.key,
      title: labels?.groupLabels?.[group.key] ?? group.key,
      color: page.classPageColors?.group?.[group.key],
      classes: group.classes.map((id) => ({
        id,
        title: labels?.classLabels?.[id] ?? id,
        color: page.classPageColors?.class?.[id]
      }))
    }));
  }
  function renderAbilityRanks(page, abilities, headingLevel, favoriteButton) {
    const ranks = /* @__PURE__ */ new Map();
    for (const ability of abilities) {
      const value = ability.rank;
      const number = typeof value === "number" || typeof value === "string" && value.trim() ? Number(value) : NaN;
      const rank = Number.isFinite(number) ? number : Infinity;
      if (!ranks.has(rank)) ranks.set(rank, []);
      ranks.get(rank).push(ability);
    }
    const groups = document.createDocumentFragment();
    const abilityHeading = `h${Math.min(6, headingLevel + 1)}`;
    const favorite = entryFavorite(page, favoriteButton, page.id);
    for (const rank of [...ranks.keys()].sort((a, b) => a - b)) {
      const section = element("section");
      section.className = "ability-rank";
      const cards = element("div");
      cards.className = "cards";
      const entries = ranks.get(rank).sort((a, b) => entryTitle(page, a).localeCompare(entryTitle(page, b)));
      for (const entry of entries) cards.append(renderCard(page, entry, abilityHeading, favorite, { tabId: page.id }, true));
      section.append(styledHeading(`h${headingLevel}`, rank === Infinity ? "Unranked" : `Rank ${rank}`, "sectionHeading"), cards);
      groups.append(section);
    }
    return groups;
  }
  function renderFullCompendium(compendium, favoriteButton) {
    const root2 = element("div");
    root2.className = "full-compendium";
    root2.append(styledHeading("h2", "Full Compendium", "pageTitle"));
    function addEntries(parent, page, entries, level, tab, heading) {
      if (!entries.length) return;
      if (heading) parent.append(styledHeading(`h${level}`, heading, "sectionHeading"));
      const entryHeading = `h${heading ? level + 1 : level}`;
      parent.append(renderEntries(page, entries, entryHeading, favoriteButton, tab.id, page === tab ? void 0 : page.id));
    }
    for (const tab of compendium.tabs) {
      const chapter = element("section");
      chapter.append(styledHeading("h3", tab.title, "pageTitle"));
      const groups = tab.type === "classes" ? getClassGroups(tab) : [];
      if (groups.length) {
        const abilitiesByClass = /* @__PURE__ */ new Map();
        for (const entry of tab.entries) {
          if (!abilitiesByClass.has(entry.class)) abilitiesByClass.set(entry.class, []);
          abilitiesByClass.get(entry.class).push(entry);
        }
        const groupedClasses = /* @__PURE__ */ new Set();
        for (const group of groups) {
          const section = element("section");
          section.append(styledHeading("h4", group.title, "sectionHeading"));
          for (const characterClass of group.classes) {
            groupedClasses.add(characterClass.id);
            const abilities = abilitiesByClass.get(characterClass.id) ?? [];
            if (!abilities.length) continue;
            const classSection = element("section");
            classSection.append(
              styledHeading("h5", characterClass.title, "entryTitle"),
              renderAbilityRanks(tab, abilities, 6, favoriteButton)
            );
            section.append(classSection);
          }
          if (section.childElementCount > 1) chapter.append(section);
        }
        const ungrouped = tab.entries.filter((entry) => !groupedClasses.has(entry.class));
        addEntries(chapter, tab, ungrouped, 4, tab, "Other abilities");
      } else {
        addEntries(chapter, tab, tab.entries, 4, tab);
      }
      for (const group of getSectionGroups(tab.sections)) {
        const section = element("section");
        section.append(styledHeading("h4", group.title, "sectionHeading"));
        for (const view of group.sections) {
          const heading = view.navigationGroup ? view.title : void 0;
          addEntries(section, view, view.entries, 5, tab, heading);
        }
        if (section.childElementCount > 1) chapter.append(section);
      }
      if (chapter.childElementCount > 1) root2.append(chapter);
    }
    if (root2.childElementCount === 1) {
      root2.append(element("p", "This compendium has no entries."));
    }
    subtabs.replaceChildren();
    content.replaceChildren(root2);
  }
  function pageUrl(location) {
    const url = new URL(window.location.href);
    for (const key of ["view", "tab", "subtab", "entry"]) {
      if (location[key] === void 0) url.searchParams.delete(key);
      else url.searchParams.set(key, location[key]);
    }
    return url;
  }
  function writePageQuery(location, historyMode) {
    const url = pageUrl(location);
    if (url.href !== window.location.href) window.history[historyMode](null, "", url);
  }
  function renderPage(page, selection, favoriteButton, navigationEditor, onNavigate, focusRow) {
    const location = { tab: page.id };
    const root2 = element("div");
    root2.append(styledHeading("h2", page.title, "pageTitle"));
    const menus = [];
    function choose(label, options, state, key, path, sidebar) {
      const choice = selectOption(label, options, state, key, onNavigate, Boolean(navigationEditor));
      if (!choice) return void 0;
      const list = element("div");
      if (sidebar) choice.nav.classList.add("entry-sidebar");
      list.append(choice.nav);
      if (navigationEditor) {
        if (!sidebar) list.classList.add("navigation-with-actions");
        const controls = element("div");
        navigationEditor.attach(choice.nav, path, controls, choice.options, choice.selected);
        list.append(controls);
      }
      if (sidebar) sidebar.append(list);
      menus.push({ ...choice, label, sidebar, list });
      return choice;
    }
    function readingPane(label, options, state, key, path) {
      const layout = element("div");
      layout.className = "reading-layout";
      const choice = choose(label, options, state, key, path, layout);
      if (!choice) return void 0;
      const body = element("div");
      body.className = "reading-body";
      layout.append(body);
      root2.append(layout);
      if (!choice.selected) body.append(element("p", "No categories yet."));
      return { selected: choice.selected, body };
    }
    function addEntries(view, entries, isSection = false) {
      if (!entries.length) return;
      if (!isSection) {
        root2.append(renderEntries(view, entries, "h3", favoriteButton, page.id));
        return;
      }
      const group = element("section");
      group.append(styledHeading("h3", view.title, "sectionHeading"), renderEntries(view, entries, "h4", favoriteButton, page.id, view.id));
      root2.append(group);
    }
    if (page.type === "classes" && page.classPageStructure) {
      const groups = getClassGroups(page);
      const group = choose("Class groups", groups, selection, "classGroup", [page.id])?.selected;
      location.subtab = group?.id;
      const pane = group && readingPane("Classes", group.classes, selection.groups[group.id] ??= /* @__PURE__ */ Object.create(null), "class", [page.id, group.id]);
      if (pane?.selected) {
        const characterClass = pane.selected;
        location.entry = characterClass.id;
        pane.body.append(styledHeading("h3", characterClass.title, "entryTitle"));
        const abilities = page.entries.filter((entry) => entry.class === characterClass.id);
        if (abilities.length) pane.body.append(renderAbilityRanks(page, abilities, 4, favoriteButton));
        else pane.body.append(element("p", "No abilities listed for this class."));
      }
    } else {
      addEntries(page, page.entries);
      const group = choose(`${page.title} subtabs`, getSectionGroups(page.sections), selection, "subtab", [page.id])?.selected;
      location.subtab = group?.id;
      for (const section of group?.sections ?? []) {
        const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
        if (section.type === "normal" && (section.entries.length || navigationEditor)) {
          const options = section.entries.map((entry) => ({
            id: entry.id,
            title: entry.title ?? entry.name ?? entry.id,
            color: entry.color,
            entry
          }));
          const pane = readingPane(`${section.title} entries`, options, state, "entry", [page.id, group.id]);
          if (pane?.selected) {
            location.entry ??= pane.selected.id;
            pane.body.append(renderEntries(section, [pane.selected.entry], "h3", favoriteButton, page.id, section.id));
          }
        } else {
          addEntries(section, section.entries, true);
        }
      }
    }
    if (root2.childElementCount === 1) {
      root2.append(element("p", "No entries in this section."));
    }
    subtabs.replaceChildren(...menus.filter((menu) => !menu.sidebar).map((menu) => menu.list));
    content.replaceChildren(root2);
    menus.find((menu) => menu.label === focusRow)?.selectedButton?.focus();
    return location;
  }
  function showCompendium(configuration2, projectId2) {
    const canWrite = Boolean(writer.saveEntry || writer.changeNavigation || writer.saveTypography);
    const entryEditor = writer.saveEntry ? createEntryEditor(root, writer, saveTarget) : null;
    function setLocation(location, historyMode) {
      if (routing && host2.isConnected) writePageQuery(location, historyMode);
    }
    let compendium = createCompendium(configuration2);
    findReference = createPageReferences(compendium);
    followReference = openTarget;
    let selected = compendium.tabs[0];
    const fullView = Symbol("Full Compendium");
    const fullTab = element("button", "Full Compendium");
    fullTab.type = "button";
    let writerTools = false;
    const navigationEditor = writer.changeNavigation ? createNavigationEditor(root, () => configuration2, applyConfiguration, writer.changeNavigation, saveTarget) : null;
    if (canWrite) {
      const toolbar = element("div");
      toolbar.className = "writer-toolbar";
      const guideButton = writer.saveTypography ? element("button", "Style Guide") : null;
      if (guideButton) {
        const guide = createStyleGuide(root, writer.saveTypography, applyConfiguration);
        guideButton.type = "button";
        guideButton.hidden = true;
        guideButton.addEventListener("click", () => guide.show(typography));
        toolbar.append(guideButton);
      }
      const toggle = element("button", "Show Writer Tools");
      toggle.type = "button";
      toggle.setAttribute("aria-pressed", "false");
      toggle.addEventListener("click", () => {
        writerTools = !writerTools;
        if (guideButton) guideButton.hidden = !writerTools;
        toggle.textContent = writerTools ? "Hide Writer Tools" : "Show Writer Tools";
        toggle.setAttribute("aria-pressed", String(writerTools));
        renderTabButtons();
        renderTabWriterActions();
        renderSelected();
      });
      const main = root.querySelector("main");
      main.classList.add("writer-preview");
      toggle.className = "writer-toggle";
      toolbar.append(toggle);
      main.append(toolbar);
    }
    const favorites = loadFavorites(projectId2);
    const favoritesTab = element("button");
    favoritesTab.type = "button";
    const updateFavoriteCount = () => {
      favoritesTab.textContent = `Favorites (${favorites.size})`;
    };
    updateFavoriteCount();
    const selections = new Map(compendium.tabs.map((page) => [
      page.id,
      { groups: /* @__PURE__ */ Object.create(null) }
    ]));
    const tabButtons = /* @__PURE__ */ new Map();
    function favoriteButton(item2, title2) {
      const button2 = element("button", "\u2606");
      button2.className = "favorite-star";
      button2.type = "button";
      button2.dataset.favoriteKey = favoriteKey(item2);
      button2.setAttribute("aria-label", `Favorite: ${title2}`);
      const showState = (pressed) => {
        button2.textContent = pressed ? "\u2605" : "\u2606";
        button2.setAttribute("aria-pressed", String(pressed));
      };
      showState(favorites.has(item2));
      button2.addEventListener("click", () => {
        showState(favorites.toggle(item2));
        updateFavoriteCount();
      });
      if (!writerTools || !entryEditor || item2.block) return button2;
      const source = compendium.resolveEntry(item2);
      const edit = element("button", "Edit");
      edit.type = "button";
      edit.setAttribute("aria-label", `Edit: ${title2}`);
      const afterDelete = writer.deleteAbility && !source.section && source.tab.type === "classes" && typeof source.entry.class === "string" ? (updated) => {
        applyConfiguration(updated);
        const selectedClass = content.querySelector('.entry-sidebar [aria-pressed="true"]');
        (selectedClass ?? tabs.querySelector('[aria-pressed="true"]'))?.focus();
        root.querySelector("#writer-announcement").textContent = `Deleted ${title2} from ${saveTarget}.`;
      } : void 0;
      function afterSave(updated) {
        Object.assign(source.entry, updated);
        findReference = createPageReferences(compendium);
        renderSelected();
        const updatedTitle = entryTitle(source.section ?? source.tab, source.entry);
        const buttons = content.querySelectorAll(".entry-actions");
        const actions2 = [...buttons].find((group) => group.firstElementChild.dataset.favoriteKey === favoriteKey(item2));
        actions2?.lastElementChild.focus();
        root.querySelector("#writer-announcement").textContent = `Saved ${updatedTitle} to ${saveTarget}.`;
      }
      const paragraphFields = (source.section ?? source.tab).fields?.filter((field) => field.type === "paragraph").map((field) => field.key);
      edit.addEventListener("click", () => entryEditor.editEntry(item2, title2, source.entry, {
        afterSave,
        afterDelete,
        paragraphFields,
        hideNavigationColor: source.section?.type === "normal"
      }));
      const actions = element("div");
      actions.className = "entry-actions";
      actions.append(button2, edit);
      return actions;
    }
    function renderSelected(focusRow, historyMode = "replaceState") {
      if (selected === fullView) {
        renderFullCompendium(compendium, favoriteButton);
        setLocation({ view: "full" }, historyMode);
      } else if (selected) {
        const location = renderPage(
          selected,
          selections.get(selected.id),
          favoriteButton,
          writerTools ? navigationEditor : null,
          (row) => renderSelected(row, "pushState"),
          focusRow
        );
        setLocation(location, historyMode);
      }
    }
    function activate(page, historyMode = "pushState") {
      selected = page;
      for (const [id, button2] of tabButtons) {
        button2.setAttribute("aria-pressed", String(id === page?.id));
      }
      favoritesTab.setAttribute("aria-pressed", String(!page));
      fullTab.setAttribute("aria-pressed", String(page === fullView));
      renderTabWriterActions();
      search.value = "";
      search.disabled = false;
      renderSearchResults();
      if (page) renderSelected(void 0, historyMode);
      else {
        renderFavorites();
        setLocation({ view: "favorites" }, historyMode);
      }
    }
    function openSource(item2, { tab, section, entry }) {
      const selection = selections.get(tab.id);
      if (section) {
        selection.subtab = section.navigationGroup?.id ?? section.id;
        const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
        state.entry = entry.id;
      } else if (tab.type === "classes" && selection.groups[selection.classGroup]?.class !== entry.class) {
        const group = tab.classPageStructure?.groups?.find((group2) => group2.classes.includes(entry.class));
        if (group) {
          selection.classGroup = group.key;
          const state = selection.groups[group.key] ??= /* @__PURE__ */ Object.create(null);
          state.class = entry.class;
        }
      }
      activate(tab);
      const buttons = [...content.querySelectorAll("[data-favorite-key]")];
      const target = buttons.find((button2) => button2.dataset.favoriteKey === favoriteKey(item2)) ?? buttons.find((button2) => button2.dataset.favoriteKey === favoriteKey({ ...item2, block: void 0 }));
      target?.focus();
    }
    function renderFavorites() {
      subtabs.replaceChildren();
      const root2 = element("div");
      root2.append(styledHeading("h2", "Favorites", "pageTitle"));
      if (!favorites.size) {
        root2.append(element("p", "Star an entry or a passage to save it here."));
        content.replaceChildren(root2);
        return;
      }
      const list = element("div");
      list.className = "cards";
      for (const item2 of favorites.values()) {
        const source = compendium.resolveEntry(item2);
        const card = element("article");
        const title2 = source ? entryTitle(source.section ?? source.tab, source.entry) : item2.entryId;
        card.append(styledHeading("h3", title2, "entryTitle"));
        if (source) {
          const location = [source.tab.title, source.section?.title].filter(Boolean).join(" / ");
          card.append(element("p", location));
          if (item2.block?.excerpt) card.append(element("p", item2.block.excerpt));
        } else {
          card.append(element("p", "This entry is no longer available."));
        }
        const actions = element("div");
        actions.className = "favorite-actions";
        if (source) {
          const open = element("button", "Open source");
          open.type = "button";
          open.addEventListener("click", () => openSource(item2, source));
          actions.append(open);
        }
        const remove = element("button", "Remove");
        remove.type = "button";
        remove.setAttribute("aria-label", `Remove favorite: ${title2}`);
        remove.addEventListener("click", () => {
          favorites.toggle(item2);
          updateFavoriteCount();
          renderFavorites();
          favoritesTab.focus();
        });
        actions.append(remove);
        card.append(actions);
        list.append(card);
      }
      root2.append(list);
      content.replaceChildren(root2);
    }
    function renderSearchResults() {
      const results = searchCompendium(compendium, search.value);
      searchResults.replaceChildren();
      searchResults.hidden = !search.value.trim();
      if (searchResults.hidden) return;
      if (!results.length) {
        const empty = element("p", "No matches found.");
        empty.setAttribute("role", "status");
        searchResults.append(empty);
        return;
      }
      for (const result of results) {
        const button2 = element("button");
        button2.type = "button";
        const title2 = element("span", result.title);
        title2.className = "search-result-title";
        const location = element("small", result.meta);
        location.className = "search-result-location";
        button2.append(title2, location);
        button2.addEventListener("click", () => openTarget(result.target));
        searchResults.append(button2);
      }
    }
    function openTarget(target) {
      const tab = compendium.tabs.find((page) => page.id === target.tabId);
      if (!tab) return;
      const selection = selections.get(tab.id);
      if (target.groupId !== void 0) {
        selection.classGroup = target.groupId;
        const state = selection.groups[target.groupId] ??= /* @__PURE__ */ Object.create(null);
        state.class = target.classId;
      }
      if (target.entryId !== void 0) {
        const source = compendium.resolveEntry(target);
        if (source) {
          openSource(target, source);
          return;
        }
      }
      const section = tab.sections.find((view) => view.id === target.sectionId);
      if (section) {
        selection.subtab = section.navigationGroup?.id ?? section.id;
        const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
        delete state.entry;
      }
      activate(tab);
      tabButtons.get(tab.id)?.focus();
    }
    search.addEventListener("input", renderSearchResults);
    search.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        search.value = "";
        renderSearchResults();
      } else if (event.key === "Enter" || event.key === "ArrowDown") {
        const first = searchResults.querySelector("button");
        if (!first || searchResults.hidden) return;
        event.preventDefault();
        first.focus();
      }
    });
    searchResults.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        search.value = "";
        renderSearchResults();
        search.focus();
      } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const next = event.key === "ArrowDown" ? event.target.nextElementSibling : event.target.previousElementSibling ?? search;
        next?.focus();
      }
    });
    favoritesTab.addEventListener("click", () => activate(null));
    fullTab.addEventListener("click", () => activate(fullView));
    function renderTabWriterActions() {
      tabs.parentElement.classList.toggle("navigation-with-actions", writerTools);
      if (!writerTools || !navigationEditor) {
        tabWriterActions.replaceChildren();
        delete tabs.dataset.navigationPath;
        return;
      }
      const options = compendium.tabs.map((page) => ({ ...page, control: tabButtons.get(page.id) }));
      navigationEditor.attach(tabs, [], tabWriterActions, options, options.find((option) => option.id === selected?.id));
    }
    function renderTabButtons() {
      tabs.replaceChildren(favoritesTab, fullTab);
      tabButtons.clear();
      for (const page of compendium.tabs) {
        const button2 = element("button", page.title);
        button2.type = "button";
        applyNavigationColor(button2, page.color);
        button2.setAttribute("aria-pressed", String(page.id === selected?.id));
        button2.addEventListener("click", () => activate(page));
        tabButtons.set(page.id, button2);
        tabs.append(button2);
        if (!selections.has(page.id)) selections.set(page.id, { groups: /* @__PURE__ */ Object.create(null) });
      }
    }
    function applyConfiguration(updated, added) {
      if (!host2.isConnected) return;
      const previous = selected;
      typography = normalizeTypography(updated.typography);
      applyHeadingStyle(titleHeading, typography.title);
      configuration2 = updated;
      compendium = createCompendium(configuration2);
      findReference = createPageReferences(compendium);
      renderTabButtons();
      if (added) {
        const [tabId, subtabId] = added.path;
        const tab = compendium.tabs.find((page) => page.id === (tabId ?? added.id));
        if (tab) {
          const state = selections.get(tab.id);
          if (tabId) {
            const isClasses = tab.type === "classes" && tab.classPageStructure;
            if (isClasses) state.classGroup = subtabId ?? added.id;
            else state.subtab = subtabId ?? added.id;
            if (subtabId) {
              const subtab = state.groups[subtabId] ??= /* @__PURE__ */ Object.create(null);
              subtab[isClasses ? "class" : "entry"] = added.id;
            }
          }
          activate(tab);
          return;
        }
      }
      if (!previous || previous === fullView) {
        activate(previous, "replaceState");
        return;
      }
      activate(compendium.tabs.find((page) => page.id === previous.id) ?? compendium.tabs[0] ?? fullView, "replaceState");
    }
    function restorePageFromUrl() {
      const params = new URL(window.location.href).searchParams;
      if (params.get("view") === "favorites") return activate(null, "replaceState");
      if (params.get("view") === "full") return activate(fullView, "replaceState");
      const tabId = params.get("tab");
      const tab = compendium.tabs.find((page) => page.id === tabId) ?? compendium.tabs[0];
      if (!tab) return activate(fullView, "replaceState");
      const subtab = tab.id === tabId ? params.get("subtab") : null;
      const entry = tab.id === tabId ? params.get("entry") : null;
      const selection = selections.get(tab.id);
      if (tab.type === "classes" && tab.classPageStructure) {
        const groups = getClassGroups(tab);
        const group = groups.find((candidate) => candidate.id === subtab) ?? groups[0];
        selection.classGroup = group?.id;
        if (group) {
          const state = selection.groups[group.id] ??= /* @__PURE__ */ Object.create(null);
          state.class = group.id === subtab || !subtab ? entry : null;
        }
      } else {
        const groups = getSectionGroups(tab.sections);
        const group = groups.find((candidate) => candidate.id === subtab) ?? groups[0];
        selection.subtab = group?.id;
        for (const section of group?.sections ?? []) {
          const state = selection.groups[section.id] ??= /* @__PURE__ */ Object.create(null);
          state.entry = group.id === subtab || !subtab ? entry : null;
        }
      }
      activate(tab, "replaceState");
    }
    renderTabButtons();
    if (routing) {
      restorePageFromUrl();
      window.addEventListener("popstate", restorePageFromUrl);
    } else {
      activate(selected ?? fullView);
    }
    return () => {
      window.removeEventListener("popstate", restorePageFromUrl);
      entryEditor?.dispose();
    };
  }
  try {
    const dispose = showCompendium(structuredClone(configuration), projectId);
    return {
      destroy() {
        dispose();
        host2.remove();
      }
    };
  } catch (error) {
    host2.remove();
    throw error;
  }
}

// preview/GameCompendium.jsx
import { jsx as jsx10, jsxs as jsxs10 } from "react/jsx-runtime";
function savedTypography(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved === null ? fallback : normalizeTypography(JSON.parse(saved));
  } catch {
    return fallback;
  }
}
function GameCompendium({
  title,
  projectId,
  backTo,
  loadData,
  configure,
  imageBaseUrl,
  themeUrl = "/preview/compendium-theme.css",
  pageStyleUrl
}) {
  const container = useRef5(null);
  const [status, setStatus] = useState8("Loading compendium\u2026");
  useEffect8(() => {
    const controller = new AbortController();
    const element = container.current;
    const pathname = window.location.pathname;
    let compendium;
    function dispose() {
      controller.abort();
      compendium?.destroy();
      compendium = void 0;
    }
    function handlePopState() {
      if (window.location.pathname !== pathname) dispose();
    }
    async function load() {
      setStatus("Loading compendium\u2026");
      try {
        const data = await loadData(controller.signal);
        if (controller.signal.aborted) return;
        const configuration = configure(data);
        const typographyKey = `40k-compendium-typography:${projectId}`;
        const typography = savedTypography(typographyKey, configuration.typography);
        compendium = mountCompendium(element, { ...configuration, typography }, {
          title,
          projectId,
          imageBaseUrl,
          routing: true,
          stylesheets: [themeUrl],
          writer: {
            saveTypography(nextTypography) {
              localStorage.setItem(typographyKey, JSON.stringify(nextTypography));
              return { ...configuration, typography: nextTypography };
            }
          }
        });
        setStatus("");
      } catch (error) {
        if (!controller.signal.aborted) setStatus(`Unable to open ${title}. ${error.message}`);
      }
    }
    window.addEventListener("popstate", handlePopState, true);
    load();
    return () => {
      window.removeEventListener("popstate", handlePopState, true);
      dispose();
    };
  }, [title, projectId, loadData, configure, imageBaseUrl, themeUrl]);
  return /* @__PURE__ */ jsxs10("main", { className: "game-compendium", "data-project": projectId, children: [
    pageStyleUrl && /* @__PURE__ */ jsx10("link", { rel: "stylesheet", href: pageStyleUrl }),
    /* @__PURE__ */ jsx10("nav", { "aria-label": `${title} navigation`, children: /* @__PURE__ */ jsx10(Link7, { to: backTo, children: "\u2039 Back" }) }),
    status && /* @__PURE__ */ jsx10("p", { role: "status", children: status }),
    /* @__PURE__ */ jsx10("div", { ref: container })
  ] });
}

// preview/compendium-data.mjs
var expeditionTerrains = {
  plains: "Plains",
  forest: "Forest",
  mountains: "Mountains",
  swamp: "Swamp",
  desert: "Desert",
  arctic: "Arctic",
  ocean: "Ocean"
};
function titleFor2(key) {
  return key.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_-]+/g, " ").replace(/^./, (letter) => letter.toUpperCase());
}
function compendiumBuilder() {
  const collections = [];
  function page(id, title, type, entries, options) {
    const collectionId = `collection-${collections.length + 1}`;
    collections.push({ id: collectionId, entries });
    return { id, title, type, collectionId, ...options };
  }
  return { collections, page };
}
function expeditionCompendium(data) {
  if (Array.isArray(data?.tabs)) return data;
  if (!data?.tileTypes || typeof data.tileTypes !== "object" || Array.isArray(data.tileTypes)) {
    throw new Error("The Expedition location compendium is missing terrain data.");
  }
  const { page, collections } = compendiumBuilder();
  const sections = Object.entries(data.tileTypes).flatMap(([terrain, locations]) => {
    const entries = Object.entries(locations).map(([number, location]) => ({
      id: number,
      title: location.title?.trim() || `Location ${number}`,
      content: location.description ?? "",
      locationNumber: number
    }));
    if (!entries.length) return [];
    return page(terrain, expeditionTerrains[terrain] ?? titleFor2(terrain), "normal", entries, {
      fields: [{ key: "locationNumber", label: "Location number" }]
    });
  });
  return { tabs: [{ id: "locations", title: "Locations", type: "normal", sections }], collections };
}

// packages/expedition.jsx
import { jsx as jsx11, jsxs as jsxs11 } from "react/jsx-runtime";
var projectPath = "/projects/Expedition";
var assets = "/games/Expedition";
function Expedition2() {
  return /* @__PURE__ */ jsx11(Expedition, { compendiumPath: `${projectPath}Compendium`, campaignTools: hasCampaignTools() });
}
async function loadLocations(signal) {
  const response = await fetch(`${assets}/location-compendium.json`, { signal });
  if (!response.ok) throw new Error(`Could not load Expedition locations (HTTP ${response.status}).`);
  return response.json();
}
function ExpeditionCompendium() {
  return /* @__PURE__ */ jsx11(
    GameCompendium,
    {
      title: "Expedition Compendium",
      projectId: "expedition",
      backTo: projectPath,
      loadData: loadLocations,
      configure: expeditionCompendium,
      themeUrl: `${assets}/compendium-theme.css`,
      pageStyleUrl: `${assets}/compendium-page.css`
    }
  );
}
function campaignPage(Page, title) {
  return function CampaignPage(props) {
    if (hasCampaignTools()) return /* @__PURE__ */ jsx11(Page, { ...props });
    return /* @__PURE__ */ jsxs11("main", { style: { minHeight: "100dvh", background: "#1e1e1e", color: "#fff", padding: "24px" }, children: [
      /* @__PURE__ */ jsx11(Link8, { to: projectPath, style: { color: "inherit" }, children: "\u2039 Expedition" }),
      /* @__PURE__ */ jsx11("h1", { children: title }),
      /* @__PURE__ */ jsx11("p", { children: "This page is unavailable on this server." })
    ] });
  };
}
var battlesPage = campaignPage(ExpeditionBattles, "Battles");
var routes = [
  { path: projectPath, Component: Expedition2 },
  { path: `${projectPath}Compendium`, Component: ExpeditionCompendium },
  { path: `${projectPath}Map`, Component: ExpeditionMap_default },
  { path: `${projectPath}Teams`, Component: campaignPage(ExpeditionTeams, "Team Management") },
  { path: `${projectPath}Bounties`, Component: ExpeditionBounties },
  { path: `${projectPath}Battles`, Component: battlesPage },
  { path: `${projectPath}Battles/settings`, Component: battlesPage, props: { settings: true } },
  { path: `${projectPath}Lore`, Component: campaignPage(ExpeditionLore, "Lore") },
  { path: `${projectPath}Shop`, Component: campaignPage(ExpeditionShop, "Shop") }
];
export {
  configureHost,
  routes
};
